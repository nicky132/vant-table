import { ref, openBlock, createElementBlock, normalizeStyle, createElementVNode, createCommentVNode, Fragment, renderList, normalizeClass, toDisplayString, withModifiers, createVNode, unref, createBlock, resolveDynamicComponent, createTextVNode, renderSlot, onMounted, computed, Teleport, withCtx, watch, nextTick, h, onUnmounted, reactive, mergeProps } from "vue";
import { Empty, Loading, Popup, Icon, Field, Checkbox, Button } from "vant";
const _hoisted_1$8 = {
  key: 0,
  style: { width: "40px" }
};
const _hoisted_2$6 = { class: "vant-thead" };
const _hoisted_3$6 = {
  key: 0,
  class: "vant-th vant-th--expand",
  style: { width: "40px", textAlign: "center" }
};
const _hoisted_4$5 = ["data-key"];
const _hoisted_5$4 = ["onClick"];
const _hoisted_6$4 = { class: "vant-th__text" };
const _hoisted_7$4 = {
  key: 0,
  class: "vant-th__sort-icon"
};
const _hoisted_8$4 = {
  class: "vant-sort-icon",
  width: "12",
  height: "12",
  viewBox: "0 0 12 12",
  fill: "none"
};
const _hoisted_9$4 = ["onClick"];
const _sfc_main$8 = {
  __name: "TableHeader",
  props: {
    hasLeftFixedContent: Boolean,
    leftFixedTotalWidth: Number,
    hasRightFixedColumns: Boolean,
    columnsInfo: Object,
    tableStyle: Object,
    expandable: Boolean,
    hasLeftFixedExpand: Boolean,
    getColStyle: Function,
    getHeaderClass: Function,
    getHeaderStyle: Function,
    setHeaderElementRef: Function,
    handleSort: Function,
    sortConfig: Object,
    isFilterActive: Function,
    toggleFilter: Function,
    // 添加滚动处理相关的props
    bodyRef: Object
  },
  emits: ["header-wheel"],
  setup(__props, { expose: __expose, emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const headerRef = ref(null);
    const headerContentRef = ref(null);
    const headerRowRef = ref(null);
    const handleHeaderWheel = (event) => {
      var _a, _b;
      console.log("🎯 表头滚动事件被触发！", {
        deltaY: event.deltaY,
        deltaX: event.deltaX,
        target: event.target,
        currentTarget: event.currentTarget
      });
      event.preventDefault();
      const deltaY = event.deltaY;
      const deltaX = event.deltaX;
      const scrollSensitivity = 1;
      const bodyElement = props.bodyRef && props.bodyRef.__v_isRef ? props.bodyRef.value : props.bodyRef;
      console.log("🔍 TableHeader中的bodyRef状态:", {
        bodyRef: props.bodyRef,
        bodyRefExists: !!props.bodyRef,
        bodyRefValue: (_a = props.bodyRef) == null ? void 0 : _a.value,
        bodyRefValueExists: !!((_b = props.bodyRef) == null ? void 0 : _b.value),
        bodyElement,
        bodyElementExists: !!bodyElement
      });
      if (!bodyElement) {
        console.warn("⚠️ bodyRef不存在，尝试通过DOM查询获取主表格元素");
        const mainBodyElements = document.querySelectorAll(".vant-table-body");
        let foundMainTable = null;
        console.log("🔍 找到的.vant-table-body元素数量:", mainBodyElements.length);
        for (let element of mainBodyElements) {
          const isInFixed = !!element.closest(".vant-table-fixed");
          console.log("🔍 检查表格元素:", {
            element,
            className: element.className,
            isInFixed,
            scrollLeft: element.scrollLeft,
            scrollTop: element.scrollTop
          });
          if (!isInFixed) {
            foundMainTable = element;
            console.log("✅ 找到主表格元素");
            break;
          }
        }
        if (foundMainTable) {
          const currentScrollTop2 = foundMainTable.scrollTop;
          const currentScrollLeft2 = foundMainTable.scrollLeft;
          const newScrollTop2 = Math.max(0, currentScrollTop2 + deltaY * scrollSensitivity);
          const newScrollLeft2 = Math.max(0, currentScrollLeft2 + deltaX * scrollSensitivity);
          console.log("🔄 通过DOM查询直接操作主表格滚动:", {
            currentScrollTop: currentScrollTop2,
            currentScrollLeft: currentScrollLeft2,
            newScrollTop: newScrollTop2,
            newScrollLeft: newScrollLeft2,
            deltaY,
            deltaX
          });
          foundMainTable.scrollTop = newScrollTop2;
          foundMainTable.scrollLeft = newScrollLeft2;
          if (headerContentRef.value) {
            headerContentRef.value.scrollLeft = newScrollLeft2;
          }
          emit("header-wheel", {
            event,
            scrollTop: newScrollTop2,
            scrollLeft: newScrollLeft2,
            deltaY,
            deltaX
          });
          return;
        } else {
          console.warn("⚠️ 通过DOM查询也无法找到主表格元素");
          return;
        }
      }
      const currentScrollTop = bodyElement.scrollTop;
      const currentScrollLeft = bodyElement.scrollLeft;
      const newScrollTop = Math.max(0, currentScrollTop + deltaY * scrollSensitivity);
      const newScrollLeft = Math.max(0, currentScrollLeft + deltaX * scrollSensitivity);
      console.log("🔄 表头滚动同步:", {
        currentScrollTop,
        currentScrollLeft,
        deltaY,
        deltaX,
        newScrollTop,
        newScrollLeft
      });
      bodyElement.scrollTop = newScrollTop;
      bodyElement.scrollLeft = newScrollLeft;
      if (headerContentRef.value) {
        headerContentRef.value.scrollLeft = newScrollLeft;
      }
      emit("header-wheel", {
        event,
        scrollTop: newScrollTop,
        scrollLeft: newScrollLeft,
        deltaY,
        deltaX
      });
    };
    const handleHeaderWheelContent = (event) => {
      console.log("🎯 表头内容区域滚动事件！", {
        deltaY: event.deltaY,
        deltaX: event.deltaX
      });
      handleHeaderWheel(event);
    };
    __expose({
      headerRef,
      headerContentRef,
      headerRowRef
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: "vant-table-header",
        ref_key: "headerRef",
        ref: headerRef,
        style: normalizeStyle({
          marginLeft: __props.hasLeftFixedContent ? `${__props.leftFixedTotalWidth}px` : "0",
          marginRight: __props.hasRightFixedColumns ? `${__props.columnsInfo.rightFixedWidth}px` : "0"
        }),
        onWheel: handleHeaderWheel
      }, [
        createElementVNode("div", {
          class: "vant-table-header__content",
          ref_key: "headerContentRef",
          ref: headerContentRef,
          onWheel: handleHeaderWheelContent
        }, [
          createElementVNode("table", {
            class: "vant-table vant-table--header",
            style: normalizeStyle(__props.tableStyle)
          }, [
            createElementVNode("colgroup", null, [
              __props.expandable && !__props.hasLeftFixedExpand ? (openBlock(), createElementBlock("col", _hoisted_1$8)) : createCommentVNode("", true),
              (openBlock(true), createElementBlock(Fragment, null, renderList(__props.columnsInfo.mainHeaders, (header) => {
                return openBlock(), createElementBlock("col", {
                  key: header.key,
                  style: normalizeStyle(__props.getColStyle(header))
                }, null, 4);
              }), 128))
            ]),
            createElementVNode("thead", _hoisted_2$6, [
              createElementVNode("tr", {
                class: "vant-thead-row vant-thead-row--main",
                ref_key: "headerRowRef",
                ref: headerRowRef
              }, [
                __props.expandable && !__props.hasLeftFixedExpand ? (openBlock(), createElementBlock("th", _hoisted_3$6, _cache[0] || (_cache[0] = [
                  createElementVNode("div", { class: "vant-th__content" }, null, -1)
                ]))) : createCommentVNode("", true),
                (openBlock(true), createElementBlock(Fragment, null, renderList(__props.columnsInfo.mainHeaders, (header) => {
                  return openBlock(), createElementBlock("th", {
                    key: header.key,
                    class: normalizeClass(__props.getHeaderClass(header)),
                    style: normalizeStyle(__props.getHeaderStyle(header)),
                    "data-key": header.key,
                    ref_for: true,
                    ref: (el) => __props.setHeaderElementRef(el, header.key, "main")
                  }, [
                    createElementVNode("div", {
                      class: "vant-th__content",
                      onClick: ($event) => __props.handleSort(header)
                    }, [
                      createElementVNode("span", _hoisted_6$4, toDisplayString(header.label), 1),
                      header.sortable ? (openBlock(), createElementBlock("div", _hoisted_7$4, [
                        (openBlock(), createElementBlock("svg", _hoisted_8$4, [
                          createElementVNode("path", {
                            class: normalizeClass([
                              "vant-sort-icon__asc",
                              {
                                "vant-sort-icon--active": __props.sortConfig.key === header.key && __props.sortConfig.direction === "asc"
                              }
                            ]),
                            d: "M3.96569 4C3.60932 4 3.43086 3.56914 3.68284 3.31716L5.71716 1.28284C5.87337 1.12663 6.12663 1.12663 6.28284 1.28284L8.31716 3.31716C8.56914 3.56914 8.39068 4 8.03431 4L3.96569 4Z",
                            "stroke-linejoin": "round"
                          }, null, 2),
                          createElementVNode("path", {
                            class: normalizeClass([
                              "vant-sort-icon__desc",
                              {
                                "vant-sort-icon--active": __props.sortConfig.key === header.key && __props.sortConfig.direction === "desc"
                              }
                            ]),
                            d: "M8.03431 8C8.39068 8 8.56914 8.43086 8.31716 8.68284L6.28284 10.7172C6.12663 10.8734 5.87337 10.8734 5.71716 10.7172L3.68284 8.68284C3.43086 8.43086 3.60932 8 3.96569 8H8.03431Z",
                            "stroke-linejoin": "round"
                          }, null, 2)
                        ]))
                      ])) : createCommentVNode("", true),
                      header.filterable ? (openBlock(), createElementBlock("i", {
                        key: 1,
                        class: normalizeClass(["van-icon van-icon-filter-o vant-th__filter-icon", { "vant-th__filter-icon--active": __props.isFilterActive(header.key) }]),
                        onClick: withModifiers(($event) => __props.toggleFilter(header.key), ["stop"])
                      }, null, 10, _hoisted_9$4)) : createCommentVNode("", true)
                    ], 8, _hoisted_5$4)
                  ], 14, _hoisted_4$5);
                }), 128))
              ], 512)
            ])
          ], 4)
        ], 544)
      ], 36);
    };
  }
};
const _hoisted_1$7 = {
  key: 0,
  style: { width: "40px" }
};
const _hoisted_2$5 = { key: 0 };
const _hoisted_3$5 = ["colspan"];
const _hoisted_4$4 = { class: "vant-empty-content" };
const _hoisted_5$3 = ["data-row-index", "onClick", "onMouseenter", "onMouseleave"];
const _hoisted_6$3 = ["onClick"];
const _hoisted_7$3 = { class: "vant-td__content" };
const _hoisted_8$3 = ["data-key", "onClick"];
const _hoisted_9$3 = { class: "vant-td__content" };
const _hoisted_10$3 = ["data-expanded-row-index"];
const _hoisted_11$2 = ["colspan"];
const _hoisted_12$1 = { class: "vant-td__expand-content" };
const _hoisted_13$1 = { class: "vant-expand-panel" };
const _hoisted_14$1 = { class: "vant-expand-panel__content" };
const _hoisted_15$1 = { class: "vant-field__label" };
const _hoisted_16$1 = { class: "vant-field__value" };
const _sfc_main$7 = {
  __name: "TableBody",
  props: {
    bodyWrapperStyle: Object,
    tableStyle: Object,
    columnsInfo: Object,
    filteredAndSortedData: Array,
    hasActiveFilters: Boolean,
    expandable: Boolean,
    hasLeftFixedExpand: Boolean,
    // Functions
    handleScroll: Function,
    handleMainTableWheel: Function,
    handleMainTableTouchStart: Function,
    handleMainTableTouchMove: Function,
    handleMainTableTouchEnd: Function,
    handleAreaMouseEnter: Function,
    handleAreaMouseLeave: Function,
    getColStyle: Function,
    getRowKey: Function,
    getRowClass: Function,
    getRowStyle: Function,
    setRowElementRef: Function,
    handleSingleRowHighlight: Function,
    handleRowClickLocal: Function,
    handleRowMouseEnter: Function,
    handleRowMouseLeave: Function,
    getCellClass: Function,
    getCellStyle: Function,
    handleCellClick: Function,
    isRowTotal: Function,
    getDataBarStyle: Function,
    getCellValue: Function,
    renderCustomCell: Function,
    formatCellValue: Function,
    isExpanded: Function,
    toggleExpand: Function
  },
  setup(__props, { expose: __expose }) {
    const bodyRef = ref(null);
    const tbodyRef = ref(null);
    __expose({
      bodyRef,
      tbodyRef
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: "vant-table-body",
        style: normalizeStyle(__props.bodyWrapperStyle),
        onScroll: _cache[0] || (_cache[0] = (...args) => __props.handleScroll && __props.handleScroll(...args)),
        onWheel: _cache[1] || (_cache[1] = (...args) => __props.handleMainTableWheel && __props.handleMainTableWheel(...args)),
        onTouchstart: _cache[2] || (_cache[2] = (...args) => __props.handleMainTableTouchStart && __props.handleMainTableTouchStart(...args)),
        onTouchmove: _cache[3] || (_cache[3] = (...args) => __props.handleMainTableTouchMove && __props.handleMainTableTouchMove(...args)),
        onTouchend: _cache[4] || (_cache[4] = (...args) => __props.handleMainTableTouchEnd && __props.handleMainTableTouchEnd(...args)),
        onMouseenter: _cache[5] || (_cache[5] = () => __props.handleAreaMouseEnter("main")),
        onMouseleave: _cache[6] || (_cache[6] = () => __props.handleAreaMouseLeave("main")),
        ref_key: "bodyRef",
        ref: bodyRef
      }, [
        createElementVNode("table", {
          class: "vant-table vant-table--body",
          style: normalizeStyle(__props.tableStyle)
        }, [
          createElementVNode("colgroup", null, [
            __props.expandable && !__props.hasLeftFixedExpand ? (openBlock(), createElementBlock("col", _hoisted_1$7)) : createCommentVNode("", true),
            (openBlock(true), createElementBlock(Fragment, null, renderList(__props.columnsInfo.mainHeaders, (header) => {
              return openBlock(), createElementBlock("col", {
                key: header.key,
                style: normalizeStyle(__props.getColStyle(header))
              }, null, 4);
            }), 128))
          ]),
          createElementVNode("tbody", {
            class: "vant-tbody",
            ref_key: "tbodyRef",
            ref: tbodyRef
          }, [
            !__props.filteredAndSortedData.length ? (openBlock(), createElementBlock("tr", _hoisted_2$5, [
              createElementVNode("td", {
                colspan: (__props.expandable && !__props.hasLeftFixedExpand ? 1 : 0) + __props.columnsInfo.mainHeaders.length,
                class: "vant-td vant-td--empty"
              }, [
                createElementVNode("div", _hoisted_4$4, [
                  createVNode(unref(Empty), {
                    description: __props.hasActiveFilters ? "没有符合条件的数据" : "暂无数据"
                  }, null, 8, ["description"])
                ])
              ], 8, _hoisted_3$5)
            ])) : (openBlock(true), createElementBlock(Fragment, { key: 1 }, renderList(__props.filteredAndSortedData, (row, rowIndex) => {
              return openBlock(), createElementBlock(Fragment, {
                key: __props.getRowKey(row, rowIndex)
              }, [
                createElementVNode("tr", {
                  class: normalizeClass(__props.getRowClass(rowIndex, row)),
                  style: normalizeStyle(__props.getRowStyle(rowIndex)),
                  "data-row-index": rowIndex,
                  ref_for: true,
                  ref: (el) => __props.setRowElementRef(el, rowIndex, "main"),
                  onClick: ($event) => {
                    __props.handleSingleRowHighlight($event, rowIndex);
                    __props.handleRowClickLocal(row, rowIndex);
                  },
                  onMouseenter: ($event) => __props.handleRowMouseEnter(rowIndex),
                  onMouseleave: ($event) => __props.handleRowMouseLeave(rowIndex)
                }, [
                  __props.expandable && !__props.hasLeftFixedExpand ? (openBlock(), createElementBlock("td", {
                    key: 0,
                    class: "vant-td vant-td--expand",
                    style: { width: "40px", textAlign: "center" },
                    onClick: withModifiers(($event) => __props.toggleExpand(row, rowIndex), ["stop"])
                  }, [
                    createElementVNode("div", _hoisted_7$3, [
                      createElementVNode("i", {
                        class: normalizeClass(["van-icon van-icon-arrow vant-td__expand-icon", { "vant-td__expand-icon--expanded": __props.isExpanded(row, rowIndex) }])
                      }, null, 2)
                    ])
                  ], 8, _hoisted_6$3)) : createCommentVNode("", true),
                  (openBlock(true), createElementBlock(Fragment, null, renderList(__props.columnsInfo.mainHeaders, (header, colIndex) => {
                    return openBlock(), createElementBlock("td", {
                      key: header.key,
                      class: normalizeClass(__props.getCellClass(header, row, rowIndex)),
                      style: normalizeStyle(__props.getCellStyle(header)),
                      "data-key": header.key,
                      onClick: ($event) => {
                        __props.handleSingleRowHighlight($event, rowIndex);
                        __props.handleCellClick(row, header, rowIndex, colIndex, $event);
                      }
                    }, [
                      createElementVNode("div", _hoisted_9$3, [
                        header.showDataBar && !__props.isRowTotal(row) ? (openBlock(), createElementBlock("div", {
                          key: 0,
                          class: "vant-td__data-bar",
                          style: normalizeStyle(__props.getDataBarStyle(__props.getCellValue(row, header.key), header.key))
                        }, null, 4)) : createCommentVNode("", true),
                        createElementVNode("span", {
                          class: normalizeClass({ "vant-td__link": header.link, "vant-td__text": !header.link })
                        }, [
                          header.renderCell ? (openBlock(), createBlock(resolveDynamicComponent(__props.renderCustomCell(
                            __props.getCellValue(row, header.key),
                            row,
                            header,
                            rowIndex,
                            colIndex
                          )), { key: 0 })) : (openBlock(), createElementBlock(Fragment, { key: 1 }, [
                            createTextVNode(toDisplayString(__props.formatCellValue(__props.getCellValue(row, header.key), header)), 1)
                          ], 64))
                        ], 2)
                      ])
                    ], 14, _hoisted_8$3);
                  }), 128))
                ], 46, _hoisted_5$3),
                __props.expandable && __props.isExpanded(row, rowIndex) ? (openBlock(), createElementBlock("tr", {
                  key: 0,
                  class: normalizeClass(["vant-tr", "vant-tr--expanded"]),
                  "data-expanded-row-index": rowIndex
                }, [
                  createElementVNode("td", {
                    colspan: (__props.expandable && !__props.hasLeftFixedExpand ? 1 : 0) + __props.columnsInfo.mainHeaders.length,
                    class: "vant-td vant-td--expanded"
                  }, [
                    createElementVNode("div", _hoisted_12$1, [
                      renderSlot(_ctx.$slots, "expanded", {
                        row,
                        rowIndex
                      }, () => [
                        createElementVNode("div", _hoisted_13$1, [
                          _cache[7] || (_cache[7] = createElementVNode("div", { class: "vant-expand-panel__header" }, [
                            createElementVNode("h4", null, "详细信息")
                          ], -1)),
                          createElementVNode("div", _hoisted_14$1, [
                            (openBlock(true), createElementBlock(Fragment, null, renderList(row, (value, key) => {
                              return openBlock(), createElementBlock("div", {
                                key,
                                class: "vant-field vant-field--readonly"
                              }, [
                                createElementVNode("div", _hoisted_15$1, toDisplayString(key) + ":", 1),
                                createElementVNode("div", _hoisted_16$1, toDisplayString(value), 1)
                              ]);
                            }), 128))
                          ])
                        ])
                      ])
                    ])
                  ], 8, _hoisted_11$2)
                ], 8, _hoisted_10$3)) : createCommentVNode("", true)
              ], 64);
            }), 128))
          ], 512)
        ], 4)
      ], 36);
    };
  }
};
const _hoisted_1$6 = ["checked", "disabled"];
const _sfc_main$6 = /* @__PURE__ */ Object.assign({
  name: "VTableCheckbox"
}, {
  __name: "VTableCheckbox",
  props: {
    modelValue: Boolean,
    indeterminate: Boolean,
    disabled: Boolean
  },
  emits: ["update:modelValue"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const handleChange = (event) => {
      if (props.disabled)
        return;
      emit("update:modelValue", event.target.checked);
    };
    const handleClick = (e) => {
      e.stopPropagation();
      if (!props.disabled) {
        emit("update:modelValue", !props.modelValue);
      }
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass([
          "vant-table-checkbox",
          {
            "vant-table-checkbox--checked": __props.modelValue,
            "vant-table-checkbox--indeterminate": __props.indeterminate,
            "vant-table-checkbox--disabled": __props.disabled
          }
        ]),
        onClick: handleClick
      }, [
        createElementVNode("input", {
          type: "checkbox",
          class: "vant-table-checkbox__input",
          checked: __props.modelValue,
          disabled: __props.disabled,
          onChange: handleChange
        }, null, 40, _hoisted_1$6)
      ], 2);
    };
  }
});
const _hoisted_1$5 = ["checked", "disabled"];
const _hoisted_2$4 = { class: "vant-table-radio__icon" };
const _hoisted_3$4 = {
  key: 0,
  class: "vant-table-radio__dot"
};
const _sfc_main$5 = /* @__PURE__ */ Object.assign({
  name: "VTableRadio"
}, {
  __name: "VTableRadio",
  props: {
    modelValue: Boolean,
    disabled: Boolean
  },
  emits: ["update:modelValue"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const handleChange = (event) => {
      if (props.disabled)
        return;
      emit("update:modelValue", event.target.checked);
    };
    const handleClick = (e) => {
      e.stopPropagation();
      if (!props.disabled) {
        emit("update:modelValue", true);
      }
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass([
          "vant-table-radio",
          {
            "vant-table-radio--checked": __props.modelValue,
            "vant-table-radio--disabled": __props.disabled
          }
        ]),
        onClick: handleClick
      }, [
        createElementVNode("input", {
          type: "radio",
          class: "vant-table-radio__input",
          checked: __props.modelValue,
          disabled: __props.disabled,
          onChange: handleChange
        }, null, 40, _hoisted_1$5),
        createElementVNode("span", _hoisted_2$4, [
          __props.modelValue ? (openBlock(), createElementBlock("span", _hoisted_3$4)) : createCommentVNode("", true)
        ])
      ], 2);
    };
  }
});
const _hoisted_1$4 = { class: "vant-thead" };
const _hoisted_2$3 = { class: "vant-th__content" };
const _hoisted_3$3 = { class: "vant-selection-header" };
const _hoisted_4$3 = {
  key: 1,
  class: "vant-selection-header__text"
};
const _hoisted_5$2 = ["data-key"];
const _hoisted_6$2 = ["onClick"];
const _hoisted_7$2 = { class: "vant-th__text" };
const _hoisted_8$2 = {
  key: 0,
  class: "vant-th__sort-icon"
};
const _hoisted_9$2 = {
  class: "vant-sort-icon",
  width: "12",
  height: "12",
  viewBox: "0 0 12 12",
  fill: "none"
};
const _hoisted_10$2 = ["onClick"];
const _hoisted_11$1 = { key: 0 };
const _hoisted_12 = ["colspan"];
const _hoisted_13 = { class: "vant-empty-content" };
const _hoisted_14 = ["data-row-index", "onClick", "onMouseenter", "onMouseleave"];
const _hoisted_15 = ["onClick"];
const _hoisted_16 = { class: "vant-td__content" };
const _hoisted_17 = ["onClick"];
const _hoisted_18 = { class: "vant-td__content" };
const _hoisted_19 = ["data-key", "onClick"];
const _hoisted_20 = { class: "vant-td__content" };
const _hoisted_21 = ["data-expanded-row-index"];
const _hoisted_22 = ["colspan"];
const _hoisted_23 = { class: "vant-td__expand-content vant-td__expand-content--fixed" };
const _hoisted_24 = { class: "vant-expand-panel" };
const _hoisted_25 = { class: "vant-expand-panel__content vant-expand-panel__content--fixed" };
const _hoisted_26 = {
  key: 0,
  class: "vant-field vant-field--readonly"
};
const _hoisted_27 = { class: "vant-field__label" };
const _hoisted_28 = { class: "vant-field__value" };
const _hoisted_29 = {
  key: 0,
  class: "vant-table-load-more__loading"
};
const _hoisted_30 = {
  key: 2,
  class: "vant-table-load-more__finished"
};
const _hoisted_31 = {
  key: 3,
  class: "vant-table-load-more__ready"
};
const _sfc_main$4 = {
  __name: "FixedColumn",
  props: {
    position: {
      type: String,
      required: true,
      validator: (value) => ["left", "right"].includes(value)
    },
    shouldShow: Boolean,
    columns: Array,
    showSelection: Boolean,
    showExpand: Boolean,
    shouldShowShadow: Boolean,
    // 🔑 参考vxe-table的阴影控制
    // 样式相关
    fixedStyle: Object,
    fixedHeaderWrapperStyle: Object,
    headerTableStyle: Object,
    bodyWrapperStyle: Object,
    bodyTableStyle: Object,
    selectionColStyle: Object,
    expandColStyle: Object,
    fixedColumnLoadMorePositionStyle: Object,
    // 数据相关
    filteredAndSortedData: Array,
    hasActiveFilters: Boolean,
    sortConfig: Object,
    isRadioMode: Boolean,
    isAllSelected: Boolean,
    isIndeterminate: Boolean,
    selectableRows: Array,
    allRowsDisabled: Boolean,
    columnsInfo: Object,
    tableStyle: Object,
    expandable: Boolean,
    // 加载更多相关
    enableLoadMore: Boolean,
    showLoadMoreUi: Boolean,
    loadMoreLoading: Boolean,
    loadMoreError: Boolean,
    loadMoreFinished: Boolean,
    loadMoreLoadingText: String,
    loadMoreErrorText: String,
    loadMoreFinishedText: String,
    loadMoreReadyText: String,
    // 函数相关
    getColStyle: Function,
    getFixedHeaderClass: Function,
    getFixedHeaderStyle: Function,
    getFixedCellClass: Function,
    getFixedCellStyle: Function,
    getSelectionHeaderStyle: Function,
    getExpandHeaderStyle: Function,
    getSelectionCellStyle: Function,
    getExpandCellStyle: Function,
    setHeaderElementRef: Function,
    handleSort: Function,
    isFilterActive: Function,
    toggleFilter: Function,
    handleFixedColumnScroll: Function,
    handleFixedColumnWheel: Function,
    handleFixedColumnTouchStart: Function,
    handleAreaMouseEnter: Function,
    handleAreaMouseLeave: Function,
    handleFixedColumnTouchMove: Function,
    handleFixedColumnTouchEnd: Function,
    getRowClass: Function,
    getRowStyle: Function,
    setRowElementRef: Function,
    handleSingleRowHighlight: Function,
    handleRowClickLocal: Function,
    handleRowMouseEnter: Function,
    handleRowMouseLeave: Function,
    getCellClass: Function,
    getCellStyle: Function,
    handleCellSelect: Function,
    isRowSelected: Function,
    isRowDisabled: Function,
    handleRowSelect: Function,
    toggleExpand: Function,
    isExpanded: Function,
    handleCellClick: Function,
    isRowTotal: Function,
    getDataBarStyle: Function,
    getCellValue: Function,
    renderCustomCell: Function,
    formatCellValue: Function,
    getRowKey: Function,
    handleSelectAll: Function
  },
  emits: ["load-more"],
  setup(__props, { expose: __expose }) {
    var _a, _b, _c, _d, _e;
    const props = __props;
    console.log(`FixedColumn ${props.position} debug:`, {
      shouldShow: props.shouldShow,
      columns: props.columns,
      columnsLength: ((_a = props.columns) == null ? void 0 : _a.length) || 0,
      filteredData: props.filteredAndSortedData,
      filteredDataLength: ((_b = props.filteredAndSortedData) == null ? void 0 : _b.length) || 0,
      filteredDataType: typeof props.filteredAndSortedData,
      filteredDataIsArray: Array.isArray(props.filteredAndSortedData),
      showSelection: props.showSelection,
      showExpand: props.showExpand,
      hasActiveFilters: props.hasActiveFilters
    });
    console.log(`FixedColumn ${props.position} template conditions:`, {
      "shouldShow": props.shouldShow,
      "!filteredAndSortedData.length": !((_c = props.filteredAndSortedData) == null ? void 0 : _c.length),
      "will show empty state": !((_d = props.filteredAndSortedData) == null ? void 0 : _d.length),
      "will show data rows": !!((_e = props.filteredAndSortedData) == null ? void 0 : _e.length)
    });
    const headerRowRef = ref(null);
    const bodyWrapperRef = ref(null);
    const tbodyRef = ref(null);
    __expose({
      headerRowRef,
      bodyWrapperRef,
      tbodyRef
    });
    return (_ctx, _cache) => {
      return __props.shouldShow ? (openBlock(), createElementBlock("div", {
        key: 0,
        class: normalizeClass([
          "vant-table-fixed",
          `vant-table-fixed--${__props.position}`
        ]),
        style: normalizeStyle(__props.fixedStyle)
      }, [
        createElementVNode("div", {
          class: "vant-table-fixed__header",
          style: normalizeStyle(__props.fixedHeaderWrapperStyle)
        }, [
          createElementVNode("table", {
            class: "vant-table vant-table--header",
            style: normalizeStyle(__props.headerTableStyle)
          }, [
            createElementVNode("colgroup", null, [
              __props.showSelection ? (openBlock(), createElementBlock("col", {
                key: 0,
                style: normalizeStyle(__props.selectionColStyle)
              }, null, 4)) : createCommentVNode("", true),
              __props.showExpand ? (openBlock(), createElementBlock("col", {
                key: 1,
                style: normalizeStyle(__props.expandColStyle)
              }, null, 4)) : createCommentVNode("", true),
              (openBlock(true), createElementBlock(Fragment, null, renderList(__props.columns, (header) => {
                return openBlock(), createElementBlock("col", {
                  key: header.key,
                  style: normalizeStyle(__props.getColStyle(header))
                }, null, 4);
              }), 128))
            ]),
            createElementVNode("thead", _hoisted_1$4, [
              createElementVNode("tr", {
                class: normalizeClass(["vant-thead-row", `vant-thead-row--${__props.position}`]),
                ref_key: "headerRowRef",
                ref: headerRowRef
              }, [
                __props.showSelection ? (openBlock(), createElementBlock("th", {
                  key: 0,
                  class: normalizeClass(__props.getFixedHeaderClass("selection", __props.position)),
                  style: normalizeStyle(__props.getSelectionHeaderStyle())
                }, [
                  createElementVNode("div", _hoisted_2$3, [
                    createElementVNode("div", _hoisted_3$3, [
                      !__props.isRadioMode ? (openBlock(), createBlock(_sfc_main$6, {
                        key: 0,
                        "model-value": __props.isAllSelected,
                        indeterminate: __props.isIndeterminate,
                        "onUpdate:modelValue": __props.handleSelectAll,
                        disabled: !__props.selectableRows.length || __props.allRowsDisabled
                      }, null, 8, ["model-value", "indeterminate", "onUpdate:modelValue", "disabled"])) : (openBlock(), createElementBlock("span", _hoisted_4$3, "选择"))
                    ])
                  ])
                ], 6)) : createCommentVNode("", true),
                __props.showExpand ? (openBlock(), createElementBlock("th", {
                  key: 1,
                  class: normalizeClass(__props.getFixedHeaderClass("expand", __props.position)),
                  style: normalizeStyle(__props.getExpandHeaderStyle())
                }, _cache[8] || (_cache[8] = [
                  createElementVNode("div", { class: "vant-th__content" }, null, -1)
                ]), 6)) : createCommentVNode("", true),
                (openBlock(true), createElementBlock(Fragment, null, renderList(__props.columns, (header) => {
                  return openBlock(), createElementBlock("th", {
                    key: header.key,
                    class: normalizeClass(__props.getFixedHeaderClass(header, __props.position)),
                    style: normalizeStyle(__props.getFixedHeaderStyle(header)),
                    "data-key": header.key,
                    ref_for: true,
                    ref: (el) => __props.setHeaderElementRef(el, header.key, __props.position)
                  }, [
                    createElementVNode("div", {
                      class: "vant-th__content",
                      onClick: ($event) => __props.handleSort(header)
                    }, [
                      createElementVNode("span", _hoisted_7$2, toDisplayString(header.label), 1),
                      header.sortable ? (openBlock(), createElementBlock("div", _hoisted_8$2, [
                        (openBlock(), createElementBlock("svg", _hoisted_9$2, [
                          createElementVNode("path", {
                            class: normalizeClass([
                              "vant-sort-icon__asc",
                              {
                                "vant-sort-icon--active": __props.sortConfig.key === header.key && __props.sortConfig.direction === "asc"
                              }
                            ]),
                            d: "M3.96569 4C3.60932 4 3.43086 3.56914 3.68284 3.31716L5.71716 1.28284C5.87337 1.12663 6.12663 1.12663 6.28284 1.28284L8.31716 3.31716C8.56914 3.56914 8.39068 4 8.03431 4L3.96569 4Z",
                            "stroke-linejoin": "round"
                          }, null, 2),
                          createElementVNode("path", {
                            class: normalizeClass([
                              "vant-sort-icon__desc",
                              {
                                "vant-sort-icon--active": __props.sortConfig.key === header.key && __props.sortConfig.direction === "desc"
                              }
                            ]),
                            d: "M8.03431 8C8.39068 8 8.56914 8.43086 8.31716 8.68284L6.28284 10.7172C6.12663 10.8734 5.87337 10.8734 5.71716 10.7172L3.68284 8.68284C3.43086 8.43086 3.60932 8 3.96569 8H8.03431Z",
                            "stroke-linejoin": "round"
                          }, null, 2)
                        ]))
                      ])) : createCommentVNode("", true),
                      header.filterable ? (openBlock(), createElementBlock("i", {
                        key: 1,
                        class: normalizeClass(["van-icon van-icon-filter-o vant-th__filter-icon", { "vant-th__filter-icon--active": __props.isFilterActive(header.key) }]),
                        onClick: withModifiers(($event) => __props.toggleFilter(header.key), ["stop"])
                      }, null, 10, _hoisted_10$2)) : createCommentVNode("", true)
                    ], 8, _hoisted_6$2)
                  ], 14, _hoisted_5$2);
                }), 128))
              ], 2)
            ])
          ], 4)
        ], 4),
        createElementVNode("div", {
          class: normalizeClass(["vant-table-fixed__body"]),
          style: normalizeStyle(__props.bodyWrapperStyle),
          ref_key: "bodyWrapperRef",
          ref: bodyWrapperRef,
          onScroll: _cache[0] || (_cache[0] = (...args) => __props.handleFixedColumnScroll && __props.handleFixedColumnScroll(...args)),
          onWheel: _cache[1] || (_cache[1] = (...args) => __props.handleFixedColumnWheel && __props.handleFixedColumnWheel(...args)),
          onTouchstart: _cache[2] || (_cache[2] = (...args) => __props.handleFixedColumnTouchStart && __props.handleFixedColumnTouchStart(...args)),
          onTouchmove: _cache[3] || (_cache[3] = (...args) => __props.handleFixedColumnTouchMove && __props.handleFixedColumnTouchMove(...args)),
          onTouchend: _cache[4] || (_cache[4] = (...args) => __props.handleFixedColumnTouchEnd && __props.handleFixedColumnTouchEnd(...args)),
          onMouseenter: _cache[5] || (_cache[5] = () => __props.handleAreaMouseEnter(__props.position)),
          onMouseleave: _cache[6] || (_cache[6] = () => __props.handleAreaMouseLeave(__props.position))
        }, [
          createElementVNode("table", {
            class: "vant-table vant-table--body",
            style: normalizeStyle(__props.bodyTableStyle)
          }, [
            createElementVNode("colgroup", null, [
              __props.showSelection ? (openBlock(), createElementBlock("col", {
                key: 0,
                style: normalizeStyle(__props.selectionColStyle)
              }, null, 4)) : createCommentVNode("", true),
              __props.showExpand ? (openBlock(), createElementBlock("col", {
                key: 1,
                style: normalizeStyle(__props.expandColStyle)
              }, null, 4)) : createCommentVNode("", true),
              (openBlock(true), createElementBlock(Fragment, null, renderList(__props.columns, (header) => {
                return openBlock(), createElementBlock("col", {
                  key: header.key,
                  style: normalizeStyle(__props.getColStyle(header))
                }, null, 4);
              }), 128))
            ]),
            createElementVNode("tbody", {
              class: "vant-tbody",
              ref_key: "tbodyRef",
              ref: tbodyRef
            }, [
              !__props.filteredAndSortedData || !__props.filteredAndSortedData.length ? (openBlock(), createElementBlock("tr", _hoisted_11$1, [
                createElementVNode("td", {
                  colspan: (__props.showSelection ? 1 : 0) + (__props.showExpand ? 1 : 0) + __props.columns.length,
                  class: "vant-td vant-td--empty"
                }, [
                  createElementVNode("div", _hoisted_13, [
                    createVNode(unref(Empty), {
                      description: __props.hasActiveFilters ? "没有符合条件的数据" : "暂无数据"
                    }, null, 8, ["description"])
                  ])
                ], 8, _hoisted_12)
              ])) : (openBlock(true), createElementBlock(Fragment, { key: 1 }, renderList(__props.filteredAndSortedData, (row, rowIndex) => {
                return openBlock(), createElementBlock(Fragment, {
                  key: __props.getRowKey(row, rowIndex)
                }, [
                  createElementVNode("tr", {
                    class: normalizeClass(__props.getRowClass(rowIndex, row)),
                    style: normalizeStyle(__props.getRowStyle(rowIndex)),
                    "data-row-index": rowIndex,
                    ref_for: true,
                    ref: (el) => __props.setRowElementRef(el, rowIndex, __props.position),
                    onClick: ($event) => {
                      __props.handleSingleRowHighlight($event, rowIndex);
                      __props.handleRowClickLocal(row, rowIndex);
                    },
                    onMouseenter: ($event) => __props.handleRowMouseEnter(rowIndex),
                    onMouseleave: ($event) => __props.handleRowMouseLeave(rowIndex)
                  }, [
                    __props.showSelection ? (openBlock(), createElementBlock("td", {
                      key: 0,
                      class: normalizeClass(__props.getFixedCellClass("selection", row, rowIndex, __props.position)),
                      style: normalizeStyle(__props.getSelectionCellStyle()),
                      onClick: withModifiers(($event) => __props.handleCellSelect(row, rowIndex, $event), ["stop"])
                    }, [
                      createElementVNode("div", _hoisted_16, [
                        !__props.isRadioMode ? (openBlock(), createBlock(_sfc_main$6, {
                          key: 0,
                          "model-value": __props.isRowSelected(row, rowIndex),
                          disabled: __props.isRowDisabled(row, rowIndex),
                          "onUpdate:modelValue": (checked) => __props.handleRowSelect(row, rowIndex, checked)
                        }, null, 8, ["model-value", "disabled", "onUpdate:modelValue"])) : (openBlock(), createBlock(_sfc_main$5, {
                          key: 1,
                          "model-value": __props.isRowSelected(row, rowIndex),
                          disabled: __props.isRowDisabled(row, rowIndex),
                          "onUpdate:modelValue": (checked) => __props.handleRowSelect(row, rowIndex, checked)
                        }, null, 8, ["model-value", "disabled", "onUpdate:modelValue"]))
                      ])
                    ], 14, _hoisted_15)) : createCommentVNode("", true),
                    __props.showExpand ? (openBlock(), createElementBlock("td", {
                      key: 1,
                      class: normalizeClass(__props.getFixedCellClass("expand", row, rowIndex, __props.position)),
                      style: normalizeStyle(__props.getExpandCellStyle()),
                      onClick: withModifiers(($event) => __props.toggleExpand(row, rowIndex), ["stop"])
                    }, [
                      createElementVNode("div", _hoisted_18, [
                        createElementVNode("i", {
                          class: normalizeClass(["van-icon van-icon-arrow vant-td__expand-icon", { "vant-td__expand-icon--expanded": __props.isExpanded(row, rowIndex) }])
                        }, null, 2)
                      ])
                    ], 14, _hoisted_17)) : createCommentVNode("", true),
                    (openBlock(true), createElementBlock(Fragment, null, renderList(__props.columns, (header, colIndex) => {
                      return openBlock(), createElementBlock("td", {
                        key: header.key,
                        class: normalizeClass(__props.getFixedCellClass(header, row, rowIndex, __props.position)),
                        style: normalizeStyle(__props.getFixedCellStyle(header)),
                        "data-key": header.key,
                        onClick: ($event) => {
                          __props.handleSingleRowHighlight($event, rowIndex);
                          __props.handleCellClick(row, header, rowIndex, colIndex, $event);
                        }
                      }, [
                        createElementVNode("div", _hoisted_20, [
                          header.showDataBar && !__props.isRowTotal(row) ? (openBlock(), createElementBlock("div", {
                            key: 0,
                            class: "vant-td__data-bar",
                            style: normalizeStyle(__props.getDataBarStyle(__props.getCellValue(row, header.key), header.key))
                          }, null, 4)) : createCommentVNode("", true),
                          createElementVNode("span", {
                            class: normalizeClass({ "vant-td__link": header.link, "vant-td__text": !header.link })
                          }, [
                            header.renderCell ? (openBlock(), createBlock(resolveDynamicComponent(__props.renderCustomCell(
                              __props.getCellValue(row, header.key),
                              row,
                              header,
                              rowIndex,
                              colIndex
                            )), { key: 0 })) : (openBlock(), createElementBlock(Fragment, { key: 1 }, [
                              createTextVNode(toDisplayString(__props.formatCellValue(__props.getCellValue(row, header.key), header)), 1)
                            ], 64))
                          ], 2)
                        ])
                      ], 14, _hoisted_19);
                    }), 128))
                  ], 46, _hoisted_14),
                  __props.expandable && __props.isExpanded(row, rowIndex) ? (openBlock(), createElementBlock("tr", {
                    key: 0,
                    class: normalizeClass(["vant-tr", "vant-tr--expanded"]),
                    "data-expanded-row-index": rowIndex
                  }, [
                    createElementVNode("td", {
                      colspan: (__props.showSelection ? 1 : 0) + (__props.showExpand ? 1 : 0) + __props.columns.length,
                      class: "vant-td vant-td--expanded vant-td--fixed"
                    }, [
                      createElementVNode("div", _hoisted_23, [
                        createElementVNode("div", _hoisted_24, [
                          createElementVNode("div", _hoisted_25, [
                            __props.columns[0] ? (openBlock(), createElementBlock("div", _hoisted_26, [
                              createElementVNode("div", _hoisted_27, toDisplayString(__props.columns[0].label) + ":", 1),
                              createElementVNode("div", _hoisted_28, toDisplayString(__props.getCellValue(row, __props.columns[0].key)), 1)
                            ])) : createCommentVNode("", true)
                          ])
                        ])
                      ])
                    ], 8, _hoisted_22)
                  ], 8, _hoisted_21)) : createCommentVNode("", true)
                ], 64);
              }), 128))
            ], 512)
          ], 4)
        ], 36),
        __props.enableLoadMore && __props.showLoadMoreUi ? (openBlock(), createElementBlock("div", {
          key: 0,
          class: normalizeClass(["vant-table-load-more", `vant-table-load-more--fixed-${__props.position}`]),
          style: normalizeStyle(__props.fixedColumnLoadMorePositionStyle)
        }, [
          __props.loadMoreLoading ? (openBlock(), createElementBlock("div", _hoisted_29, [
            createVNode(unref(Loading), { size: "16px" }),
            createElementVNode("span", null, toDisplayString(__props.loadMoreLoadingText), 1)
          ])) : __props.loadMoreError ? (openBlock(), createElementBlock("div", {
            key: 1,
            class: "vant-table-load-more__error",
            onClick: _cache[7] || (_cache[7] = ($event) => _ctx.$emit("load-more"))
          }, [
            createElementVNode("span", null, toDisplayString(__props.loadMoreErrorText), 1)
          ])) : __props.loadMoreFinished ? (openBlock(), createElementBlock("div", _hoisted_30, [
            createElementVNode("span", null, toDisplayString(__props.loadMoreFinishedText), 1)
          ])) : (openBlock(), createElementBlock("div", _hoisted_31, [
            createElementVNode("span", null, toDisplayString(__props.loadMoreReadyText), 1)
          ]))
        ], 6)) : createCommentVNode("", true)
      ], 6)) : createCommentVNode("", true);
    };
  }
};
const _hoisted_1$3 = { class: "vant-table-scrollbar-middle" };
const _sfc_main$3 = {
  __name: "HorizontalScrollbar",
  props: {
    showHorizontalScrollbar: Boolean,
    horizontalScrollbarContainerStyle: Object,
    scrollbarWrapperStyle: Object,
    isScrollbarVisible: Boolean,
    isDragging: Boolean,
    scrollbarHandleStyle: Object,
    scrollbarSpaceStyle: Object,
    scrollbarLeftCornerStyle: Object,
    scrollbarRightCornerStyle: Object,
    // Functions
    handleScrollbarTrackClick: Function,
    handleScrollbarMouseDown: Function,
    handleScrollbarMouseEnter: Function,
    handleScrollbarMouseLeave: Function,
    handleScrollToLeft: Function,
    handleScrollToRight: Function
  },
  setup(__props, { expose: __expose }) {
    __expose({
      scrollbarWrapperRef: null,
      scrollbarHandleRef: null
    });
    return (_ctx, _cache) => {
      return __props.showHorizontalScrollbar ? (openBlock(), createElementBlock("div", {
        key: 0,
        class: "vant-table-scroll-x-virtual",
        style: normalizeStyle(__props.horizontalScrollbarContainerStyle)
      }, [
        createElementVNode("div", {
          class: "vant-table-scrollbar-left",
          style: normalizeStyle(__props.scrollbarLeftCornerStyle),
          onClick: _cache[0] || (_cache[0] = (...args) => __props.handleScrollToLeft && __props.handleScrollToLeft(...args))
        }, null, 4),
        createElementVNode("div", _hoisted_1$3, [
          createElementVNode("div", {
            class: "vant-table-scroll-x-wrapper",
            style: normalizeStyle(__props.scrollbarWrapperStyle),
            ref: "scrollbarWrapperRef",
            onClick: _cache[4] || (_cache[4] = (...args) => __props.handleScrollbarTrackClick && __props.handleScrollbarTrackClick(...args))
          }, [
            createElementVNode("div", {
              class: normalizeClass(["vant-table-scroll-x-handle", {
                "vant-table-scroll-x-handle--visible": __props.isScrollbarVisible,
                "vant-table-scroll-x-handle--dragging": __props.isDragging
              }]),
              style: normalizeStyle(__props.scrollbarHandleStyle),
              ref: "scrollbarHandleRef",
              onMousedown: _cache[1] || (_cache[1] = (...args) => __props.handleScrollbarMouseDown && __props.handleScrollbarMouseDown(...args)),
              onMouseenter: _cache[2] || (_cache[2] = (...args) => __props.handleScrollbarMouseEnter && __props.handleScrollbarMouseEnter(...args)),
              onMouseleave: _cache[3] || (_cache[3] = (...args) => __props.handleScrollbarMouseLeave && __props.handleScrollbarMouseLeave(...args))
            }, [
              createElementVNode("div", {
                class: "vant-table-scroll-x-space",
                style: normalizeStyle(__props.scrollbarSpaceStyle)
              }, null, 4)
            ], 38)
          ], 4)
        ]),
        createElementVNode("div", {
          class: "vant-table-scrollbar-right",
          style: normalizeStyle(__props.scrollbarRightCornerStyle),
          onClick: _cache[5] || (_cache[5] = (...args) => __props.handleScrollToRight && __props.handleScrollToRight(...args))
        }, null, 4)
      ], 4)) : createCommentVNode("", true);
    };
  }
};
const _hoisted_1$2 = {
  key: 0,
  class: "vant-table-load-more"
};
const _hoisted_2$2 = {
  key: 0,
  class: "vant-table-load-more__loading"
};
const _hoisted_3$2 = {
  key: 2,
  class: "vant-table-load-more__finished"
};
const _hoisted_4$2 = {
  key: 3,
  class: "vant-table-load-more__ready"
};
const _sfc_main$2 = {
  __name: "LoadMoreIndicator",
  props: {
    enableLoadMore: Boolean,
    showLoadMoreUi: Boolean,
    loadMoreLoading: Boolean,
    loadMoreError: Boolean,
    loadMoreFinished: Boolean,
    loadMoreLoadingText: String,
    loadMoreErrorText: String,
    loadMoreFinishedText: String,
    loadMoreReadyText: String
  },
  emits: ["load-more"],
  setup(__props) {
    return (_ctx, _cache) => {
      return __props.enableLoadMore && __props.showLoadMoreUi ? (openBlock(), createElementBlock("div", _hoisted_1$2, [
        __props.loadMoreLoading ? (openBlock(), createElementBlock("div", _hoisted_2$2, [
          createVNode(unref(Loading), { size: "16px" }),
          createElementVNode("span", null, toDisplayString(__props.loadMoreLoadingText), 1)
        ])) : __props.loadMoreError ? (openBlock(), createElementBlock("div", {
          key: 1,
          class: "vant-table-load-more__error",
          onClick: _cache[0] || (_cache[0] = ($event) => _ctx.$emit("load-more"))
        }, [
          createElementVNode("span", null, toDisplayString(__props.loadMoreErrorText), 1)
        ])) : __props.loadMoreFinished ? (openBlock(), createElementBlock("div", _hoisted_3$2, [
          createElementVNode("span", null, toDisplayString(__props.loadMoreFinishedText), 1)
        ])) : (openBlock(), createElementBlock("div", _hoisted_4$2, [
          createElementVNode("span", null, toDisplayString(__props.loadMoreReadyText), 1)
        ]))
      ])) : createCommentVNode("", true);
    };
  }
};
const _hoisted_1$1 = { style: { "display": "none" } };
const _hoisted_2$1 = { class: "vant-filter-modal" };
const _hoisted_3$1 = { class: "vant-filter-modal__header" };
const _hoisted_4$1 = { class: "vant-filter-modal__title" };
const _hoisted_5$1 = { class: "vant-filter-modal__content" };
const _hoisted_6$1 = { class: "vant-filter-search" };
const _hoisted_7$1 = { class: "vant-filter-v-options" };
const _hoisted_8$1 = { class: "vant-filter-v-option" };
const _hoisted_9$1 = { class: "vant-filter-v-option__text" };
const _hoisted_10$1 = { class: "vant-filter-modal__actions" };
const _sfc_main$1 = {
  __name: "FilterPopup",
  props: {
    headers: Array,
    filterStates: Object,
    filters: Object,
    toggleFilter: Function,
    applyFilter: Function,
    clearFilters: Function
  },
  setup(__props) {
    const props = __props;
    onMounted(() => {
      var _a;
      console.log("🔍 FilterPopup component mounted with props:", {
        headers: (_a = props.headers) == null ? void 0 : _a.length,
        filterStates: props.filterStates,
        filters: props.filters
      });
    });
    const filterableHeaders = computed(() => {
      const headers = (props.headers || []).filter((header) => header.filterable);
      console.log("🔍 FilterPopup filterableHeaders:", headers);
      console.log("🔍 FilterPopup filterStates:", props.filterStates);
      console.log(
        "🔍 FilterPopup should show popups for:",
        Object.fromEntries(
          Object.entries(props.filterStates || {}).map(([k, v]) => [k, v == null ? void 0 : v.show])
        )
      );
      return headers;
    });
    const handleFilterClose = (key) => {
      props.toggleFilter(key);
    };
    const onClickOverlay = () => {
      Object.keys(props.filterStates || {}).forEach((key) => {
        var _a;
        if ((_a = props.filterStates[key]) == null ? void 0 : _a.show) {
          props.toggleFilter(key);
        }
      });
    };
    const getFilteredOptions = (key) => {
      var _a, _b, _c;
      const filter = (_a = props.filters) == null ? void 0 : _a[key];
      if (!filter)
        return [];
      const searchValue = ((_c = (_b = props.filterStates) == null ? void 0 : _b[key]) == null ? void 0 : _c.value) || "";
      if (!searchValue)
        return filter.options || [];
      return (filter.options || []).filter(
        (option) => String(option).toLowerCase().includes(searchValue.toLowerCase())
      );
    };
    const isOptionSelected = (key, option) => {
      var _a, _b, _c;
      return ((_c = (_b = (_a = props.filterStates) == null ? void 0 : _a[key]) == null ? void 0 : _b.selectedValues) == null ? void 0 : _c.includes(option)) || false;
    };
    const toggleFilterOption = (key, option) => {
      var _a;
      if (!((_a = props.filterStates) == null ? void 0 : _a[key]))
        return;
      const selectedValues = props.filterStates[key].selectedValues || [];
      const index = selectedValues.indexOf(option);
      if (index > -1) {
        selectedValues.splice(index, 1);
      } else {
        selectedValues.push(option);
      }
    };
    const selectAllFilterOptions = (key) => {
      var _a, _b, _c, _d;
      if (!((_a = props.filterStates) == null ? void 0 : _a[key]))
        return;
      const allSelected = !((_b = props.filterStates[key].selectedValues) == null ? void 0 : _b.length);
      if (allSelected) {
        props.filterStates[key].selectedValues = [...((_d = (_c = props.filters) == null ? void 0 : _c[key]) == null ? void 0 : _d.options) || []];
      } else {
        props.filterStates[key].selectedValues = [];
      }
    };
    const resetFilter = (key) => {
      var _a;
      if ((_a = props.filterStates) == null ? void 0 : _a[key]) {
        props.filterStates[key].value = "";
        props.filterStates[key].selectedValues = [];
      }
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createElementVNode("div", _hoisted_1$1, toDisplayString(console.log("🔍 FilterPopup template rendering, filterableHeaders:", filterableHeaders.value.length)), 1),
        (openBlock(true), createElementBlock(Fragment, null, renderList(filterableHeaders.value, (header) => {
          var _a;
          return openBlock(), createBlock(Teleport, {
            key: `filter-${header.key}`,
            to: "body"
          }, [
            ((_a = __props.filterStates[header.key]) == null ? void 0 : _a.show) || false ? (openBlock(), createBlock(unref(Popup), {
              key: 0,
              show: __props.filterStates[header.key].show,
              "onUpdate:show": ($event) => __props.filterStates[header.key].show = $event,
              position: "center",
              style: { zIndex: 99999 },
              "lazy-render": true,
              "destroy-on-close": true,
              closeable: "",
              onClickOverlay,
              round: "",
              class: "vant-filter-modal-popup vant-filter-modal-popup--teleport van-overlay"
            }, {
              default: withCtx(() => {
                var _a2, _b;
                return [
                  createElementVNode("div", _hoisted_2$1, [
                    createElementVNode("div", _hoisted_3$1, [
                      createElementVNode("span", _hoisted_4$1, "过滤 " + toDisplayString(header.label), 1),
                      createVNode(unref(Icon), {
                        name: "cross",
                        class: "vant-filter-modal__close",
                        onClick: ($event) => handleFilterClose(header.key)
                      }, null, 8, ["onClick"])
                    ]),
                    createElementVNode("div", _hoisted_5$1, [
                      createElementVNode("div", _hoisted_6$1, [
                        createVNode(unref(Field), {
                          modelValue: __props.filterStates[header.key].value,
                          "onUpdate:modelValue": ($event) => __props.filterStates[header.key].value = $event,
                          placeholder: "搜索...",
                          size: "small",
                          clearable: ""
                        }, null, 8, ["modelValue", "onUpdate:modelValue"])
                      ]),
                      createElementVNode("div", _hoisted_7$1, [
                        createElementVNode("div", _hoisted_8$1, [
                          createVNode(unref(Checkbox), {
                            "model-value": !((_b = (_a2 = __props.filterStates[header.key]) == null ? void 0 : _a2.selectedValues) == null ? void 0 : _b.length),
                            "onUpdate:modelValue": ($event) => selectAllFilterOptions(header.key)
                          }, {
                            default: withCtx(() => _cache[0] || (_cache[0] = [
                              createElementVNode("span", { class: "vant-filter-v-option__text" }, "全部", -1)
                            ])),
                            _: 2,
                            __: [0]
                          }, 1032, ["model-value", "onUpdate:modelValue"])
                        ]),
                        (openBlock(true), createElementBlock(Fragment, null, renderList(getFilteredOptions(header.key), (option) => {
                          return openBlock(), createElementBlock("div", {
                            key: option,
                            class: "vant-filter-v-option"
                          }, [
                            createVNode(unref(Checkbox), {
                              "model-value": isOptionSelected(header.key, option),
                              "onUpdate:modelValue": ($event) => toggleFilterOption(header.key, option)
                            }, {
                              default: withCtx(() => [
                                createElementVNode("span", _hoisted_9$1, toDisplayString(option), 1)
                              ]),
                              _: 2
                            }, 1032, ["model-value", "onUpdate:modelValue"])
                          ]);
                        }), 128))
                      ])
                    ]),
                    createElementVNode("div", _hoisted_10$1, [
                      createVNode(unref(Button), {
                        block: "",
                        onClick: ($event) => resetFilter(header.key)
                      }, {
                        default: withCtx(() => _cache[1] || (_cache[1] = [
                          createTextVNode("重置")
                        ])),
                        _: 2,
                        __: [1]
                      }, 1032, ["onClick"]),
                      createVNode(unref(Button), {
                        block: "",
                        type: "primary",
                        onClick: ($event) => __props.applyFilter(header.key)
                      }, {
                        default: withCtx(() => _cache[2] || (_cache[2] = [
                          createTextVNode("确定")
                        ])),
                        _: 2,
                        __: [2]
                      }, 1032, ["onClick"])
                    ])
                  ])
                ];
              }),
              _: 2
            }, 1032, ["show", "onUpdate:show"])) : createCommentVNode("", true)
          ]);
        }), 128))
      ], 64);
    };
  }
};
const tableProps = {
  headers: { type: Array, required: true, default: () => [] },
  data: { type: Array, required: true, default: () => [] },
  width: { type: [Number, String], default: "100%" },
  height: { type: [Number, String], default: "auto" },
  minWidth: { type: Number, default: 300 },
  totalRowKey: { type: String, default: "isTotal" },
  bordered: { type: Boolean, default: true },
  striped: { type: Boolean, default: false },
  expandable: { type: Boolean, default: false },
  loading: { type: Boolean, default: false },
  sortProp: { type: String, default: null },
  sortType: { type: String, default: null },
  highlightIndex: { type: Number, default: -1 },
  // 高亮颜色配置
  highlightColor: { type: String, default: "#e6f4ff" },
  // 点击高亮背景色
  highlightBorderColor: { type: String, default: "#1677ff" },
  // 点击高亮边框色
  // 复选行高亮颜色配置
  selectedRowColor: { type: String, default: "#e6f4ff" },
  // 复选行背景色
  selectedRowBorderColor: { type: String, default: "#40a9ff" },
  // 复选行边框色
  // 选择功能相关Props
  selectable: { type: Boolean, default: false },
  selectMode: {
    type: String,
    default: "checkbox",
    validator: (v) => ["checkbox", "radio"].includes(v)
  },
  selectOnRowClick: { type: Boolean, default: false },
  preserveSelection: { type: Boolean, default: false },
  selectableFilter: { type: Function, default: null },
  maxSelectCount: { type: Number, default: 0 },
  rowKey: { type: [String, Function], default: "id" },
  selectedKeys: { type: Array, default: () => [] },
  // 加载更多
  enableLoadMore: { type: Boolean, default: false },
  showLoadMoreUi: { type: Boolean, default: false },
  // 是否显示加载更多的UI
  loadMoreLoading: { type: Boolean, default: false },
  loadMoreFinished: { type: Boolean, default: false },
  loadMoreError: { type: Boolean, default: false },
  loadMoreOffset: { type: Number, default: 50 },
  loadMoreLoadingText: { type: String, default: "加载中..." },
  loadMoreFinishedText: { type: String, default: "没有更多了" },
  loadMoreErrorText: { type: String, default: "加载失败，点击重试" },
  loadMoreReadyText: { type: String, default: "上拉加载更多" }
};
const tableEvents = [
  "sort-change",
  "cell-click",
  "row-click",
  "row-mouse-enter",
  "row-mouse-leave",
  "expand-change",
  "load-more",
  "filter-change",
  "update:selected-keys",
  "selection-change",
  "select-all",
  "select",
  "batch-delete",
  "scroll-to-top",
  // 纵向滚动到顶部事件
  "scroll-to-bottom",
  // 纵向滚动到底部事件
  "scroll-to-left",
  // 横向滚动到左边界事件
  "scroll-to-right",
  // 横向滚动到右边界事件
  "scroll"
  // 通用滚动事件
];
const tableConstants = {
  // 尺寸常量
  EXPAND_WIDTH: 40,
  SELECTION_WIDTH: 48,
  SCROLLBAR_HEIGHT: 16,
  MIN_ROW_HEIGHT: 44,
  DEFAULT_HEADER_HEIGHT: 48,
  // 性能配置
  CLICK_DEBOUNCE_TIME: 150,
  SCROLL_DEBOUNCE_TIME: 16,
  RESIZE_DEBOUNCE_TIME: 100,
  // iOS检测正则
  IOS_REGEX: /iPad|iPhone|iPod/,
  // CSS类名
  CSS_CLASSES: {
    WRAPPER: "vant-table-wrapper",
    HEADER: "vant-table-header",
    BODY: "vant-table-body",
    ROW: "vant-tr",
    CELL: "vant-td",
    SELECTED: "vant-tr--selected",
    HOVER: "vant-tr--hover",
    HIGHLIGHTED: "vant-tr--highlighted",
    CHECKBOX_SELECTED: "vant-tr--checkbox-selected",
    IOS_OPTIMIZED: "vant-table--ios-optimized"
  }
};
const debugConfig = {
  // 开发环境检测
  isDevelopment: () => process.env.NODE_ENV === "development",
  // 调试标志 - 可以通过这些标志控制不同类型的日志输出
  enableConsoleLog: false,
  // 改为 false 来减少控制台日志
  enablePerformanceLog: false,
  enableStateLog: false,
  enableScrollLog: false,
  // 新增：控制滚动相关日志
  enableStyleLog: false,
  // 新增：控制样式相关日志
  enableHandlerLog: false,
  // 新增：控制事件处理日志
  // 调试方法名称
  DEBUG_METHODS: [
    "enableDebug",
    "quickDebug",
    "forceHeaderSync",
    "checkAlignment",
    "measureAndSyncHeaderHeight",
    "measureAndSyncRowHeights",
    "testRowHighlight",
    "checkRowElements",
    "forceResetAllRowStates",
    "forceClearSelectedSync",
    "applyRowStateSync",
    "testSingleRowHighlight",
    "forceTestSingleHighlight",
    "checkHighlightState"
  ]
};
function useScrollHandlers(props, emit, bodyRef, leftBodyWrapperRef, rightBodyWrapperRef, headerContentRef, scrollTop, scrollLeft, isDevelopment, layoutWrapperRef, updateShadowState, updateShadowScrollPosition) {
  const isLoadingMore = ref(false);
  const savedScrollPosition = ref(0);
  const savedDataLength = ref(0);
  const savedScrollHeight = ref(0);
  const intoRunScroll = ref(false);
  const lastScrollTop = ref(0);
  const hoveredArea = ref(null);
  const isHovering = ref(false);
  const isSyncing = ref(false);
  if (typeof window !== "undefined") {
    window.testHoverScrollSync = () => {
      console.log("🧪 测试hover滚动同步功能");
      console.log("当前hover状态:", {
        hoveredArea: hoveredArea.value,
        isHovering: isHovering.value
      });
      console.log("🔍 所有ref状态:", {
        bodyRef: !!(bodyRef == null ? void 0 : bodyRef.value),
        leftBodyWrapperRef: !!(leftBodyWrapperRef == null ? void 0 : leftBodyWrapperRef.value),
        rightBodyWrapperRef: !!(rightBodyWrapperRef == null ? void 0 : rightBodyWrapperRef.value),
        headerContentRef: !!(headerContentRef == null ? void 0 : headerContentRef.value)
      });
      if (bodyRef == null ? void 0 : bodyRef.value) {
        console.log("主表格滚动位置:", {
          scrollTop: bodyRef.value.scrollTop,
          scrollLeft: bodyRef.value.scrollLeft
        });
      } else {
        console.warn("⚠️ bodyRef不存在或为null");
      }
      if (leftBodyWrapperRef == null ? void 0 : leftBodyWrapperRef.value) {
        console.log("左固定列滚动位置:", {
          scrollTop: leftBodyWrapperRef.value.scrollTop
        });
      } else {
        console.warn("⚠️ leftBodyWrapperRef不存在或为null");
      }
      if (rightBodyWrapperRef == null ? void 0 : rightBodyWrapperRef.value) {
        console.log("右固定列滚动位置:", {
          scrollTop: rightBodyWrapperRef.value.scrollTop
        });
      } else {
        console.warn("⚠️ rightBodyWrapperRef不存在或为null");
      }
    };
    window.checkScrollHandlerRefs = () => {
      console.log("🔍 检查useScrollHandlers中的ref状态:", {
        bodyRef: {
          exists: !!bodyRef,
          value: !!(bodyRef == null ? void 0 : bodyRef.value),
          type: typeof bodyRef,
          isRef: bodyRef && bodyRef.__v_isRef
        },
        leftBodyWrapperRef: {
          exists: !!leftBodyWrapperRef,
          value: !!(leftBodyWrapperRef == null ? void 0 : leftBodyWrapperRef.value),
          type: typeof leftBodyWrapperRef,
          isRef: leftBodyWrapperRef && leftBodyWrapperRef.__v_isRef
        },
        rightBodyWrapperRef: {
          exists: !!rightBodyWrapperRef,
          value: !!(rightBodyWrapperRef == null ? void 0 : rightBodyWrapperRef.value),
          type: typeof rightBodyWrapperRef,
          isRef: rightBodyWrapperRef && rightBodyWrapperRef.__v_isRef
        },
        headerContentRef: {
          exists: !!headerContentRef,
          value: !!(headerContentRef == null ? void 0 : headerContentRef.value),
          type: typeof headerContentRef,
          isRef: headerContentRef && headerContentRef.__v_isRef
        }
      });
    };
    window.testForcedSync = (scrollTop2 = 100) => {
      console.log(`🧪 强制同步测试 - scrollTop: ${scrollTop2}`);
      vxeStyleAbsoluteSync(scrollTop2, 0, null);
    };
    window.testMainTableDOMQuery = () => {
      console.log("🧪 测试主表格DOM查询");
      const mainBodyElements = document.querySelectorAll(".vant-table-body");
      console.log("🔍 找到的.vant-table-body元素:", mainBodyElements.length);
      mainBodyElements.forEach((element, index) => {
        const isInFixed = !!element.closest(".vant-table-fixed");
        console.log(`元素${index + 1}:`, {
          element,
          className: element.className,
          isInFixed,
          scrollTop: element.scrollTop,
          scrollHeight: element.scrollHeight,
          clientHeight: element.clientHeight,
          canScroll: element.scrollHeight > element.clientHeight
        });
      });
      let mainTableElement = null;
      for (let element of mainBodyElements) {
        if (!element.closest(".vant-table-fixed")) {
          mainTableElement = element;
          break;
        }
      }
      if (mainTableElement) {
        console.log("✅ 成功找到主表格元素:", {
          element: mainTableElement,
          scrollTop: mainTableElement.scrollTop,
          可以设置scrollTop: true
        });
        const originalScrollTop = mainTableElement.scrollTop;
        mainTableElement.scrollTop = 50;
        setTimeout(() => {
          console.log("📊 设置scrollTop测试结果:", {
            原始scrollTop: originalScrollTop,
            设置的scrollTop: 50,
            当前scrollTop: mainTableElement.scrollTop,
            设置成功: mainTableElement.scrollTop === 50
          });
          mainTableElement.scrollTop = originalScrollTop;
        }, 100);
      } else {
        console.warn("⚠️ 未找到主表格元素");
      }
    };
  }
  const vxeStyleAbsoluteSync = (targetScrollTop, targetScrollLeft, skipSource = null) => {
    var _a, _b, _c, _d, _e;
    console.log("🚀 vxeStyleAbsoluteSync 被调用了！", {
      targetScrollTop,
      targetScrollLeft,
      skipSource,
      intoRunScroll: intoRunScroll.value,
      isSyncing: isSyncing.value,
      refsStatus: {
        bodyRef: !!(bodyRef == null ? void 0 : bodyRef.value),
        leftBodyWrapperRef: !!(leftBodyWrapperRef == null ? void 0 : leftBodyWrapperRef.value),
        rightBodyWrapperRef: !!(rightBodyWrapperRef == null ? void 0 : rightBodyWrapperRef.value),
        headerContentRef: !!(headerContentRef == null ? void 0 : headerContentRef.value)
      }
    });
    if (isSyncing.value) {
      console.log("⏭️ 跳过同步 - 正在同步中，防止无限循环");
      return;
    }
    if (intoRunScroll.value) {
      if (isDevelopment.value) {
        console.log("⏭️ 跳过 VXE 同步 - 程序化滚动中", {
          intoRunScroll: intoRunScroll.value
        });
      }
      return;
    }
    isSyncing.value = true;
    if (isLoadingMore.value && isDevelopment.value) {
      console.log("VXE 同步 - 加载更多期间保持表格同步", {
        isLoadingMore: isLoadingMore.value,
        targetScrollTop,
        targetScrollLeft
      });
    }
    const getGlobalMaxScrollTop = () => {
      if (!bodyRef.value)
        return 0;
      const mainScrollHeight = bodyRef.value.scrollHeight;
      const mainClientHeight = bodyRef.value.clientHeight;
      const mainMaxScrollTop = Math.max(0, mainScrollHeight - mainClientHeight);
      let globalMaxScrollTop2 = mainMaxScrollTop;
      if (leftBodyWrapperRef.value) {
        const leftScrollHeight = leftBodyWrapperRef.value.scrollHeight;
        const leftClientHeight = leftBodyWrapperRef.value.clientHeight;
        const leftMaxScrollTop = Math.max(0, leftScrollHeight - leftClientHeight);
        globalMaxScrollTop2 = Math.min(globalMaxScrollTop2, leftMaxScrollTop);
      }
      if (rightBodyWrapperRef.value) {
        const rightScrollHeight = rightBodyWrapperRef.value.scrollHeight;
        const rightClientHeight = rightBodyWrapperRef.value.clientHeight;
        const rightMaxScrollTop = Math.max(0, rightScrollHeight - rightClientHeight);
        globalMaxScrollTop2 = Math.min(globalMaxScrollTop2, rightMaxScrollTop);
      }
      return globalMaxScrollTop2;
    };
    const globalMaxScrollTop = getGlobalMaxScrollTop();
    const totalWidth = ((_a = props.columnsInfo) == null ? void 0 : _a.totalWidth) || ((_c = (_b = props.columnsInfo) == null ? void 0 : _b.value) == null ? void 0 : _c.totalWidth) || 0;
    const containerWidth = ((_d = props.containerWidth) == null ? void 0 : _d.value) || props.containerWidth || 0;
    const maxScrollLeft = Math.max(0, totalWidth - containerWidth);
    console.log("🔍 滚动边界计算调试:", {
      totalWidth,
      containerWidth,
      maxScrollLeft,
      targetScrollLeft,
      globalMaxScrollTop,
      propsKeys: Object.keys(props || {}),
      columnsInfo: props.columnsInfo,
      propsType: typeof props,
      isReactiveProps: !!((_e = props.columnsInfo) == null ? void 0 : _e.value)
    });
    const constrainedScrollTop = Math.max(0, Math.min(globalMaxScrollTop, targetScrollTop || 0));
    const constrainedScrollLeft = Math.max(0, Math.min(maxScrollLeft, targetScrollLeft || 0));
    if (isDevelopment.value) {
      console.log("VXE风格绝对同步:", {
        原始ScrollTop: targetScrollTop,
        约束后ScrollTop: constrainedScrollTop,
        原始ScrollLeft: targetScrollLeft,
        约束后ScrollLeft: constrainedScrollLeft
      });
    }
    console.log("🔍 同步控制调试:", {
      skipSource,
      目标scrollTop: constrainedScrollTop,
      目标scrollLeft: constrainedScrollLeft,
      同步锁状态: isSyncing.value
    });
    let mainTableElement = bodyRef == null ? void 0 : bodyRef.value;
    if (!mainTableElement) {
      const mainBodyElements = document.querySelectorAll(".vant-table-body");
      if (mainBodyElements.length > 0) {
        for (let element of mainBodyElements) {
          if (!element.closest(".vant-table-fixed")) {
            mainTableElement = element;
            if (bodyRef && !bodyRef.value) {
              bodyRef.value = element;
              console.log("✅ 通过DOM查询获取主表格元素并更新bodyRef");
            }
            break;
          }
        }
        if (mainTableElement && !(bodyRef == null ? void 0 : bodyRef.value)) {
          console.log("✅ 通过DOM查询获取主表格元素成功");
        }
      }
    }
    if (mainTableElement) {
      const oldScrollTop = mainTableElement.scrollTop;
      const oldScrollLeft = mainTableElement.scrollLeft;
      mainTableElement.scrollTop = constrainedScrollTop;
      mainTableElement.scrollLeft = constrainedScrollLeft;
      console.log("✅ 同步主表格成功:", {
        oldScrollTop,
        newScrollTop: constrainedScrollTop,
        实际ScrollTop: mainTableElement.scrollTop,
        oldScrollLeft,
        newScrollLeft: constrainedScrollLeft,
        实际ScrollLeft: mainTableElement.scrollLeft,
        同步成功: mainTableElement.scrollTop === constrainedScrollTop,
        使用的方法: (bodyRef == null ? void 0 : bodyRef.value) ? "bodyRef.value" : "DOM查询"
      });
    } else {
      console.log("❌ 跳过主表格同步 (bodyRef和DOM查询都失败)", {
        bodyRefExists: !!bodyRef,
        bodyRefValue: !!(bodyRef == null ? void 0 : bodyRef.value),
        bodyRefType: typeof bodyRef,
        DOMQueryResult: document.querySelectorAll(".vant-table-body").length
      });
    }
    if (headerContentRef == null ? void 0 : headerContentRef.value) {
      headerContentRef.value.scrollLeft = constrainedScrollLeft;
      console.log("✅ 表头滚动同步成功:", {
        constrainedScrollLeft,
        headerContentRefExists: !!headerContentRef.value,
        headerScrollLeft: headerContentRef.value.scrollLeft,
        headerElement: headerContentRef.value,
        headerClassName: headerContentRef.value.className
      });
    } else {
      console.warn("⚠️ 表头滚动同步失败 - headerContentRef不存在", {
        headerContentRef,
        headerContentRefType: typeof headerContentRef,
        headerContentRefValue: headerContentRef.value,
        headerContentRefValueType: typeof headerContentRef.value
      });
      const headerElement = document.querySelector(".vant-table-header__content");
      if (headerElement) {
        const testScrollLeft = targetScrollLeft || 0;
        const originalOverflow = headerElement.style.overflowX;
        headerElement.style.overflowX = "auto";
        headerElement.scrollLeft = testScrollLeft;
        const actualScrollLeft = headerElement.scrollLeft;
        console.log("🔄 通过querySelector同步表头(使用原始scrollLeft):", {
          targetScrollLeft: testScrollLeft,
          constrainedScrollLeft,
          headerElement,
          原始overflow: originalOverflow,
          设置后的scrollLeft: actualScrollLeft,
          headerScrollWidth: headerElement.scrollWidth,
          headerClientWidth: headerElement.clientWidth,
          canScroll: headerElement.scrollWidth > headerElement.clientWidth,
          scrollLeftWorked: actualScrollLeft === testScrollLeft
        });
        if (originalOverflow) {
          headerElement.style.overflowX = originalOverflow;
        }
      } else {
        console.warn("⚠️ 连通过querySelector也找不到表头元素");
      }
    }
    let leftFixedElement = leftBodyWrapperRef == null ? void 0 : leftBodyWrapperRef.value;
    if (!leftFixedElement) {
      const leftFixedElements = document.querySelectorAll(".vant-table-fixed--left .vant-table-fixed__body");
      if (leftFixedElements.length > 0) {
        leftFixedElement = leftFixedElements[0];
        if (leftBodyWrapperRef && !leftBodyWrapperRef.value) {
          leftBodyWrapperRef.value = leftFixedElement;
          console.log("✅ 通过DOM查询获取左固定列元素并更新leftBodyWrapperRef");
        }
      }
    }
    if (leftFixedElement) {
      const oldScrollTop = leftFixedElement.scrollTop;
      leftFixedElement.scrollTop = constrainedScrollTop;
      console.log("✅ 同步左固定列成功:", {
        oldScrollTop,
        newScrollTop: constrainedScrollTop,
        实际ScrollTop: leftFixedElement.scrollTop,
        同步成功: leftFixedElement.scrollTop === constrainedScrollTop,
        使用的方法: (leftBodyWrapperRef == null ? void 0 : leftBodyWrapperRef.value) ? "leftBodyWrapperRef.value" : "DOM查询"
      });
    } else {
      console.log("❌ 跳过左固定列同步 (leftBodyWrapperRef不存在)", {
        leftBodyWrapperRefExists: !!leftBodyWrapperRef,
        leftBodyWrapperRefValue: !!(leftBodyWrapperRef == null ? void 0 : leftBodyWrapperRef.value),
        leftBodyWrapperRefType: typeof leftBodyWrapperRef
      });
    }
    let rightFixedElement = rightBodyWrapperRef == null ? void 0 : rightBodyWrapperRef.value;
    if (!rightFixedElement) {
      const rightFixedElements = document.querySelectorAll(".vant-table-fixed--right .vant-table-fixed__body");
      if (rightFixedElements.length > 0) {
        rightFixedElement = rightFixedElements[0];
        if (rightBodyWrapperRef && !rightBodyWrapperRef.value) {
          rightBodyWrapperRef.value = rightFixedElement;
          console.log("✅ 通过DOM查询获取右固定列元素并更新rightBodyWrapperRef");
        }
      }
    }
    if (rightFixedElement) {
      const oldScrollTop = rightFixedElement.scrollTop;
      rightFixedElement.scrollTop = constrainedScrollTop;
      console.log("✅ 同步右固定列成功:", {
        oldScrollTop,
        newScrollTop: constrainedScrollTop,
        实际ScrollTop: rightFixedElement.scrollTop,
        同步成功: rightFixedElement.scrollTop === constrainedScrollTop,
        使用的方法: (rightBodyWrapperRef == null ? void 0 : rightBodyWrapperRef.value) ? "rightBodyWrapperRef.value" : "DOM查询"
      });
    } else {
      console.log("❌ 跳过右固定列同步 (rightBodyWrapperRef和DOM查询都失败)", {
        rightBodyWrapperRefExists: !!rightBodyWrapperRef,
        rightBodyWrapperRefValue: !!(rightBodyWrapperRef == null ? void 0 : rightBodyWrapperRef.value),
        rightBodyWrapperRefType: typeof rightBodyWrapperRef,
        DOMQueryResult: document.querySelectorAll(".vant-table-fixed--right .vant-table-fixed__body").length
      });
    }
    if (scrollTop && typeof scrollTop.value !== "undefined") {
      scrollTop.value = constrainedScrollTop;
    }
    if (scrollLeft && typeof scrollLeft.value !== "undefined") {
      scrollLeft.value = constrainedScrollLeft;
    }
    isSyncing.value = false;
    console.log("✅ vxeStyleAbsoluteSync 完成，同步锁已释放");
  };
  const handleMainTableWheel = (event) => {
    var _a;
    console.log("🚀 主表格 handleMainTableWheel 被调用了！", {
      deltaY: event.deltaY,
      deltaX: event.deltaX,
      currentScrollTop: (_a = bodyRef.value) == null ? void 0 : _a.scrollTop,
      eventType: "主表格滚轮"
    });
    if (!bodyRef.value)
      return;
    event.preventDefault();
    const currentScrollTop = bodyRef.value.scrollTop;
    const currentScrollLeft = bodyRef.value.scrollLeft;
    const deltaY = event.deltaY;
    const deltaX = event.deltaX;
    const scrollSensitivity = 1;
    const newScrollTop = Math.max(0, currentScrollTop + deltaY * scrollSensitivity);
    const newScrollLeft = Math.max(0, currentScrollLeft + deltaX * scrollSensitivity);
    console.log("🔄 主表格滚轮同步所有容器:", {
      currentScrollTop,
      newScrollTop,
      deltaY,
      deltaX,
      scrollSensitivity
    });
    vxeStyleAbsoluteSync(newScrollTop, newScrollLeft, null);
    if (props.enableLoadMore && deltaY > 0 && !isLoadingMore.value && !props.loadMoreLoading && !props.loadMoreFinished && !props.loadMoreError) {
      const { scrollHeight, clientHeight } = bodyRef.value;
      const distanceFromBottom = scrollHeight - newScrollTop - clientHeight;
      if (distanceFromBottom < props.loadMoreOffset) {
        isLoadingMore.value = true;
        savedScrollPosition.value = newScrollTop;
        if (isDevelopment.value) {
          console.log("🎯【主表格滚轮】触发加载更多，保存位置:", {
            保存的scrollTop: newScrollTop,
            预估行数: Math.floor(newScrollTop / 44) + 1
          });
        }
        emit("load-more");
      }
    }
  };
  const handleFixedColumnScroll = (event) => {
    console.log("🚀 固定列 handleFixedColumnScroll 被调用了！", {
      event,
      target: event.target,
      scrollTop: event.target.scrollTop,
      scrollLeft: event.target.scrollLeft,
      targetClass: event.target.className,
      eventType: "固定列滚动"
    });
    if (bodyRef.value) {
      const currentScrollTop = event.target.scrollTop;
      const currentScrollLeft = bodyRef.value.scrollLeft || 0;
      const isLeftFixed = event.target.closest(".vant-table-fixed--left");
      const isRightFixed = event.target.closest(".vant-table-fixed--right");
      const skipSource = isLeftFixed ? "left" : isRightFixed ? "right" : null;
      console.log("🔄 固定列滚动事件:", {
        scrollTop: currentScrollTop,
        scrollLeft: currentScrollLeft,
        事件源: event.target.className,
        skipSource,
        isLeftFixed,
        isRightFixed,
        即将同步到主表格: true
      });
      vxeStyleAbsoluteSync(currentScrollTop, currentScrollLeft, null);
      if (props.enableLoadMore && currentScrollTop > (bodyRef.value.scrollTop || 0) && !isLoadingMore.value && !props.loadMoreLoading && !props.loadMoreFinished && !props.loadMoreError) {
        const { scrollHeight, clientHeight } = bodyRef.value;
        const distanceFromBottom = scrollHeight - currentScrollTop - clientHeight;
        if (distanceFromBottom < props.loadMoreOffset) {
          isLoadingMore.value = true;
          savedScrollPosition.value = currentScrollTop;
          if (isDevelopment.value) {
            console.log("🎯【固定列滚动】触发加载更多，保存位置:", {
              保存的scrollTop: currentScrollTop,
              当前bodyScrollTop: bodyRef.value.scrollTop,
              预估行数: Math.floor(currentScrollTop / 44) + 1
            });
          }
          emit("load-more");
        }
      }
    }
  };
  const handleFixedColumnWheel = (event) => {
    var _a;
    console.log("🚀 固定列 handleFixedColumnWheel 被调用了！", {
      deltaY: event.deltaY,
      deltaX: event.deltaX,
      currentScrollTop: (_a = bodyRef.value) == null ? void 0 : _a.scrollTop,
      eventType: "固定列滚轮"
    });
    if (!bodyRef.value)
      return;
    event.preventDefault();
    const isLeftFixed = event.target.closest(".vant-table-fixed--left");
    const isRightFixed = event.target.closest(".vant-table-fixed--right");
    const sourceInfo = isLeftFixed ? "左固定列" : isRightFixed ? "右固定列" : "未知固定列";
    const currentScrollTop = bodyRef.value.scrollTop;
    const currentScrollLeft = bodyRef.value.scrollLeft;
    const deltaY = event.deltaY;
    const deltaX = event.deltaX;
    const scrollSensitivity = 1;
    const newScrollTop = Math.max(0, currentScrollTop + deltaY * scrollSensitivity);
    const newScrollLeft = Math.max(0, currentScrollLeft + deltaX * scrollSensitivity);
    console.log("🔄 固定列滚轮同步所有容器:", {
      currentScrollTop,
      newScrollTop,
      deltaY,
      deltaX,
      scrollSensitivity,
      sourceInfo
    });
    vxeStyleAbsoluteSync(newScrollTop, newScrollLeft, null);
    if (props.enableLoadMore && deltaY > 0 && !isLoadingMore.value && !props.loadMoreLoading && !props.loadMoreFinished && !props.loadMoreError) {
      const { scrollHeight, clientHeight } = bodyRef.value;
      const distanceFromBottom = scrollHeight - newScrollTop - clientHeight;
      if (distanceFromBottom < props.loadMoreOffset) {
        isLoadingMore.value = true;
        savedScrollPosition.value = newScrollTop;
        if (isDevelopment.value) {
          console.log("🎯【固定列滚轮】触发加载更多，保存位置:", {
            保存的scrollTop: newScrollTop,
            预估行数: Math.floor(newScrollTop / 44) + 1
          });
        }
        emit("load-more");
      }
    }
  };
  const handleScroll = (event) => {
    console.log("🚀 主表格 handleScroll 被调用了！", {
      event,
      target: event.target,
      scrollTop: event.target.scrollTop,
      scrollLeft: event.target.scrollLeft,
      targetClass: event.target.className,
      eventType: "主表格滚动"
    });
    const actualBodyElement = bodyRef.value || event.target;
    if (!actualBodyElement) {
      console.warn("⚠️ 既没有bodyRef.value也没有event.target");
      return;
    }
    const currentScrollTop = actualBodyElement.scrollTop;
    const currentScrollLeft = actualBodyElement.scrollLeft;
    console.log("🔄 主表格滚动事件:", {
      scrollTop: currentScrollTop,
      scrollLeft: currentScrollLeft,
      headerContentRef: !!headerContentRef.value,
      使用的元素: bodyRef.value ? "bodyRef.value" : "event.target"
    });
    console.log("🔍 scrollLeft引用调试（handleScroll中）:", {
      scrollLeft引用: scrollLeft,
      scrollLeft类型: typeof scrollLeft,
      scrollLeft当前值: scrollLeft == null ? void 0 : scrollLeft.value,
      scrollLeft是否为RefImpl: scrollLeft && scrollLeft.__v_isRef,
      参数个数: arguments.length
    });
    if (scrollLeft && typeof scrollLeft.value !== "undefined") {
      const oldScrollLeft = scrollLeft.value;
      scrollLeft.value = currentScrollLeft;
      console.log("✅ 直接更新 scrollLeft.value:", {
        旧值: oldScrollLeft,
        新值: currentScrollLeft,
        滚动差值: currentScrollLeft - oldScrollLeft
      });
    }
    if (scrollTop && typeof scrollTop.value !== "undefined") {
      const oldScrollTop = scrollTop.value;
      scrollTop.value = currentScrollTop;
      console.log("✅ 直接更新 scrollTop.value:", {
        旧值: oldScrollTop,
        新值: currentScrollTop,
        滚动差值: currentScrollTop - oldScrollTop
      });
    }
    if (typeof document !== "undefined") {
      const tableWrapper = document.querySelector(".vant-table-wrapper");
      if (tableWrapper) {
        tableWrapper.dataset.scrollLeft = currentScrollLeft.toString();
        console.log("✅ 强制更新DOM scrollLeft dataset:", currentScrollLeft);
      }
      const scrollbarHandle = document.querySelector(".vant-table-scroll-x-handle");
      const scrollbarWrapper = document.querySelector(".vant-table-scroll-x-wrapper");
      if (scrollbarHandle && scrollbarWrapper) {
        const wrapperWidth = scrollbarWrapper.clientWidth;
        const handleWidth = scrollbarHandle.offsetWidth;
        const tableBody = document.querySelector(".vant-table-body");
        if (tableBody) {
          const maxScrollLeft = Math.max(0, tableBody.scrollWidth - tableBody.clientWidth);
          if (maxScrollLeft > 0) {
            const scrollProgress = currentScrollLeft / maxScrollLeft;
            const maxHandleLeft = wrapperWidth - handleWidth;
            const handleLeft = scrollProgress * maxHandleLeft;
            scrollbarHandle.style.left = `${handleLeft}px`;
            console.log("✅ 直接设置滚动条手柄位置:", {
              currentScrollLeft,
              maxScrollLeft,
              scrollProgress,
              handleLeft,
              wrapperWidth,
              handleWidth
            });
          }
        }
      }
    }
    console.log("🔥 即将调用 vxeStyleAbsoluteSync");
    if (updateShadowScrollPosition) {
      updateShadowScrollPosition(currentScrollLeft);
      console.log("✅ 调用了updateShadowScrollPosition函数，滚动位置:", currentScrollLeft);
    }
    vxeStyleAbsoluteSync(currentScrollTop, currentScrollLeft, "main");
    if (updateShadowState && layoutWrapperRef) {
      updateShadowState(layoutWrapperRef);
      console.log("✅ 调用了updateShadowState函数");
    }
    if (props.enableLoadMore && !isLoadingMore.value && !props.loadMoreLoading && !props.loadMoreFinished && !props.loadMoreError) {
      const { scrollHeight: scrollHeight2, clientHeight: clientHeight2 } = actualBodyElement;
      const distanceFromBottom = scrollHeight2 - currentScrollTop - clientHeight2;
      if (distanceFromBottom < props.loadMoreOffset) {
        isLoadingMore.value = true;
        savedScrollPosition.value = currentScrollTop;
        if (isDevelopment.value) {
          console.log("🎯【主表格滚动】触发加载更多，保存位置:", {
            保存的scrollTop: currentScrollTop,
            预估行数: Math.floor(currentScrollTop / 44) + 1
          });
        }
        emit("load-more");
      }
    }
    const { scrollHeight, clientHeight, scrollWidth, clientWidth } = actualBodyElement;
    const tolerance = 5;
    if (currentScrollTop <= tolerance) {
      emit("scroll-to-top", {
        scrollTop: currentScrollTop,
        scrollLeft: currentScrollLeft,
        scrollHeight,
        clientHeight,
        scrollWidth,
        clientWidth,
        element: actualBodyElement
      });
    }
    if (scrollHeight - currentScrollTop - clientHeight <= tolerance) {
      emit("scroll-to-bottom", {
        scrollTop: currentScrollTop,
        scrollLeft: currentScrollLeft,
        scrollHeight,
        clientHeight,
        scrollWidth,
        clientWidth,
        element: actualBodyElement
      });
    }
    if (currentScrollLeft <= tolerance) {
      emit("scroll-to-left", {
        scrollTop: currentScrollTop,
        scrollLeft: currentScrollLeft,
        scrollHeight,
        clientHeight,
        scrollWidth,
        clientWidth,
        element: actualBodyElement
      });
    }
    if (scrollWidth - currentScrollLeft - clientWidth <= tolerance) {
      emit("scroll-to-right", {
        scrollTop: currentScrollTop,
        scrollLeft: currentScrollLeft,
        scrollHeight,
        clientHeight,
        scrollWidth,
        clientWidth,
        element: actualBodyElement
      });
    }
    emit("scroll", {
      scrollTop: currentScrollTop,
      scrollLeft: currentScrollLeft,
      scrollHeight,
      clientHeight,
      scrollWidth,
      clientWidth,
      element: actualBodyElement
    });
  };
  const handleFixedColumnTouchStart = (event) => {
    if (isDevelopment.value) {
      console.log("🔄 固定列触摸开始");
    }
  };
  const handleFixedColumnTouchMove = (event) => {
    if (isDevelopment.value) {
      console.log("🔄 固定列触摸移动");
    }
  };
  const handleFixedColumnTouchEnd = (event) => {
    if (isDevelopment.value) {
      console.log("🔄 固定列触摸结束");
    }
  };
  const handleAreaMouseEnter = (area) => {
    hoveredArea.value = area;
    isHovering.value = true;
    if (isDevelopment.value) {
      console.log(`🎯 鼠标进入${area === "main" ? "主表格" : area === "left" ? "左固定列" : "右固定列"}区域`);
    }
  };
  const handleAreaMouseLeave = (area) => {
    if (hoveredArea.value === area) {
      hoveredArea.value = null;
      isHovering.value = false;
      if (isDevelopment.value) {
        console.log(`🎯 鼠标离开${area === "main" ? "主表格" : area === "left" ? "左固定列" : "右固定列"}区域`);
      }
    }
  };
  const handleMainTableTouchStart = (event) => {
    if (isDevelopment.value) {
      console.log("🔄 主表格触摸开始");
    }
  };
  const handleMainTableTouchMove = (event) => {
    if (isDevelopment.value) {
      console.log("🔄 主表格触摸移动");
    }
  };
  const handleMainTableTouchEnd = (event) => {
    if (isDevelopment.value) {
      console.log("🔄 主表格触摸结束");
    }
  };
  return {
    // 状态
    isLoadingMore,
    savedScrollPosition,
    savedDataLength,
    savedScrollHeight,
    intoRunScroll,
    lastScrollTop,
    hoveredArea,
    isHovering,
    isSyncing,
    // 方法
    vxeStyleAbsoluteSync,
    handleScroll,
    handleMainTableWheel,
    handleMainTableTouchStart,
    handleMainTableTouchMove,
    handleMainTableTouchEnd,
    handleFixedColumnScroll,
    handleFixedColumnWheel,
    handleFixedColumnTouchStart,
    handleFixedColumnTouchMove,
    handleFixedColumnTouchEnd,
    handleAreaMouseEnter,
    handleAreaMouseLeave
  };
}
function useLoadMore(props, bodyRef, leftBodyWrapperRef, rightBodyWrapperRef, scrollTop, scrollLeft, filteredAndSortedData, measureAndSyncHeaderHeight, measureAndSyncRowHeights, isDevelopment, isLoadingMore, savedScrollPosition, savedDataLength, savedScrollHeight, lastScrollTop, intoRunScroll) {
  watch(
    () => props.loadMoreLoading,
    (newLoading, oldLoading) => {
      var _a, _b, _c;
      if (newLoading && !oldLoading) {
        if (!isLoadingMore.value) {
          isLoadingMore.value = true;
          if (savedScrollPosition.value <= 0) {
            savedScrollPosition.value = ((_a = bodyRef.value) == null ? void 0 : _a.scrollTop) || 0;
          }
        }
        lastScrollTop.value = savedScrollPosition.value;
        if (isDevelopment.value) {
          console.log("🔧【Watch监听器】加载开始，位置保护:", {
            当前bodyScrollTop: ((_b = bodyRef.value) == null ? void 0 : _b.scrollTop) || 0,
            保存的位置: savedScrollPosition.value,
            isLoadingMore: isLoadingMore.value,
            是否覆盖: savedScrollPosition.value <= 0 ? "是" : "否(保护已有位置)",
            预估保存行数: savedScrollPosition.value > 0 ? Math.floor(savedScrollPosition.value / 44) + 1 : 0
          });
        }
        const beforeDataLength = filteredAndSortedData.value.length;
        const beforeScrollHeight = ((_c = bodyRef.value) == null ? void 0 : _c.scrollHeight) || 0;
        if (isDevelopment.value) {
          console.log("监听器 - 加载更多开始:", {
            已保存位置: savedScrollPosition.value,
            数据长度: beforeDataLength,
            scrollHeight: beforeScrollHeight,
            isLoadingMore: isLoadingMore.value
          });
        }
        savedDataLength.value = beforeDataLength;
        savedScrollHeight.value = beforeScrollHeight;
      }
      if (oldLoading && !newLoading && isLoadingMore.value) {
        measureAndSyncRowHeights();
        nextTick(() => {
          var _a2, _b2, _c2, _d;
          const isIPhone = /iPhone/i.test(navigator.userAgent);
          const mainScrollTop = ((_a2 = bodyRef.value) == null ? void 0 : _a2.scrollTop) || 0;
          const leftScrollTop = ((_b2 = leftBodyWrapperRef.value) == null ? void 0 : _b2.scrollTop) || 0;
          const rightScrollTop = ((_c2 = rightBodyWrapperRef.value) == null ? void 0 : _c2.scrollTop) || 0;
          if (isDevelopment.value) {
            console.log("【调试】加载更多完成后的自然位置:", {
              保存的位置: savedScrollPosition.value,
              主表格当前位置: mainScrollTop,
              左固定列当前位置: leftScrollTop,
              右固定列当前位置: rightScrollTop,
              主表格差异: mainScrollTop - savedScrollPosition.value,
              左固定列差异: leftScrollTop - savedScrollPosition.value
            });
          }
          if (isIPhone && bodyRef.value) {
            const targetPosition = savedScrollPosition.value;
            if (isDevelopment.value) {
              console.log("【iPhone优化恢复】开始处理:", {
                保存位置: targetPosition,
                当前主表格位置: mainScrollTop,
                当前左固定列位置: leftScrollTop,
                当前scrollHeight: bodyRef.value.scrollHeight
              });
            }
            const forcePosition = (position) => {
              if (bodyRef.value) {
                bodyRef.value.scrollTop = position;
                scrollTop.value = position;
              }
              if (leftBodyWrapperRef.value) {
                leftBodyWrapperRef.value.scrollTop = position;
              }
              if (rightBodyWrapperRef.value) {
                rightBodyWrapperRef.value.scrollTop = position;
              }
            };
            forcePosition(targetPosition);
            setTimeout(() => {
              var _a3;
              forcePosition(targetPosition);
              if (isDevelopment.value) {
                console.log("【iPhone优化恢复】关键时机设置:", {
                  目标: targetPosition,
                  实际: ((_a3 = bodyRef.value) == null ? void 0 : _a3.scrollTop) || 0
                });
              }
            }, 0);
            if (isDevelopment.value) {
              console.log("【iPhone优化恢复】初始设置完成:", {
                目标位置: targetPosition,
                立即读取位置: bodyRef.value.scrollTop
              });
            }
          } else {
            const targetPosition = savedScrollPosition.value;
            const leftColumnAccurate = Math.abs(leftScrollTop - targetPosition) <= 2;
            const mainTableInaccurate = Math.abs(mainScrollTop - targetPosition) > 5;
            if (leftColumnAccurate && mainTableInaccurate && bodyRef.value) {
              if (isDevelopment.value) {
                console.log("【PC端修正】主表格位置:", {
                  从: mainScrollTop,
                  到: targetPosition,
                  修正差距: Math.abs(mainScrollTop - targetPosition)
                });
              }
              const getGlobalMaxScrollTop = () => {
                if (!bodyRef.value)
                  return 0;
                const mainMaxScrollTop = bodyRef.value.scrollHeight - bodyRef.value.clientHeight;
                let globalMaxScrollTop2 = mainMaxScrollTop;
                if (leftBodyWrapperRef.value) {
                  const leftMaxScrollTop = leftBodyWrapperRef.value.scrollHeight - leftBodyWrapperRef.value.clientHeight;
                  globalMaxScrollTop2 = Math.min(globalMaxScrollTop2, leftMaxScrollTop);
                }
                if (rightBodyWrapperRef.value) {
                  const rightMaxScrollTop = rightBodyWrapperRef.value.scrollHeight - rightBodyWrapperRef.value.clientHeight;
                  globalMaxScrollTop2 = Math.min(globalMaxScrollTop2, rightMaxScrollTop);
                }
                return Math.max(0, globalMaxScrollTop2);
              };
              const globalMaxScrollTop = getGlobalMaxScrollTop();
              const safeTargetPosition = Math.max(0, Math.min(globalMaxScrollTop, targetPosition));
              bodyRef.value.scrollTop = safeTargetPosition;
              scrollTop.value = safeTargetPosition;
              if (leftBodyWrapperRef.value) {
                leftBodyWrapperRef.value.scrollTop = safeTargetPosition;
              }
              if (rightBodyWrapperRef.value) {
                rightBodyWrapperRef.value.scrollTop = safeTargetPosition;
              }
              const newMainScrollTop = ((_d = bodyRef.value) == null ? void 0 : _d.scrollTop) || 0;
              if (isDevelopment.value) {
                console.log("【PC端修正】位置修正结果:", {
                  原始目标位置: targetPosition,
                  安全目标位置: safeTargetPosition,
                  修正后主表格位置: newMainScrollTop,
                  是否成功: Math.abs(newMainScrollTop - safeTargetPosition) <= 2
                });
              }
            }
          }
          isLoadingMore.value = false;
          intoRunScroll.value = false;
          savedDataLength.value = 0;
          savedScrollHeight.value = 0;
        });
      }
    },
    { immediate: false }
  );
}
function useSelection(props, emit, filteredAndSortedData, getRowKey, isDevelopment, updateSelectionHighlight) {
  const selectedKeysSet = ref(/* @__PURE__ */ new Set());
  const selectedRows = computed(() => {
    if (!props.selectable)
      return [];
    return filteredAndSortedData.value.filter((row, index) => {
      const key = getRowKey(row, index);
      return selectedKeysSet.value.has(key);
    });
  });
  const selectedRowKeys = computed(() => {
    return Array.from(selectedKeysSet.value);
  });
  const handleRowSelect = (row, rowIndex, checked) => {
    const key = getRowKey(row, rowIndex);
    if (checked) {
      selectedKeysSet.value.add(key);
    } else {
      selectedKeysSet.value.delete(key);
    }
    if (isDevelopment.value) {
      console.log("Row select:", {
        key,
        checked,
        selectedCount: selectedKeysSet.value.size
      });
    }
    const selectedKeysList = Array.from(selectedKeysSet.value);
    const selectedRowData = filteredAndSortedData.value.filter((row2, index) => {
      const rowKey = getRowKey(row2, index);
      return selectedKeysSet.value.has(rowKey);
    });
    emit("selection-change", {
      selectedRowKeys: selectedKeysList,
      selectedRows: selectedRowData,
      currentRow: row,
      currentRowKey: key,
      checked
    });
    if (updateSelectionHighlight && typeof updateSelectionHighlight === "function") {
      updateSelectionHighlight(selectedRowData, getRowKey, filteredAndSortedData);
    }
  };
  const handleRowClick = (row, rowIndex) => {
    if (!props.selectable)
      return;
    const key = getRowKey(row, rowIndex);
    const currentSelected = selectedKeysSet.value.has(key);
    handleRowSelect(row, rowIndex, !currentSelected);
  };
  const handleSelectAll = (checked) => {
    if (checked) {
      filteredAndSortedData.value.forEach((row, index) => {
        const key = getRowKey(row, index);
        selectedKeysSet.value.add(key);
      });
    } else {
      selectedKeysSet.value.clear();
    }
    if (isDevelopment.value) {
      console.log("Select all:", {
        checked,
        selectedCount: selectedKeysSet.value.size
      });
    }
    const selectedRowData = filteredAndSortedData.value.filter((row, index) => {
      const rowKey = getRowKey(row, index);
      return selectedKeysSet.value.has(rowKey);
    });
    if (checked) {
      const selectedKeysList = Array.from(selectedKeysSet.value);
      emit("select-all", {
        selectedRowKeys: selectedKeysList,
        selectedRows: selectedRowData,
        checked: true
      });
    } else {
      const selectedKeysList = Array.from(selectedKeysSet.value);
      emit("select-all", {
        selectedRowKeys: selectedKeysList,
        selectedRows: selectedRowData,
        checked: false
      });
    }
    if (updateSelectionHighlight && typeof updateSelectionHighlight === "function") {
      updateSelectionHighlight(selectedRowData, getRowKey, filteredAndSortedData);
    }
  };
  const clearSelection = () => {
    selectedKeysSet.value.clear();
    if (isDevelopment.value) {
      console.log("Clear all selections");
    }
    emit("selection-change", {
      selectedRowKeys: [],
      selectedRows: [],
      currentRow: null,
      currentRowKey: null,
      checked: false
    });
    if (updateSelectionHighlight && typeof updateSelectionHighlight === "function") {
      updateSelectionHighlight([], getRowKey, filteredAndSortedData);
    }
  };
  const isRowSelected = (row, rowIndex) => {
    if (!props.selectable)
      return false;
    const key = getRowKey(row, rowIndex);
    return selectedKeysSet.value.has(key);
  };
  const isRowDisabled = (row, rowIndex) => {
    if (typeof props.disabledRowKeys === "function") {
      return props.disabledRowKeys(row, rowIndex);
    }
    if (Array.isArray(props.disabledRowKeys)) {
      const key = getRowKey(row, rowIndex);
      return props.disabledRowKeys.includes(key);
    }
    return false;
  };
  const isAllSelected = computed(() => {
    if (!props.selectable || filteredAndSortedData.value.length === 0)
      return false;
    return filteredAndSortedData.value.every((row, index) => {
      const key = getRowKey(row, index);
      return selectedKeysSet.value.has(key);
    });
  });
  const isIndeterminate = computed(() => {
    if (!props.selectable || filteredAndSortedData.value.length === 0)
      return false;
    const selectedCount = filteredAndSortedData.value.filter((row, index) => {
      const key = getRowKey(row, index);
      return selectedKeysSet.value.has(key);
    }).length;
    return selectedCount > 0 && selectedCount < filteredAndSortedData.value.length;
  });
  const selectableRows = computed(() => {
    return filteredAndSortedData.value.filter((row, index) => !isRowDisabled(row, index));
  });
  const allRowsDisabled = computed(() => {
    if (filteredAndSortedData.value.length === 0)
      return true;
    return filteredAndSortedData.value.every((row, index) => isRowDisabled(row, index));
  });
  const handleCellSelect = (row, rowIndex, event) => {
    if (isRowDisabled(row, rowIndex))
      return;
    const currentlySelected = isRowSelected(row, rowIndex);
    handleRowSelect(row, rowIndex, !currentlySelected);
  };
  return {
    // 状态
    selectedKeysSet,
    selectedRows,
    selectedRowKeys,
    isAllSelected,
    isIndeterminate,
    selectableRows,
    allRowsDisabled,
    // 方法
    handleRowSelect,
    handleRowClick,
    handleSelectAll,
    clearSelection,
    isRowSelected,
    isRowDisabled,
    handleCellSelect
  };
}
function useTableEvents(bodyRef, leftBodyWrapperRef, rightBodyWrapperRef, scrollTop, scrollLeft, vxeStyleAbsoluteSync, getGlobalMaxScrollTop, updateShadowState, isDevelopment, emit, props, isLoadingMore, savedScrollPosition) {
  let fixedColumnTouchStartY = 0;
  let fixedColumnTouchStartScrollTop = 0;
  let isFixedColumnTouching = false;
  let touchStartTime = 0;
  let mainTableTouchStartY = 0;
  let mainTableTouchStartX = 0;
  let mainTableTouchStartScrollTop = 0;
  let mainTableTouchStartScrollLeft = 0;
  let isMainTableTouching = false;
  let mainTableTouchStartTime = 0;
  const handleFixedColumnTouchStart = (event) => {
    var _a, _b;
    if (!bodyRef.value)
      return;
    const touch = event.touches[0];
    fixedColumnTouchStartY = touch.clientY;
    fixedColumnTouchStartScrollTop = bodyRef.value.scrollTop;
    isFixedColumnTouching = true;
    touchStartTime = Date.now();
    if (isDevelopment.value) {
      console.log("Fixed column touch start:", {
        startY: fixedColumnTouchStartY,
        startScrollTop: fixedColumnTouchStartScrollTop,
        target: (_b = (_a = event.target.closest("tr")) == null ? void 0 : _a.dataset) == null ? void 0 : _b.rowIndex
      });
    }
    event.preventDefault();
  };
  const handleFixedColumnTouchMove = (event) => {
    if (!isFixedColumnTouching || !bodyRef.value)
      return;
    const touch = event.touches[0];
    const deltaY = fixedColumnTouchStartY - touch.clientY;
    const newScrollTop = fixedColumnTouchStartScrollTop + deltaY;
    const globalMaxScrollTop = getGlobalMaxScrollTop();
    const constrainedScrollTop = Math.max(0, Math.min(globalMaxScrollTop, newScrollTop));
    vxeStyleAbsoluteSync(constrainedScrollTop, bodyRef.value.scrollLeft || 0);
    updateShadowState();
    if (isDevelopment.value) {
      console.log("Fixed column touch move:", {
        deltaY,
        newScrollTop,
        constrainedScrollTop,
        globalMaxScrollTop
      });
    }
    event.preventDefault();
  };
  const handleFixedColumnTouchEnd = (event) => {
    if (!isFixedColumnTouching || !bodyRef.value)
      return;
    const touchEndTime = Date.now();
    const touchDuration = touchEndTime - touchStartTime;
    const finalScrollTop = bodyRef.value.scrollTop;
    if (props.enableLoadMore && touchDuration < 1e3 && !isLoadingMore.value && !props.loadMoreLoading && !props.loadMoreFinished && !props.loadMoreError) {
      const { scrollHeight, clientHeight } = bodyRef.value;
      const distanceFromBottom = scrollHeight - finalScrollTop - clientHeight;
      if (distanceFromBottom < props.loadMoreOffset) {
        if (isDevelopment.value) {
          console.log("Fixed column touch triggered load more:", {
            touchDuration,
            finalScrollTop,
            distanceFromBottom,
            loadMoreOffset: props.loadMoreOffset
          });
        }
        isLoadingMore.value = true;
        savedScrollPosition.value = finalScrollTop;
        emit("load-more");
      }
    }
    if (isDevelopment.value) {
      console.log("Fixed column touch end:", {
        touchDuration,
        finalScrollTop,
        startScrollTop: fixedColumnTouchStartScrollTop,
        scrollDelta: finalScrollTop - fixedColumnTouchStartScrollTop
      });
    }
    isFixedColumnTouching = false;
    fixedColumnTouchStartY = 0;
    fixedColumnTouchStartScrollTop = 0;
    touchStartTime = 0;
    event.preventDefault();
  };
  const handleMainTableTouchStart = (event) => {
    if (!bodyRef.value)
      return;
    const touch = event.touches[0];
    mainTableTouchStartY = touch.clientY;
    mainTableTouchStartX = touch.clientX;
    mainTableTouchStartScrollTop = bodyRef.value.scrollTop;
    mainTableTouchStartScrollLeft = bodyRef.value.scrollLeft;
    isMainTableTouching = true;
    mainTableTouchStartTime = Date.now();
    if (isDevelopment.value) {
      console.log("Main table touch start:", {
        startY: mainTableTouchStartY,
        startX: mainTableTouchStartX,
        startScrollTop: mainTableTouchStartScrollTop,
        startScrollLeft: mainTableTouchStartScrollLeft
      });
    }
  };
  const handleMainTableTouchMove = (event) => {
    var _a;
    if (!isMainTableTouching || !bodyRef.value)
      return;
    const touch = event.touches[0];
    const deltaY = mainTableTouchStartY - touch.clientY;
    const deltaX = mainTableTouchStartX - touch.clientX;
    const newScrollTop = mainTableTouchStartScrollTop + deltaY;
    const newScrollLeft = mainTableTouchStartScrollLeft + deltaX;
    const globalMaxScrollTop = getGlobalMaxScrollTop();
    const maxScrollLeft = Math.max(0, (((_a = props.columnsInfo) == null ? void 0 : _a.totalWidth) || 0) - (props.containerWidth || 0));
    const constrainedScrollTop = Math.max(0, Math.min(globalMaxScrollTop, newScrollTop));
    const constrainedScrollLeft = Math.max(0, Math.min(maxScrollLeft, newScrollLeft));
    vxeStyleAbsoluteSync(constrainedScrollTop, constrainedScrollLeft);
    updateShadowState();
    if (isDevelopment.value) {
      console.log("Main table touch move:", {
        deltaY,
        deltaX,
        newScrollTop,
        newScrollLeft,
        constrainedScrollTop,
        constrainedScrollLeft
      });
    }
  };
  const handleMainTableTouchEnd = (event) => {
    if (!isMainTableTouching || !bodyRef.value)
      return;
    const touchEndTime = Date.now();
    const touchDuration = touchEndTime - mainTableTouchStartTime;
    const finalScrollTop = bodyRef.value.scrollTop;
    const finalScrollLeft = bodyRef.value.scrollLeft;
    if (props.enableLoadMore && touchDuration < 1e3 && !isLoadingMore.value && !props.loadMoreLoading && !props.loadMoreFinished && !props.loadMoreError) {
      const { scrollHeight, clientHeight } = bodyRef.value;
      const distanceFromBottom = scrollHeight - finalScrollTop - clientHeight;
      if (distanceFromBottom < props.loadMoreOffset) {
        if (isDevelopment.value) {
          console.log("Main table touch triggered load more:", {
            touchDuration,
            finalScrollTop,
            distanceFromBottom,
            loadMoreOffset: props.loadMoreOffset
          });
        }
        isLoadingMore.value = true;
        savedScrollPosition.value = finalScrollTop;
        emit("load-more");
      }
    }
    if (isDevelopment.value) {
      console.log("Main table touch end:", {
        touchDuration,
        finalScrollTop,
        finalScrollLeft,
        scrollTopDelta: finalScrollTop - mainTableTouchStartScrollTop,
        scrollLeftDelta: finalScrollLeft - mainTableTouchStartScrollLeft
      });
    }
    isMainTableTouching = false;
    mainTableTouchStartY = 0;
    mainTableTouchStartX = 0;
    mainTableTouchStartScrollTop = 0;
    mainTableTouchStartScrollLeft = 0;
    mainTableTouchStartTime = 0;
  };
  return {
    handleFixedColumnTouchStart,
    handleFixedColumnTouchMove,
    handleFixedColumnTouchEnd,
    handleMainTableTouchStart,
    handleMainTableTouchMove,
    handleMainTableTouchEnd
  };
}
function useTableFilters(props, rawData, columnsInfo, isDevelopment) {
  const filterStates = ref({});
  const activeFilters = ref({});
  const initializeFilters = () => {
    var _a;
    if (!((_a = columnsInfo.value) == null ? void 0 : _a.computedHeaders))
      return;
    columnsInfo.value.computedHeaders.forEach((header) => {
      if (header.filterable) {
        if (!filterStates.value[header.key]) {
          filterStates.value[header.key] = {
            show: false,
            value: "",
            options: header.filterOptions || []
          };
        }
      }
    });
  };
  watch(() => {
    var _a;
    return (_a = columnsInfo.value) == null ? void 0 : _a.computedHeaders;
  }, initializeFilters, { immediate: true, deep: true });
  const toggleFilter = (key) => {
    var _a;
    console.log("🔍 toggleFilter called with key:", key);
    if (!filterStates.value[key]) {
      filterStates.value[key] = {
        show: false,
        value: "",
        options: []
      };
    }
    filterStates.value[key].show = !filterStates.value[key].show;
    console.log("🔍 Filter state after toggle:", {
      key,
      filterState: filterStates.value[key],
      showValue: (_a = filterStates.value[key]) == null ? void 0 : _a.show,
      allFilterStates: filterStates.value,
      allShowValues: Object.fromEntries(
        Object.entries(filterStates.value).map(([k, v]) => [k, v == null ? void 0 : v.show])
      )
    });
    if (isDevelopment.value) {
      console.log("Toggle filter:", {
        key,
        show: filterStates.value[key].show
      });
    }
  };
  const isFilterActive = (key) => {
    return !!(activeFilters.value[key] && (activeFilters.value[key].value && activeFilters.value[key].value.trim() !== "" || activeFilters.value[key].values && activeFilters.value[key].values.length > 0));
  };
  const handleFilterClose = (key) => {
    if (filterStates.value[key]) {
      filterStates.value[key].show = false;
    }
  };
  const toggleFilterOption = (key, option) => {
    if (!activeFilters.value[key]) {
      activeFilters.value[key] = {
        values: []
      };
    }
    const values = activeFilters.value[key].values || [];
    const index = values.indexOf(option.value);
    if (index === -1) {
      values.push(option.value);
    } else {
      values.splice(index, 1);
    }
    activeFilters.value[key] = {
      ...activeFilters.value[key],
      values: [...values]
    };
    if (isDevelopment.value) {
      console.log("Toggle filter option:", {
        key,
        option: option.value,
        currentValues: activeFilters.value[key].values
      });
    }
  };
  const applyTextFilter = (key) => {
    var _a;
    const filterState = filterStates.value[key];
    if (!filterState)
      return;
    const value = (_a = filterState.value) == null ? void 0 : _a.trim();
    if (value) {
      activeFilters.value[key] = {
        type: "text",
        value
      };
    } else {
      delete activeFilters.value[key];
    }
    filterState.show = false;
    if (isDevelopment.value) {
      console.log("Apply text filter:", {
        key,
        value,
        activeFilters: Object.keys(activeFilters.value)
      });
    }
  };
  const resetFilter = (key) => {
    delete activeFilters.value[key];
    if (filterStates.value[key]) {
      filterStates.value[key].value = "";
      filterStates.value[key].show = false;
    }
    if (isDevelopment.value) {
      console.log("Reset filter:", key);
    }
  };
  const clearFilters = () => {
    activeFilters.value = {};
    Object.keys(filterStates.value).forEach((key) => {
      if (filterStates.value[key]) {
        filterStates.value[key].value = "";
        filterStates.value[key].show = false;
      }
    });
    if (isDevelopment.value) {
      console.log("Clear all filters");
    }
  };
  const hasActiveFilters = computed(() => {
    return Object.keys(activeFilters.value).length > 0;
  });
  const filteredData = computed(() => {
    let filtered = rawData.value || [];
    Object.entries(activeFilters.value).forEach(([key, filter]) => {
      if (filter.type === "text" && filter.value) {
        const searchValue = filter.value.toLowerCase();
        filtered = filtered.filter((row) => {
          const cellValue = row[key];
          if (cellValue === null || cellValue === void 0)
            return false;
          return String(cellValue).toLowerCase().includes(searchValue);
        });
      } else if (filter.values && filter.values.length > 0) {
        filtered = filtered.filter((row) => {
          const cellValue = row[key];
          return filter.values.includes(cellValue);
        });
      }
    });
    return filtered;
  });
  return {
    // 状态
    filterStates,
    activeFilters,
    hasActiveFilters,
    filteredData,
    // 方法
    toggleFilter,
    isFilterActive,
    handleFilterClose,
    toggleFilterOption,
    applyTextFilter,
    resetFilter,
    clearFilters,
    initializeFilters
  };
}
function useTableSorting(props, emit, filteredData, isDevelopment) {
  const sortConfig = ref({
    key: props.sortProp,
    direction: props.sortType
  });
  const handleSort = (header) => {
    if (!header.sortable)
      return;
    const currentKey = sortConfig.value.key;
    const currentDirection = sortConfig.value.direction;
    if (currentKey === header.key) {
      if (currentDirection === "asc") {
        sortConfig.value.direction = "desc";
      } else if (currentDirection === "desc") {
        sortConfig.value.key = "";
        sortConfig.value.direction = "";
      } else {
        sortConfig.value.direction = "asc";
      }
    } else {
      sortConfig.value.key = header.key;
      sortConfig.value.direction = "asc";
    }
    if (isDevelopment.value) {
      console.log("Sort changed:", {
        key: sortConfig.value.key,
        direction: sortConfig.value.direction,
        header: header.key
      });
    }
    emit("sort-change", {
      key: sortConfig.value.key,
      direction: sortConfig.value.direction,
      header
    });
  };
  const sortedData = computed(() => {
    if (!sortConfig.value.key || !sortConfig.value.direction) {
      return filteredData.value;
    }
    const key = sortConfig.value.key;
    const direction = sortConfig.value.direction;
    const sorted = [...filteredData.value].sort((a, b) => {
      let aVal = a[key];
      let bVal = b[key];
      if (aVal === null || aVal === void 0)
        aVal = "";
      if (bVal === null || bVal === void 0)
        bVal = "";
      const aNum = Number(aVal);
      const bNum = Number(bVal);
      if (!isNaN(aNum) && !isNaN(bNum)) {
        return direction === "asc" ? aNum - bNum : bNum - aNum;
      }
      const aStr = String(aVal).toLowerCase();
      const bStr = String(bVal).toLowerCase();
      if (direction === "asc") {
        return aStr.localeCompare(bStr, "zh-CN");
      } else {
        return bStr.localeCompare(aStr, "zh-CN");
      }
    });
    if (isDevelopment.value) {
      console.log("Data sorted:", {
        key,
        direction,
        originalLength: filteredData.value.length,
        sortedLength: sorted.length
      });
    }
    return sorted;
  });
  const resetSort = () => {
    sortConfig.value.key = "";
    sortConfig.value.direction = "";
    if (isDevelopment.value) {
      console.log("Sort reset");
    }
    emit("sort-change", {
      key: "",
      direction: "",
      header: null
    });
  };
  const setSort = (key, direction) => {
    sortConfig.value.key = key;
    sortConfig.value.direction = direction;
    if (isDevelopment.value) {
      console.log("Sort set:", { key, direction });
    }
    emit("sort-change", {
      key,
      direction,
      header: null
    });
  };
  return {
    // 状态
    sortConfig,
    sortedData,
    // 方法
    handleSort,
    resetSort,
    setSort
  };
}
function useTableState(props, emit, bodyRef, leftBodyWrapperRef, rightBodyWrapperRef, layoutWrapperRef, isDevelopment) {
  const hoveredRowIndex = ref(-1);
  const selectedRowIndex = ref(-1);
  const expandedRows = ref(/* @__PURE__ */ new Set());
  const isDragging = ref(false);
  const dragStartX = ref(0);
  const dragStartScrollLeft = ref(0);
  const isScrollbarVisible = ref(false);
  const autoHideTimer = ref(null);
  const smoothScrollAnimation = ref(null);
  const containerWidth = ref(0);
  const scrollTop = ref(0);
  const scrollLeft = ref(0);
  const lastScrollTop = ref(0);
  const lastScrollLeft = ref(0);
  const headerHeight = ref(48);
  const isHeaderMeasuring = ref(false);
  const isInitialHeaderHeightSet = ref(false);
  const isRowMeasuring = ref(false);
  const rowHeightMap = ref(/* @__PURE__ */ new Map());
  const expandedRowHeightMap = ref(/* @__PURE__ */ new Map());
  const headerElementRefs = ref({});
  const rowElementRefs = ref({});
  const setHeaderElementRef = (el, key, position) => {
    if (el) {
      if (!headerElementRefs.value[key]) {
        headerElementRefs.value[key] = {};
      }
      headerElementRefs.value[key][position] = el;
    }
  };
  const setRowElementRef = (el, rowIndex, position) => {
    if (el) {
      if (!rowElementRefs.value[rowIndex]) {
        rowElementRefs.value[rowIndex] = {};
      }
      rowElementRefs.value[rowIndex][position] = el;
    } else {
      console.warn(`❌ setRowElementRef: 第${rowIndex}行${position}区域元素为空`);
    }
  };
  const isRowExpanded = (row, rowIndex) => {
    const getRowKey = (row2, rowIndex2) => {
      if (typeof props.rowKey === "function") {
        return props.rowKey(row2, rowIndex2);
      }
      return row2[props.rowKey] || `row-${rowIndex2}`;
    };
    const key = getRowKey(row, rowIndex);
    return expandedRows.value.has(key);
  };
  const toggleRowExpansion = (row, rowIndex) => {
    const getRowKey = (row2, rowIndex2) => {
      if (typeof props.rowKey === "function") {
        return props.rowKey(row2, rowIndex2);
      }
      return row2[props.rowKey] || `row-${rowIndex2}`;
    };
    const key = getRowKey(row, rowIndex);
    if (expandedRows.value.has(key)) {
      expandedRows.value.delete(key);
    } else {
      expandedRows.value.add(key);
    }
    emit("expand-change", {
      row,
      rowIndex,
      expanded: expandedRows.value.has(key),
      expandedKeys: Array.from(expandedRows.value)
    });
    nextTick(() => {
      setTimeout(() => {
        measureAndSyncRowHeights();
      }, 50);
    });
  };
  const forceHeaderHeightSync = () => {
    console.log("🔧 手动强制表头高度同步");
    isHeaderMeasuring.value = false;
    measureAndSyncHeaderHeight(true);
  };
  const resetHeaderHeightLock = () => {
    isInitialHeaderHeightSet.value = false;
    console.log("🔓 表头高度锁定已重置，下次调用将重新计算");
  };
  const measureAndSyncHeaderHeight = (forceRecalculation = false) => {
    console.log("🚀 measureAndSyncHeaderHeight 被调用，参数:", {
      forceRecalculation,
      isHeaderMeasuring: isHeaderMeasuring.value,
      isInitialHeaderHeightSet: isInitialHeaderHeightSet.value,
      headerHeight: headerHeight.value
    });
    console.log("🔒 表头高度同步已被禁用以保持原有样式");
    return;
  };
  const measureAndSyncRowHeights = () => {
    if (isRowMeasuring.value)
      return;
    isRowMeasuring.value = true;
    nextTick(() => {
      try {
        const newRowHeightMap = /* @__PURE__ */ new Map();
        const newExpandedRowHeightMap = /* @__PURE__ */ new Map();
        Object.keys(rowElementRefs.value).forEach((rowIndex) => {
          ["main", "left", "right"].forEach((position) => {
            var _a;
            const rowEl = (_a = rowElementRefs.value[rowIndex]) == null ? void 0 : _a[position];
            if (rowEl) {
              rowEl.style.height = "auto";
              rowEl.style.minHeight = "auto";
              rowEl.style.maxHeight = "none";
              rowEl.querySelectorAll("td").forEach((td) => {
                td.style.height = "auto";
                td.style.minHeight = "auto";
                td.style.maxHeight = "none";
              });
            }
          });
        });
        requestAnimationFrame(() => {
          Object.keys(rowElementRefs.value).forEach((rowIndex) => {
            const heights = [];
            const positions = ["main", "left", "right"];
            positions.forEach((position) => {
              var _a;
              const rowEl = (_a = rowElementRefs.value[rowIndex]) == null ? void 0 : _a[position];
              if (rowEl) {
                const rect = rowEl.getBoundingClientRect();
                heights.push(rect.height);
              }
            });
            if (heights.length > 0) {
              const maxHeight = Math.max(...heights, 44);
              newRowHeightMap.set(parseInt(rowIndex), maxHeight);
              positions.forEach((position) => {
                var _a;
                const rowEl = (_a = rowElementRefs.value[rowIndex]) == null ? void 0 : _a[position];
                if (rowEl) {
                  rowEl.style.height = `${maxHeight}px`;
                  rowEl.style.minHeight = `${maxHeight}px`;
                  rowEl.style.maxHeight = `${maxHeight}px`;
                  rowEl.querySelectorAll("td").forEach((td) => {
                    td.style.height = `${maxHeight}px`;
                    td.style.minHeight = `${maxHeight}px`;
                    td.style.maxHeight = `${maxHeight}px`;
                  });
                }
              });
            }
          });
          expandedRows.value.forEach((expandedKey) => {
            console.log("处理展开行:", expandedKey);
            const expandedRowElements = document.querySelectorAll(`[data-expanded-row-index]`);
            expandedRowElements.forEach((expandedEl) => {
              const rowIndex = expandedEl.getAttribute("data-expanded-row-index");
              if (rowIndex) {
                const heights = [];
                const expandedEls = document.querySelectorAll(`[data-expanded-row-index="${rowIndex}"]`);
                expandedEls.forEach((el) => {
                  const rect = el.getBoundingClientRect();
                  heights.push(rect.height);
                });
                if (heights.length > 0) {
                  const maxHeight = Math.max(...heights, 60);
                  newExpandedRowHeightMap.set(parseInt(rowIndex), maxHeight);
                  expandedEls.forEach((el) => {
                    el.style.height = `${maxHeight}px`;
                    el.style.minHeight = `${maxHeight}px`;
                    el.style.maxHeight = `${maxHeight}px`;
                    el.querySelectorAll("td").forEach((td) => {
                      td.style.height = `${maxHeight}px`;
                      td.style.minHeight = `${maxHeight}px`;
                      td.style.maxHeight = `${maxHeight}px`;
                    });
                  });
                }
              }
            });
          });
          rowHeightMap.value = newRowHeightMap;
          expandedRowHeightMap.value = newExpandedRowHeightMap;
        });
      } finally {
        setTimeout(() => {
          isRowMeasuring.value = false;
        }, 50);
      }
    });
  };
  const updateContainerWidth = () => {
    if (bodyRef.value) {
      const parentElement = bodyRef.value.parentElement;
      if (parentElement) {
        const rect = parentElement.getBoundingClientRect();
        containerWidth.value = Math.max(rect.width, props.minWidth);
      }
    } else if (typeof props.width === "number") {
      containerWidth.value = props.width;
    }
  };
  watch(() => expandedRows.value, () => {
    nextTick(() => {
      setTimeout(() => {
        measureAndSyncRowHeights();
      }, 50);
    });
  }, { deep: true });
  watch(() => props.width, () => {
    nextTick(() => {
      updateContainerWidth();
      setTimeout(() => {
        measureAndSyncHeaderHeight();
      }, 50);
    });
  });
  return {
    // 状态
    hoveredRowIndex,
    selectedRowIndex,
    expandedRows,
    isDragging,
    dragStartX,
    dragStartScrollLeft,
    isScrollbarVisible,
    autoHideTimer,
    smoothScrollAnimation,
    containerWidth,
    scrollTop,
    scrollLeft,
    lastScrollTop,
    lastScrollLeft,
    headerHeight,
    isHeaderMeasuring,
    isInitialHeaderHeightSet,
    isRowMeasuring,
    rowHeightMap,
    expandedRowHeightMap,
    headerElementRefs,
    rowElementRefs,
    // 方法
    setHeaderElementRef,
    setRowElementRef,
    isRowExpanded,
    toggleRowExpansion,
    measureAndSyncHeaderHeight,
    forceHeaderHeightSync,
    resetHeaderHeightLock,
    measureAndSyncRowHeights,
    updateContainerWidth
  };
}
function useTableComputed(props, containerWidth, scrollTop, scrollLeft, headerHeight, filteredAndSortedData, rowHeightMap) {
  const EXPAND_WIDTH = 40;
  const SELECTION_WIDTH = 48;
  const SCROLLBAR_HEIGHT = 15;
  const columnsInfo = computed(() => {
    const totalWidth = containerWidth.value || 375;
    const leftFixedColumns = [];
    const rightFixedColumns = [];
    const normalColumns = [];
    props.headers.forEach((header) => {
      if (header.fixed === "left") {
        leftFixedColumns.push({ ...header });
      } else if (header.fixed === "right") {
        rightFixedColumns.push({ ...header });
      } else {
        normalColumns.push({ ...header });
      }
    });
    let leftFixedWidth = 0;
    leftFixedColumns.forEach((col) => {
      const width = col.width || 120;
      col.computedWidth = width;
      leftFixedWidth += width;
    });
    let rightFixedWidth = 0;
    rightFixedColumns.forEach((col) => {
      const width = col.width || (col.key === "action" || col.key === "actions" || col.key === "操作" ? 80 : 120);
      col.computedWidth = width;
      rightFixedWidth += width;
    });
    const expandWidth = props.expandable ? EXPAND_WIDTH : 0;
    const selectionWidth = props.selectable ? SELECTION_WIDTH : 0;
    const fixedColumnsWidth = leftFixedWidth + rightFixedWidth + expandWidth + selectionWidth;
    const containerAvailableWidth = Math.max(0, totalWidth - fixedColumnsWidth);
    const fixedContentWidth = normalColumns.reduce((sum, col) => sum + (col.width || 0), 0);
    const flexColumnsCount = normalColumns.filter((col) => !col.width).length;
    const minFlexWidth = flexColumnsCount * 120;
    const minRequiredWidth = fixedContentWidth + minFlexWidth;
    const availableWidth = Math.max(containerAvailableWidth, minRequiredWidth);
    const fixedWidthColumns = [];
    const flexColumns = [];
    normalColumns.forEach((col) => {
      if (col.width) {
        fixedWidthColumns.push({ ...col, computedWidth: col.width });
      } else {
        flexColumns.push({ ...col });
      }
    });
    console.log("🔍 列分类调试:", {
      totalWidth,
      fixedColumnsWidth,
      leftFixedWidth,
      rightFixedWidth,
      expandWidth,
      selectionWidth,
      containerAvailableWidth,
      fixedContentWidth,
      flexColumnsCount,
      minFlexWidth,
      minRequiredWidth,
      availableWidth,
      normalColumns: normalColumns.map((c) => ({ key: c.key, width: c.width })),
      fixedWidthColumns: fixedWidthColumns.map((c) => ({ key: c.key, width: c.computedWidth })),
      flexColumns: flexColumns.map((c) => ({ key: c.key }))
    });
    if (flexColumns.length > 0) {
      const fixedWidthTotal = fixedWidthColumns.reduce((sum, col) => sum + col.computedWidth, 0);
      const actualAvailableWidth = Math.max(containerAvailableWidth, availableWidth);
      const spacingCompensation = 2;
      const remainingWidth = Math.max(0, actualAvailableWidth - fixedWidthTotal - spacingCompensation);
      const flexColumnWidth = Math.max(120, Math.floor(remainingWidth / flexColumns.length));
      const remainder = remainingWidth - flexColumnWidth * flexColumns.length;
      const stableWidth = remainder < 10 ? flexColumnWidth : Math.floor(remainingWidth / flexColumns.length);
      console.log("🔍 弹性列宽度分配（稳定模式）:", {
        containerAvailableWidth,
        availableWidth,
        actualAvailableWidth,
        fixedWidthTotal,
        spacingCompensation,
        remainingWidth,
        flexColumnsCount: flexColumns.length,
        baseFlexColumnWidth: flexColumnWidth,
        remainder,
        stableWidth,
        calculation: `使用稳定宽度: ${stableWidth}px (避免闪现)`
      });
      flexColumns.forEach((col) => {
        col.computedWidth = stableWidth;
        console.log(`🔧 弹性列 ${col.key}: -> ${col.computedWidth}px (稳定)`);
      });
    }
    const computedHeaders = [...leftFixedColumns, ...rightFixedColumns, ...fixedWidthColumns, ...flexColumns].sort((a, b) => {
      const aIndex = props.headers.findIndex((h2) => h2.key === a.key);
      const bIndex = props.headers.findIndex((h2) => h2.key === b.key);
      return aIndex - bIndex;
    });
    const mainHeaders = normalColumns.map((col) => {
      const computedCol = [...fixedWidthColumns, ...flexColumns].find((c) => c.key === col.key);
      return computedCol || col;
    });
    console.log("🔍 主表头调试:", {
      totalNormalColumns: normalColumns.length,
      fixedWidthColumns: fixedWidthColumns.map((c) => ({ key: c.key, width: c.computedWidth })),
      flexColumns: flexColumns.map((c) => ({ key: c.key, width: c.computedWidth })),
      mainHeaders: mainHeaders.map((c) => ({ key: c.key, width: c.computedWidth })),
      mainHeadersCount: mainHeaders.length
    });
    const mainHeadersWidth = mainHeaders.reduce((sum, col) => sum + col.computedWidth, 0);
    const normalColumnsWidth = [...fixedWidthColumns, ...flexColumns].reduce((sum, col) => sum + col.computedWidth, 0);
    const calculatedTotalWidth = leftFixedWidth + rightFixedWidth + normalColumnsWidth + expandWidth + selectionWidth;
    const totalTableWidth = calculatedTotalWidth;
    console.log("🔍 总宽度计算调试:", {
      leftFixedWidth,
      rightFixedWidth,
      normalColumnsWidth,
      expandWidth,
      selectionWidth,
      calculatedTotalWidth,
      totalTableWidth,
      containerWidth: containerWidth.value,
      "应该显示阴影": totalTableWidth > containerWidth.value
    });
    return {
      leftFixedColumns,
      rightFixedColumns,
      computedHeaders,
      mainHeaders,
      // 新增：主表头/主表体使用的非固定列
      mainHeadersWidth,
      // 新增：主表格宽度
      totalWidth: totalTableWidth,
      leftFixedWidth,
      rightFixedWidth,
      normalColumnsWidth,
      containerWidth: containerWidth.value
    };
  });
  const isMobile = computed(() => false);
  const hasLeftFixedContent = computed(() => {
    return props.selectable || props.expandable || columnsInfo.value.leftFixedColumns.length > 0;
  });
  const hasRightFixedColumns = computed(() => {
    return columnsInfo.value.rightFixedColumns.length > 0;
  });
  const leftFixedTotalWidth = computed(() => {
    if (isMobile.value)
      return 0;
    return (props.selectable ? SELECTION_WIDTH : 0) + (props.expandable ? EXPAND_WIDTH : 0) + columnsInfo.value.leftFixedWidth;
  });
  const normalColumnsTotalWidth = computed(() => {
    if (!containerWidth.value)
      return 0;
    const leftWidth = leftFixedTotalWidth.value;
    const rightWidth = hasRightFixedColumns.value ? columnsInfo.value.rightFixedWidth : 0;
    return Math.max(0, containerWidth.value - leftWidth - rightWidth);
  });
  const hasHorizontalScrollbar = computed(() => {
    if (!columnsInfo.value.mainHeadersWidth || !containerWidth.value)
      return false;
    const leftWidth = hasLeftFixedContent.value ? leftFixedTotalWidth.value : 0;
    const rightWidth = hasRightFixedColumns.value ? columnsInfo.value.rightFixedWidth : 0;
    const contentWidth = containerWidth.value - leftWidth - rightWidth;
    const mainTableWidth = columnsInfo.value.mainHeadersWidth;
    return !isMobile.value && mainTableWidth > contentWidth;
  });
  const scrollbarHandleWidth = computed(() => {
    if (!hasHorizontalScrollbar.value)
      return 0;
    const containerW = containerWidth.value;
    const leftFixedW = columnsInfo.value.leftFixedWidth || 0;
    const rightFixedW = columnsInfo.value.rightFixedWidth || 0;
    const mainVisibleWidth = containerW - leftFixedW - rightFixedW;
    const mainContentWidth = columnsInfo.value.mainHeadersWidth || 0;
    const maxScrollLeft = Math.max(0, mainContentWidth - mainVisibleWidth);
    if (maxScrollLeft === 0)
      return mainVisibleWidth;
    if (isMobile.value)
      return containerW;
    const viewportRatio = mainVisibleWidth / mainContentWidth;
    const minHandleWidth = 30;
    const calculatedWidth = mainVisibleWidth * viewportRatio;
    const maxAllowedWidth = mainVisibleWidth * 0.8;
    return Math.max(minHandleWidth, Math.min(calculatedWidth, maxAllowedWidth));
  });
  const scrollbarHandleLeft = computed(() => {
    if (!hasHorizontalScrollbar.value)
      return 0;
    const containerW = containerWidth.value;
    const leftFixedW = columnsInfo.value.leftFixedWidth || 0;
    const rightFixedW = columnsInfo.value.rightFixedWidth || 0;
    const handleWidth = scrollbarHandleWidth.value;
    const mainVisibleWidth = containerW - leftFixedW - rightFixedW;
    const mainContentWidth = columnsInfo.value.mainHeadersWidth || 0;
    const maxScrollLeft = Math.max(0, mainContentWidth - mainVisibleWidth);
    if (maxScrollLeft === 0)
      return 0;
    if (isMobile.value)
      return 0;
    const scrollProgress = scrollLeft.value / maxScrollLeft;
    const isNearRightBoundary = scrollProgress >= 0.98;
    if (isNearRightBoundary) {
      return mainVisibleWidth - handleWidth;
    }
    const availableTrackWidth = mainVisibleWidth - handleWidth;
    const handleLeftInMainArea = scrollProgress * availableTrackWidth;
    if (process.env.NODE_ENV === "development") {
      console.log("🎯 滚动条手柄位置计算:", {
        scrollLeft: scrollLeft.value,
        mainContentWidth,
        containerW,
        maxScrollLeft,
        scrollProgress,
        mainVisibleWidth,
        handleWidth,
        availableTrackWidth,
        handleLeftInMainArea,
        isNearRightBoundary,
        "修复": "VXE-table风格的边界检测和位置计算",
        "计算公式": isNearRightBoundary ? `边界情况: ${mainVisibleWidth} - ${handleWidth} = ${mainVisibleWidth - handleWidth}` : `(${scrollLeft.value} / ${maxScrollLeft}) * ${availableTrackWidth} = ${handleLeftInMainArea}`
      });
    }
    return handleLeftInMainArea;
  });
  const containerStyle = computed(() => {
    const styles = {};
    if (typeof props.width === "string") {
      styles.width = props.width;
      if (props.minWidth) {
        styles.minWidth = `${props.minWidth}px`;
      }
    } else {
      styles.width = `${props.width}px`;
    }
    if (typeof props.height === "string") {
      styles.height = props.height;
    } else {
      styles.height = `${props.height}px`;
    }
    return styles;
  });
  const tableStyle = computed(() => {
    var _a;
    const availableWidth = containerWidth.value || 375;
    const leftWidth = hasLeftFixedContent.value ? leftFixedTotalWidth.value : 0;
    const rightWidth = hasRightFixedColumns.value ? columnsInfo.value.rightFixedWidth : 0;
    const contentWidth = Math.max(200, availableWidth - leftWidth - rightWidth);
    const mainTableWidth = columnsInfo.value.mainHeadersWidth || 0;
    const finalWidth = mainTableWidth <= contentWidth ? contentWidth : mainTableWidth;
    console.log("🔍 表格宽度计算调试:", {
      availableWidth,
      leftWidth,
      rightWidth,
      contentWidth,
      mainTableWidth,
      finalWidth,
      needsScroll: mainTableWidth > contentWidth,
      mainHeaders: (_a = columnsInfo.value.mainHeaders) == null ? void 0 : _a.map((h2) => ({ key: h2.key, width: h2.computedWidth })),
      message: `主表格宽度${mainTableWidth}px，可用空间${contentWidth}px，最终宽度${finalWidth}px${mainTableWidth > contentWidth ? "（需要滚动）" : "（无需滚动）"}`
    });
    return {
      width: `${finalWidth}px`,
      minWidth: `${finalWidth}px`,
      tableLayout: "fixed",
      borderCollapse: "separate",
      borderSpacing: 0
    };
  });
  const bodyWrapperStyle = computed(() => {
    const height = headerHeight.value;
    const loadMoreHeight = props.enableLoadMore && props.showLoadMoreUi ? 60 : 0;
    const scrollbarHeight = 0;
    const paddingBottomWithoutLoadMore = hasHorizontalScrollbar.value ? 35 : 18;
    console.log("hasHorizontalScrollbar=", hasHorizontalScrollbar.value, paddingBottomWithoutLoadMore);
    const result = {
      height: `calc(${typeof props.height === "string" ? props.height : `${props.height}px`} - ${height}px - ${loadMoreHeight}px - ${scrollbarHeight}px)`,
      overflow: "auto",
      marginLeft: hasLeftFixedContent.value ? `${leftFixedTotalWidth.value}px` : "0",
      marginRight: hasRightFixedColumns.value ? `${columnsInfo.value.rightFixedWidth}px` : "0",
      // 🔑 关键修复：添加底部padding避免水平滚动条遮挡最后一行
      // 根据加载更多UI状态设置不同的padding值
      // paddingBottom: (props.enableLoadMore && props.showLoadMoreUi) ? '20px' : '35px'
      paddingBottom: props.enableLoadMore && props.showLoadMoreUi ? "20px" : `${paddingBottomWithoutLoadMore}px`
    };
    console.log("🔍 Main table bodyWrapperStyle debug:", {
      enableLoadMore: props.enableLoadMore,
      showLoadMoreUi: props.showLoadMoreUi,
      hasHorizontalScrollbar: hasHorizontalScrollbar.value,
      loadMoreHeight,
      scrollbarHeight,
      heightFormula: result.height,
      propsHeight: props.height,
      headerHeight: height,
      SCROLLBAR_HEIGHT,
      "paddingBottom方案": {
        "height": "给表格最大高度 282px",
        "paddingBottom": "没有加载更多UI时添加20px底部间距",
        "原因": "水平滚动条overlay在表格内容上方，需要padding推开最后一行"
      },
      "最终计算": {
        "showLoadMoreUi=false": "高度282px + 底部padding20px = 有效高度262px",
        "showLoadMoreUi=true": "高度222px + 底部padding0px = 有效高度222px"
      }
    });
    return result;
  });
  const getRowStyle = (rowIndex) => {
    const height = rowHeightMap.value.get(rowIndex);
    return height ? {
      height: `${height}px`,
      minHeight: `${height}px`,
      maxHeight: `${height}px`
    } : {
      minHeight: "44px"
      // 🔑 关键修复：不设置 maxHeight，允许行根据内容自动撑开
    };
  };
  const getColStyle = (header) => ({
    width: `${header.computedWidth}px`,
    minWidth: `${header.computedWidth}px`,
    maxWidth: `${header.computedWidth}px`
  });
  const getHeaderClass = (header) => {
    const classes = ["vant-th"];
    if (header.sortable) {
      classes.push("vant-th--sortable");
    }
    return classes;
  };
  const getHeaderStyle = (header) => ({
    width: `${header.computedWidth}px`,
    minWidth: `${header.computedWidth}px`,
    maxWidth: `${header.computedWidth}px`,
    textAlign: header.align || "left",
    boxSizing: "border-box"
  });
  const getRowClass = (rowIndex, row) => {
    const classes = ["vant-tr"];
    if (row[props.totalRowKey]) {
      classes.push("vant-tr--total");
    }
    if (props.striped && rowIndex % 2 === 1) {
      classes.push("vant-tr--striped");
    }
    if (props.highlightIndex === rowIndex) {
      classes.push("vant-tr--highlighted");
    }
    return classes;
  };
  return {
    // 计算属性
    columnsInfo,
    isMobile,
    hasLeftFixedContent,
    hasRightFixedColumns,
    leftFixedTotalWidth,
    normalColumnsTotalWidth,
    hasHorizontalScrollbar,
    scrollbarHandleWidth,
    scrollbarHandleLeft,
    containerStyle,
    tableStyle,
    bodyWrapperStyle,
    // 样式方法
    getRowStyle,
    getColStyle,
    getHeaderClass,
    getHeaderStyle,
    getRowClass,
    // 常量
    EXPAND_WIDTH,
    SELECTION_WIDTH,
    SCROLLBAR_HEIGHT
  };
}
function useTableUtils(props, emit, columnsInfo, containerWidth, scrollLeft, hasHorizontalScrollbar, leftFixedTotalWidth, hasRightFixedColumns, scrollbarHandleWidth, scrollbarHandleLeft, isDragging, isScrollbarVisible, SCROLLBAR_HEIGHT) {
  const getCellValue = (row, key) => row[key];
  const isRowTotal = (row) => {
    return row[props.totalRowKey] === true;
  };
  const formatCellValue = (value, column) => {
    if (value == null)
      return "";
    switch (column.type) {
      case "number":
        return typeof value === "number" ? value.toLocaleString() : value;
      case "percent":
        return typeof value === "number" ? `${value}%` : value;
      case "currency":
        return typeof value === "number" ? `¥${value.toLocaleString()}` : value;
      default:
        return value;
    }
  };
  const renderCell = (value, row, column, rowIndex, colIndex, h2) => {
    if (typeof column.renderCell === "function") {
      const result = column.renderCell(value, row, column, rowIndex, colIndex, h2);
      if (result && typeof result === "object" && result.type) {
        return result;
      }
      if (typeof result === "string" || typeof result === "number") {
        return h2("span", result);
      }
      return h2("span", String(value || ""));
    }
    return h2("span", String(value || ""));
  };
  const horizontalScrollbarContainerStyle = computed(() => {
    if (!hasHorizontalScrollbar.value)
      return { display: "none" };
    return {
      position: "absolute",
      bottom: "0px",
      left: 0,
      right: 0,
      height: `${SCROLLBAR_HEIGHT}px`,
      zIndex: 90,
      visibility: hasHorizontalScrollbar.value ? "visible" : "hidden",
      width: "100%",
      background: "#f5f5f5",
      borderTop: "0.5px solid var(--van-border-color)",
      pointerEvents: "auto",
      boxShadow: "0 -1px 3px rgba(0,0,0,0.1)",
      zIndex: 999
    };
  });
  const scrollbarLeftCornerStyle = computed(() => {
    const width = leftFixedTotalWidth.value;
    return {
      width: `${width}px`,
      height: `${SCROLLBAR_HEIGHT}px`,
      backgroundColor: "#f5f5f5",
      borderRight: width > 0 ? "1px solid var(--van-border-color)" : "none",
      flexShrink: 0,
      cursor: width > 0 ? "pointer" : "default"
    };
  });
  const scrollbarRightCornerStyle = computed(() => {
    const rightWidth = hasRightFixedColumns.value ? columnsInfo.value.rightFixedWidth : 0;
    return {
      width: `${rightWidth}px`,
      height: `${SCROLLBAR_HEIGHT}px`,
      backgroundColor: "#f5f5f5",
      borderLeft: rightWidth > 0 ? "1px solid var(--van-border-color)" : "none",
      flexShrink: 0,
      display: "block",
      cursor: rightWidth > 0 ? "pointer" : "default"
    };
  });
  const scrollbarWrapperStyle = computed(() => {
    return {
      position: "absolute",
      left: "0",
      right: "0",
      top: "0",
      bottom: "0",
      height: `${SCROLLBAR_HEIGHT}px`,
      overflow: "hidden",
      backgroundColor: "rgba(249, 249, 249, 0.8)",
      cursor: "pointer",
      width: "100%",
      border: "1px solid rgba(224, 224, 224, 0.6)",
      borderRadius: "8px",
      borderTop: "none",
      boxSizing: "border-box",
      backdropFilter: "blur(2px)",
      transition: "opacity 0.3s ease",
      opacity: isScrollbarVisible.value ? 1 : 0.7
    };
  });
  const scrollbarHandleStyle = computed(() => {
    const handleWidth = scrollbarHandleWidth.value;
    const handleLeft = scrollbarHandleLeft.value;
    if (process.env.NODE_ENV === "development") {
      console.log("🎯 滚动条手柄样式计算:", {
        handleWidth,
        handleLeft,
        "完整样式": {
          left: `${handleLeft}px`,
          width: `${handleWidth}px`
        }
      });
    }
    return {
      position: "absolute",
      top: "2px",
      left: `${handleLeft}px`,
      width: `${handleWidth}px`,
      height: "calc(100% - 4px)",
      cursor: isDragging.value ? "grabbing" : "grab",
      userSelect: "none",
      transition: isDragging.value ? "none" : "left 0.1s ease, opacity 0.3s ease",
      borderRadius: "6px",
      opacity: isScrollbarVisible.value ? 0.9 : 0.6,
      boxShadow: "0 1px 3px rgba(0,0,0,0.1)"
    };
  });
  const scrollbarSpaceStyle = computed(() => {
    return {
      width: "100%",
      height: "100%",
      background: "linear-gradient(135deg, rgba(232, 232, 232, 0.8) 0%, rgba(200, 200, 200, 0.9) 50%, rgba(232, 232, 232, 0.8) 100%)",
      border: "1px solid rgba(208, 208, 208, 0.6)",
      borderRadius: "6px",
      position: "relative",
      boxSizing: "border-box",
      transition: "all 0.2s ease",
      backdropFilter: "blur(1px)"
    };
  });
  const handleCellClick = (row, column, rowIndex, colIndex, value, originalEvent) => {
    emit("cell-click", {
      row,
      column,
      rowIndex,
      colIndex,
      value,
      originalEvent
    });
  };
  const handleRowClick = (row, rowIndex, originalEvent) => {
    emit("row-click", {
      row,
      rowIndex,
      originalEvent
    });
  };
  const handleBatchDelete = (selectedRows, selectedRowKeys) => {
    if (selectedRows.length === 0)
      return;
    emit("batch-delete", {
      selectedRows,
      selectedRowKeys
    });
  };
  return {
    // 数据处理工具
    getCellValue,
    isRowTotal,
    formatCellValue,
    renderCell,
    // 样式计算
    horizontalScrollbarContainerStyle,
    scrollbarLeftCornerStyle,
    scrollbarRightCornerStyle,
    scrollbarWrapperStyle,
    scrollbarHandleStyle,
    scrollbarSpaceStyle,
    // 事件处理
    handleCellClick,
    handleRowClick,
    handleBatchDelete
  };
}
function useScrollbar(bodyRef, scrollLeft, containerWidth, columnsInfo, isDragging, isScrollbarVisible, autoHideTimer, smoothScrollAnimation, syncScroll, updateShadowState) {
  const smoothScrollTo = (targetScrollLeft, duration = 300) => {
    if (smoothScrollAnimation.value) {
      cancelAnimationFrame(smoothScrollAnimation.value);
    }
    const startScrollLeft = scrollLeft.value;
    const distance = targetScrollLeft - startScrollLeft;
    const startTime = performance.now();
    const animate = (currentTime) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const easeProgress = 1 - Math.pow(1 - progress, 4);
      const newScrollLeft = startScrollLeft + distance * easeProgress;
      if (bodyRef.value) {
        bodyRef.value.scrollLeft = newScrollLeft;
        scrollLeft.value = newScrollLeft;
        syncScroll();
        updateShadowState();
      }
      if (progress < 1) {
        smoothScrollAnimation.value = requestAnimationFrame(animate);
      } else {
        smoothScrollAnimation.value = null;
      }
    };
    smoothScrollAnimation.value = requestAnimationFrame(animate);
  };
  const showScrollbar = () => {
    isScrollbarVisible.value = true;
    if (autoHideTimer.value) {
      clearTimeout(autoHideTimer.value);
    }
  };
  const startAutoHideTimer = () => {
    if (autoHideTimer.value) {
      clearTimeout(autoHideTimer.value);
    }
    autoHideTimer.value = setTimeout(() => {
      if (!isDragging.value) {
        isScrollbarVisible.value = false;
      }
    }, 1500);
  };
  const handleScrollbarMouseEnter = () => {
    showScrollbar();
  };
  const handleScrollbarMouseLeave = () => {
    if (!isDragging.value) {
      startAutoHideTimer();
    }
  };
  const handleScrollbarMouseDown = (event) => {
    if (!columnsInfo.value.totalWidth || !containerWidth.value)
      return;
    event.preventDefault();
    event.stopPropagation();
    isDragging.value = true;
    const dragStartX = event.clientX;
    const dragStartScrollLeft = scrollLeft.value;
    showScrollbar();
    const target = event.currentTarget;
    target.style.transform = "scale(1.05)";
    target.style.transition = "transform 0.1s ease";
    const handleMouseMove = (moveEvent) => {
      if (!isDragging.value)
        return;
      moveEvent.preventDefault();
      const deltaX = moveEvent.clientX - dragStartX;
      const leftFixedW = columnsInfo.value.leftFixedWidth || 0;
      const rightFixedW = columnsInfo.value.rightFixedWidth || 0;
      const mainVisibleWidth = containerWidth.value - leftFixedW - rightFixedW;
      const mainContentWidth = columnsInfo.value.mainHeadersWidth || 0;
      const maxScrollLeft = Math.max(0, mainContentWidth - mainVisibleWidth);
      if (maxScrollLeft === 0)
        return;
      const scrollRatio = deltaX / mainVisibleWidth;
      const newScrollLeft = dragStartScrollLeft + scrollRatio * maxScrollLeft;
      const clampedScrollLeft = Math.max(0, Math.min(maxScrollLeft, newScrollLeft));
      if (bodyRef.value) {
        bodyRef.value.scrollLeft = clampedScrollLeft;
      }
      if (document.getSelection) {
        document.getSelection().removeAllRanges();
      }
    };
    const handleMouseUp = () => {
      isDragging.value = false;
      target.style.transform = "";
      target.style.transition = "";
      document.removeEventListener("mousemove", handleMouseMove);
      document.removeEventListener("mouseup", handleMouseUp);
      document.body.style.userSelect = "";
      startAutoHideTimer();
    };
    document.body.style.userSelect = "none";
    document.addEventListener("mousemove", handleMouseMove);
    document.addEventListener("mouseup", handleMouseUp);
  };
  const handleScrollbarTrackClick = (event) => {
    if (!columnsInfo.value.totalWidth || !containerWidth.value || isDragging.value)
      return;
    const trackElement = event.currentTarget.querySelector(".vant-table-scroll-x-wrapper");
    if (!trackElement)
      return;
    const trackRect = trackElement.getBoundingClientRect();
    const clickX = event.clientX - trackRect.left;
    const leftFixedW = columnsInfo.value.leftFixedWidth || 0;
    const rightFixedW = columnsInfo.value.rightFixedWidth || 0;
    const mainVisibleWidth = containerWidth.value - leftFixedW - rightFixedW;
    const mainContentWidth = columnsInfo.value.mainHeadersWidth || 0;
    if (clickX < leftFixedW || clickX > containerWidth.value - rightFixedW) {
      return;
    }
    const maxScrollLeft = Math.max(0, mainContentWidth - mainVisibleWidth);
    if (maxScrollLeft === 0)
      return;
    const clickXInMainArea = clickX - leftFixedW;
    const totalRatio = mainVisibleWidth / mainContentWidth;
    const scrollbarHandleWidth = Math.max(30, mainVisibleWidth * totalRatio);
    const targetLeftInMainArea = Math.max(0, Math.min(mainVisibleWidth - scrollbarHandleWidth, clickXInMainArea - scrollbarHandleWidth / 2));
    const targetScrollLeft = maxScrollLeft > 0 ? targetLeftInMainArea / (mainVisibleWidth - scrollbarHandleWidth) * maxScrollLeft : 0;
    smoothScrollTo(targetScrollLeft, 400);
    showScrollbar();
    startAutoHideTimer();
  };
  const scrollToLeft = () => smoothScrollTo(0);
  const scrollToRight = () => {
    const leftFixedW = columnsInfo.value.leftFixedWidth || 0;
    const rightFixedW = columnsInfo.value.rightFixedWidth || 0;
    const mainVisibleWidth = containerWidth.value - leftFixedW - rightFixedW;
    const mainContentWidth = columnsInfo.value.mainHeadersWidth || 0;
    const maxScrollLeft = Math.max(0, mainContentWidth - mainVisibleWidth);
    smoothScrollTo(maxScrollLeft);
  };
  const scrollToColumn = (columnKey) => {
    const headers = columnsInfo.value.computedHeaders;
    const columnIndex = headers.findIndex((header) => header.key === columnKey);
    if (columnIndex >= 0) {
      let scrollLeft2 = 0;
      for (let i = 0; i < columnIndex; i++) {
        scrollLeft2 += headers[i].computedWidth;
      }
      smoothScrollTo(scrollLeft2);
    }
  };
  return {
    smoothScrollTo,
    showScrollbar,
    startAutoHideTimer,
    handleScrollbarMouseEnter,
    handleScrollbarMouseLeave,
    handleScrollbarMouseDown,
    handleScrollbarTrackClick,
    scrollToLeft,
    scrollToRight,
    scrollToColumn
  };
}
function useTableStyles(props, columnsInfo, leftFixedTotalWidth, hasRightFixedColumns, hasLeftFixedContent, scrollLeft, containerWidth, headerHeight, EXPAND_WIDTH, SELECTION_WIDTH, SCROLLBAR_HEIGHT) {
  if (process.env.NODE_ENV === "development") {
    console.log("🔍 useTableStyles 接收到的 scrollLeft 引用:", {
      scrollLeft引用: scrollLeft,
      scrollLeft类型: typeof scrollLeft,
      scrollLeft当前值: scrollLeft == null ? void 0 : scrollLeft.value,
      scrollLeft是否为RefImpl: scrollLeft && scrollLeft.__v_isRef,
      参数列表长度: arguments.length
    });
  }
  const localScrollLeft = ref(0);
  watch(
    () => scrollLeft.value,
    (newValue) => {
      if (process.env.NODE_ENV === "development") {
        console.log("🔄 useTableStyles watch到scrollLeft变化:", {
          新值: newValue,
          旧值: localScrollLeft.value,
          外部scrollLeft引用: scrollLeft,
          是否相等: newValue === localScrollLeft.value
        });
      }
      localScrollLeft.value = newValue;
    },
    { immediate: true, flush: "sync" }
  );
  const updateShadowState = (layoutWrapperRef) => {
    var _a;
    if (!(layoutWrapperRef == null ? void 0 : layoutWrapperRef.value))
      return;
    const totalWidth = ((_a = columnsInfo.value) == null ? void 0 : _a.totalWidth) || 0;
    const containerWidthValue = containerWidth.value;
    const currentScrollLeft = getCurrentScrollLeft();
    const maxScrollLeft = Math.max(0, totalWidth - containerWidthValue);
    const leftShadowVisible = shouldShowLeftShadow.value;
    const rightShadowVisible = shouldShowRightShadow.value;
    if (process.env.NODE_ENV === "development") {
      console.log("🎯 阴影状态更新:", {
        当前滚动: currentScrollLeft,
        本地滚动: localScrollLeft.value,
        最大滚动: maxScrollLeft,
        总宽度: totalWidth,
        容器宽度: containerWidthValue,
        显示左侧阴影: leftShadowVisible,
        显示右侧阴影: rightShadowVisible,
        有左固定列: hasLeftFixedContent.value,
        有右固定列: hasRightFixedColumns.value,
        外部scrollLeft: scrollLeft.value
      });
    }
  };
  const selectionColStyle = computed(() => ({
    width: `${SELECTION_WIDTH}px`,
    minWidth: `${SELECTION_WIDTH}px`,
    maxWidth: `${SELECTION_WIDTH}px`
  }));
  const getSelectionHeaderStyle = () => ({
    width: `${SELECTION_WIDTH}px`,
    minWidth: `${SELECTION_WIDTH}px`,
    maxWidth: `${SELECTION_WIDTH}px`,
    textAlign: "center"
  });
  const getSelectionCellStyle = () => ({
    width: `${SELECTION_WIDTH}px`,
    minWidth: `${SELECTION_WIDTH}px`,
    maxWidth: `${SELECTION_WIDTH}px`,
    textAlign: "center"
  });
  const expandColStyle = computed(() => ({
    width: `${EXPAND_WIDTH}px`,
    minWidth: `${EXPAND_WIDTH}px`,
    maxWidth: `${EXPAND_WIDTH}px`
  }));
  const shouldHideFixedColumns = computed(() => {
    return false;
  });
  const isScrolledToRight = computed(() => {
    const containerWidthValue = containerWidth.value;
    const totalWidth = columnsInfo.value.totalWidth;
    const maxScrollLeft = Math.max(0, totalWidth - containerWidthValue);
    return localScrollLeft.value >= maxScrollLeft - 5;
  });
  const shadowScrollLeft = ref(0);
  const getCurrentScrollLeft = () => {
    const externalScrollLeft = scrollLeft.value || 0;
    const shadowScrollLeftValue = shadowScrollLeft.value || 0;
    if (externalScrollLeft === 0 && shadowScrollLeftValue > 0) {
      return shadowScrollLeftValue;
    }
    return externalScrollLeft;
  };
  const updateShadowScrollPosition = (scrollLeftValue) => {
    if (typeof scrollLeftValue === "number" && scrollLeftValue >= 0) {
      const oldValue = shadowScrollLeft.value;
      shadowScrollLeft.value = scrollLeftValue;
      if (process.env.NODE_ENV === "development") {
        console.log("🔄 更新阴影滚动位置:", {
          新位置: scrollLeftValue,
          旧位置: oldValue,
          外部scrollLeft: scrollLeft.value,
          更新成功: shadowScrollLeft.value === scrollLeftValue
        });
      }
    }
  };
  const shouldShowLeftShadow = computed(() => {
    var _a;
    if (!hasLeftFixedContent.value)
      return false;
    const containerWidthValue = containerWidth.value;
    const totalWidth = ((_a = columnsInfo.value) == null ? void 0 : _a.totalWidth) || 0;
    const currentScrollLeft = shadowScrollLeft.value;
    scrollLeft.value;
    if (totalWidth <= containerWidthValue) {
      return false;
    }
    const maxScrollLeft = Math.max(0, totalWidth - containerWidthValue);
    const shouldShow = currentScrollLeft > 5;
    if (process.env.NODE_ENV === "development") {
      console.log("🔍 左侧阴影逻辑:", {
        当前滚动: currentScrollLeft,
        外部scrollLeft: scrollLeft.value,
        shadowScrollLeft: shadowScrollLeft.value,
        最大滚动: maxScrollLeft,
        总宽度: totalWidth,
        容器宽度: containerWidthValue,
        显示阴影: shouldShow,
        "🎯关键判断": `${currentScrollLeft} > 5 = ${shouldShow}`,
        "滚动状态": currentScrollLeft === 0 ? "初始位置" : currentScrollLeft > 5 ? "已开始滚动" : "微小滚动"
      });
    }
    return shouldShow;
  });
  const shouldShowRightShadow = computed(() => {
    var _a, _b, _c;
    if (!hasRightFixedColumns.value)
      return false;
    const containerWidthValue = containerWidth.value;
    const totalWidth = ((_a = columnsInfo.value) == null ? void 0 : _a.totalWidth) || 0;
    if (totalWidth <= containerWidthValue) {
      return false;
    }
    const externalScrollLeft = scrollLeft.value || 0;
    const shadowScrollLeft_value = shadowScrollLeft.value || 0;
    const localScrollLeft_value = localScrollLeft.value || 0;
    const currentScrollLeft = Math.max(externalScrollLeft, shadowScrollLeft_value, localScrollLeft_value);
    const leftFixedWidth = ((_b = columnsInfo.value) == null ? void 0 : _b.leftFixedWidth) || 0;
    const rightFixedWidth = ((_c = columnsInfo.value) == null ? void 0 : _c.rightFixedWidth) || 0;
    const scrollableContentWidth = totalWidth - leftFixedWidth - rightFixedWidth;
    const scrollableContainerWidth = containerWidthValue - leftFixedWidth - rightFixedWidth;
    const realMaxScrollLeft = Math.max(0, scrollableContentWidth - scrollableContainerWidth);
    const shouldShow = currentScrollLeft < realMaxScrollLeft - 5;
    if (process.env.NODE_ENV === "development") {
      console.log("🔍 右侧阴影逻辑 - 修复版:", {
        "所有滚动值": {
          external: externalScrollLeft,
          shadow: shadowScrollLeft_value,
          local: localScrollLeft_value,
          chosen: currentScrollLeft
        },
        "宽度计算": {
          totalWidth,
          containerWidth: containerWidthValue,
          leftFixedWidth,
          rightFixedWidth,
          scrollableContentWidth,
          scrollableContainerWidth
        },
        "滚动距离": {
          realMaxScrollLeft,
          threshold: realMaxScrollLeft - 5,
          hasScrollableContent: realMaxScrollLeft > 0
        },
        "阴影判断": {
          condition: `${currentScrollLeft} < ${realMaxScrollLeft - 5}`,
          result: shouldShow,
          state: currentScrollLeft === 0 ? "初始(应显示)" : currentScrollLeft >= realMaxScrollLeft - 5 ? "到底(应隐藏)" : "中间(应显示)"
        }
      });
      console.log(`🎨 右侧阴影修复版: ${shouldShow ? "✅显示" : "❌隐藏"} | 滚动=${currentScrollLeft}/${realMaxScrollLeft}`);
    }
    return shouldShow;
  });
  const leftFixedStyle = computed(() => {
    const height = typeof props.height === "string" ? props.height : `${props.height}px`;
    const scrollbarHeight = hasHorizontalScrollbar.value ? SCROLLBAR_HEIGHT : 0;
    return {
      position: "absolute",
      top: 0,
      left: 0,
      width: `${leftFixedTotalWidth.value}px`,
      height: `calc(${height} - ${scrollbarHeight}px)`,
      zIndex: 50,
      backgroundColor: "#fff",
      // 当应该隐藏固定列时，设置 display: none
      display: shouldHideFixedColumns.value ? "none" : "block",
      // 🔑 修复：参考VXE Table的阴影效果 - 右侧阴影 8px 0px 10px -5px
      boxShadow: shouldShowLeftShadow.value ? "8px 0px 10px -5px rgba(0, 0, 0, 0.12)" : "none"
    };
  });
  const rightFixedStyle = computed(() => {
    const height = typeof props.height === "string" ? props.height : `${props.height}px`;
    const scrollbarHeight = hasHorizontalScrollbar.value ? SCROLLBAR_HEIGHT : 0;
    const shouldShowShadow = shouldShowRightShadow.value;
    const _shadowScrollLeft = shadowScrollLeft.value;
    const _scrollLeft = scrollLeft.value;
    const _localScrollLeft = localScrollLeft.value;
    if (process.env.NODE_ENV === "development") {
      console.log("🎨 右侧固定列样式计算:", {
        shouldShowShadow,
        rightFixedWidth: columnsInfo.value.rightFixedWidth,
        shouldHideFixedColumns: shouldHideFixedColumns.value,
        boxShadow: shouldShowShadow ? "-8px 0px 10px -5px rgba(0, 0, 0, 0.12)" : "none",
        scrollLeft: _scrollLeft,
        shadowScrollLeft: _shadowScrollLeft,
        localScrollLeft: _localScrollLeft
      });
    }
    return {
      position: "absolute",
      top: 0,
      right: "0px",
      width: `${columnsInfo.value.rightFixedWidth}px`,
      height: `calc(${height} - ${scrollbarHeight}px)`,
      zIndex: 50,
      backgroundColor: "#fff",
      display: shouldHideFixedColumns.value ? "none" : "block",
      // 🔑 修复：参考VXE Table的阴影效果 - -8px 0px 10px -5px
      boxShadow: shouldShowShadow ? "-8px 0px 10px -5px rgba(0, 0, 0, 0.12)" : "none",
      boxSizing: "border-box"
    };
  });
  const fixedHeaderWrapperStyle = computed(() => ({
    height: `${headerHeight.value}px`
  }));
  const leftHeaderTableStyle = computed(() => {
    const selectionWidth = props.selectable ? SELECTION_WIDTH : 0;
    return {
      width: `${columnsInfo.value.leftFixedWidth + (props.expandable ? EXPAND_WIDTH : 0) + selectionWidth}px`,
      tableLayout: "fixed",
      borderCollapse: "separate",
      borderSpacing: 0
    };
  });
  const rightHeaderTableStyle = computed(() => ({
    width: `${columnsInfo.value.rightFixedWidth}px`,
    tableLayout: "fixed",
    borderCollapse: "separate",
    borderSpacing: 0
  }));
  const leftBodyWrapperStyle = computed(() => {
    const headerHeightValue = headerHeight.value;
    const toolbarHeight = 0;
    const loadMoreHeight = props.enableLoadMore && props.showLoadMoreUi ? 60 + SCROLLBAR_HEIGHT : SCROLLBAR_HEIGHT;
    const scrollbarHeight = hasHorizontalScrollbar.value ? SCROLLBAR_HEIGHT : 0;
    const height = typeof props.height === "string" ? props.height : `${props.height}px`;
    console.log("🔍 左侧固定列高度计算调试:", {
      原始height: props.height,
      处理后height: height,
      headerHeightValue,
      toolbarHeight,
      loadMoreHeight,
      scrollbarHeight,
      enableLoadMore: props.enableLoadMore,
      showLoadMoreUi: props.showLoadMoreUi,
      hasHorizontalScrollbar: hasHorizontalScrollbar.value,
      最终高度公式: `calc(${height} - ${headerHeightValue}px - ${toolbarHeight}px - ${loadMoreHeight}px - ${scrollbarHeight}px)`
    });
    return {
      height: `calc(${height} - ${headerHeightValue}px - ${toolbarHeight}px - ${loadMoreHeight}px - ${scrollbarHeight}px)`,
      overflow: "hidden",
      pointerEvents: "auto"
    };
  });
  const rightBodyWrapperStyle = computed(() => {
    const headerHeightValue = headerHeight.value;
    const toolbarHeight = 0;
    const loadMoreHeight = props.enableLoadMore && props.showLoadMoreUi ? 60 + SCROLLBAR_HEIGHT : SCROLLBAR_HEIGHT;
    const scrollbarHeight = hasHorizontalScrollbar.value ? SCROLLBAR_HEIGHT : 0;
    const height = typeof props.height === "string" ? props.height : `${props.height}px`;
    console.log("🔍 右侧固定列高度计算调试:", {
      原始height: props.height,
      处理后height: height,
      headerHeightValue,
      toolbarHeight,
      loadMoreHeight,
      scrollbarHeight,
      enableLoadMore: props.enableLoadMore,
      showLoadMoreUi: props.showLoadMoreUi,
      hasHorizontalScrollbar: hasHorizontalScrollbar.value,
      最终高度公式: `calc(${height} - ${headerHeightValue}px - ${toolbarHeight}px - ${loadMoreHeight}px - ${scrollbarHeight}px)`
    });
    return {
      height: `calc(${height} - ${headerHeightValue}px - ${toolbarHeight}px - ${loadMoreHeight}px - ${scrollbarHeight}px)`,
      overflow: "hidden",
      pointerEvents: "auto"
    };
  });
  const fixedColumnLoadMorePositionStyle = computed(() => {
    const scrollbarHeight = hasHorizontalScrollbar.value ? SCROLLBAR_HEIGHT : 0;
    return {
      bottom: `${scrollbarHeight}px`
    };
  });
  const leftBodyTableStyle = computed(() => {
    const selectionWidth = props.selectable ? SELECTION_WIDTH : 0;
    return {
      width: `${columnsInfo.value.leftFixedWidth + (props.expandable ? EXPAND_WIDTH : 0) + selectionWidth}px`,
      tableLayout: "fixed",
      borderCollapse: "separate",
      borderSpacing: 0
    };
  });
  const rightBodyTableStyle = computed(() => ({
    width: `${columnsInfo.value.rightFixedWidth}px`,
    tableLayout: "fixed",
    borderCollapse: "separate",
    borderSpacing: 0
  }));
  const loadMoreAreaStyle = computed(() => {
    const scrollbarHeight = hasHorizontalScrollbar.value ? SCROLLBAR_HEIGHT : 0;
    return {
      position: "absolute",
      bottom: `${scrollbarHeight}px`,
      left: hasLeftFixedContent.value ? `${leftFixedTotalWidth.value}px` : 0,
      right: hasRightFixedColumns.value ? `${columnsInfo.value.rightFixedWidth}px` : 0,
      height: "60px",
      zIndex: 10,
      backgroundColor: "#fff",
      borderTop: "1px solid var(--van-border-color)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    };
  });
  const hasHorizontalScrollbar = computed(() => {
    if (!columnsInfo.value.totalWidth || !containerWidth.value)
      return false;
    return columnsInfo.value.totalWidth > containerWidth.value;
  });
  return {
    // 样式计算
    selectionColStyle,
    getSelectionHeaderStyle,
    getSelectionCellStyle,
    expandColStyle,
    shouldHideFixedColumns,
    isScrolledToRight,
    leftFixedStyle,
    rightFixedStyle,
    fixedHeaderWrapperStyle,
    leftHeaderTableStyle,
    rightHeaderTableStyle,
    leftBodyWrapperStyle,
    rightBodyWrapperStyle,
    fixedColumnLoadMorePositionStyle,
    leftBodyTableStyle,
    rightBodyTableStyle,
    loadMoreAreaStyle,
    hasHorizontalScrollbar,
    // 🔑 新增：阴影状态更新函数和阴影控制
    updateShadowState,
    updateShadowScrollPosition,
    shouldShowLeftShadow,
    shouldShowRightShadow
  };
}
function useRowClickHandler(props, emit, isDevelopment, touchHandledRowIndex, selectedRowIndex, singleHighlightController, ensureSingleRowHighlight, isRowDisabled, isRowSelected, handleRowSelect) {
  const lastRowClickTime = ref(0);
  const lastRowClickIndex = ref(-1);
  const handleRowClickLocal = (row, rowIndex) => {
    const currentTime = Date.now();
    if (touchHandledRowIndex.value === rowIndex) {
      if (isDevelopment.value) {
        console.log(`Row click ignored: row ${rowIndex} already handled by touch event`);
      }
      touchHandledRowIndex.value = -1;
      return;
    }
    if (lastRowClickIndex.value === rowIndex && currentTime - lastRowClickTime.value < 100) {
      if (isDevelopment.value) {
        console.log(`Row click ignored (debounce): row ${rowIndex}`);
      }
      return;
    }
    lastRowClickTime.value = currentTime;
    lastRowClickIndex.value = rowIndex;
    if (isDevelopment.value) {
      console.log("Row clicked:", {
        rowIndex,
        previousSelected: selectedRowIndex.value
      });
    }
    singleHighlightController.enforceSingleRowHighlight(rowIndex);
    ensureSingleRowHighlight(rowIndex);
    if (props.selectOnRowClick && props.selectable && !isRowDisabled(row, rowIndex)) {
      singleHighlightController.markCheckboxOperation();
      const currentSelected = isRowSelected(row, rowIndex);
      handleRowSelect(row, rowIndex, !currentSelected);
    }
    emit("row-click", { row, rowIndex });
  };
  const handleBatchDelete = (selectedRows, selectedRowKeys) => {
    if (selectedRows.value.length === 0)
      return;
    emit("batch-delete", {
      selectedRows: selectedRows.value,
      selectedRowKeys: selectedRowKeys.value
    });
  };
  return {
    handleRowClickLocal,
    handleBatchDelete,
    lastRowClickTime,
    lastRowClickIndex
  };
}
function useTableHandlers(props, emit, scrollTop, scrollLeft, lastScrollTop, lastScrollLeft, intoRunScroll, isLoadingMore, isDevelopment, vxeStyleAbsoluteSync, handleLoadMore, updateShadowState, syncScroll, MIN_ROW_HEIGHT, dynamicRowHeights, EXPAND_WIDTH, rowHighlightHandlers) {
  const getRowStyle = (rowIndex) => {
    const height = dynamicRowHeights.value.get(rowIndex);
    if (height) {
      return {
        height: `${height}px`,
        minHeight: `${height}px`,
        maxHeight: `${height}px`
      };
    }
    return {
      minHeight: `${MIN_ROW_HEIGHT}px`
    };
  };
  const getExpandHeaderStyle = () => ({
    width: `${EXPAND_WIDTH}px`,
    minWidth: `${EXPAND_WIDTH}px`,
    maxWidth: `${EXPAND_WIDTH}px`,
    textAlign: "center"
  });
  const getExpandCellStyle = () => ({
    width: `${EXPAND_WIDTH}px`,
    minWidth: `${EXPAND_WIDTH}px`,
    maxWidth: `${EXPAND_WIDTH}px`,
    textAlign: "center"
  });
  const handleScroll = (event) => {
    const { scrollTop: currentScrollTop, scrollLeft: currentScrollLeft } = event.target;
    if (intoRunScroll.value) {
      if (isDevelopment.value) {
        console.log("跳过滚动处理 - 程序化滚动中", {
          intoRunScroll: intoRunScroll.value
        });
      }
      return;
    }
    const isInLoadingMore = isLoadingMore.value;
    if (isInLoadingMore && isDevelopment.value) {
      console.log("加载更多期间的滚动 - 仅进行同步，不触发新的加载", {
        currentScrollTop,
        currentScrollLeft
      });
    }
    const hasScrollTopChanged = currentScrollTop !== scrollTop.value;
    const hasScrollLeftChanged = currentScrollLeft !== scrollLeft.value;
    if (hasScrollTopChanged) {
      lastScrollTop.value = scrollTop.value;
      scrollTop.value = currentScrollTop;
    }
    if (hasScrollLeftChanged) {
      lastScrollLeft.value = scrollLeft.value;
      scrollLeft.value = currentScrollLeft;
    }
    if (!isInLoadingMore && props.enableLoadMore && hasScrollTopChanged) {
      const { scrollHeight, clientHeight } = event.target;
      const scrollPercentage = (currentScrollTop + clientHeight) / scrollHeight;
      if (scrollPercentage >= 0.9) {
        handleLoadMore();
      }
    }
    if (hasScrollTopChanged || hasScrollLeftChanged) {
      vxeStyleAbsoluteSync(currentScrollTop, currentScrollLeft);
      updateShadowState();
      syncScroll();
    }
    emit("scroll", {
      scrollTop: currentScrollTop,
      scrollLeft: currentScrollLeft,
      scrollHeight: event.target.scrollHeight,
      clientHeight: event.target.clientHeight,
      clientWidth: event.target.clientWidth
    });
  };
  const handleHeaderClick = (header, event) => {
    if (header.sortable) {
      emit("sort-change", { header, event });
    }
    emit("header-click", { header, event });
  };
  const handleRowClick = (row, rowIndex, event) => {
    emit("row-click", { row, rowIndex, event });
  };
  const handleRowClickLocal = (row, rowIndex) => {
    if (isDevelopment.value) {
      console.log("Row clicked locally:", { rowIndex });
    }
    emit("row-click", { row, rowIndex });
  };
  const handleCellClick = (row, column, rowIndex, colIndex, value, event) => {
    emit("cell-click", {
      row,
      column,
      rowIndex,
      colIndex,
      value,
      event
    });
  };
  const handleRowDoubleClick = (row, rowIndex, event) => {
    emit("row-double-click", { row, rowIndex, event });
  };
  const handleCellDoubleClick = (row, column, rowIndex, colIndex, value, event) => {
    emit("cell-double-click", {
      row,
      column,
      rowIndex,
      colIndex,
      value,
      event
    });
  };
  const handleRowMouseEnter = (row, rowIndex, event) => {
    const rowElements = document.querySelectorAll(`[data-row-index="${rowIndex}"]`);
    rowElements.forEach((el) => {
      if (el.classList.contains("vant-tr")) {
        el.classList.add("vant-tr--hover");
      }
    });
    emit("row-mouse-enter", { row, rowIndex, event });
    if (isDevelopment.value) {
      console.log(`🎯 鼠标进入第${rowIndex}行`);
    }
  };
  const handleRowMouseLeave = (row, rowIndex, event) => {
    const rowElements = document.querySelectorAll(`[data-row-index="${rowIndex}"]`);
    rowElements.forEach((el) => {
      if (el.classList.contains("vant-tr")) {
        el.classList.remove("vant-tr--hover");
      }
    });
    emit("row-mouse-leave", { row, rowIndex, event });
    if (isDevelopment.value) {
      console.log(`🎯 鼠标离开第${rowIndex}行`);
    }
  };
  const handleRowContextMenu = (row, rowIndex, event) => {
    emit("row-context-menu", { row, rowIndex, event });
  };
  const handleCellContextMenu = (row, column, rowIndex, colIndex, value, event) => {
    emit("cell-context-menu", {
      row,
      column,
      rowIndex,
      colIndex,
      value,
      event
    });
  };
  return {
    // 样式函数
    getRowStyle,
    getExpandHeaderStyle,
    getExpandCellStyle,
    // 事件处理函数
    handleScroll,
    handleHeaderClick,
    handleRowClick,
    handleRowClickLocal,
    handleCellClick,
    handleRowDoubleClick,
    handleCellDoubleClick,
    handleRowMouseEnter,
    handleRowMouseLeave,
    handleRowContextMenu,
    handleCellContextMenu,
    // 行高亮处理函数
    handleSingleRowHighlight: rowHighlightHandlers == null ? void 0 : rowHighlightHandlers.handleSingleRowHighlight
  };
}
function useTouchEvents(props, emit, bodyRef, leftBodyWrapperRef, rightBodyWrapperRef, scrollLeft, vxeStyleAbsoluteSync, getGlobalMaxScrollTop, filteredAndSortedData, handleSingleRowHighlight, handleRowClick, isLoadingMore, savedScrollPosition, isDevelopment, touchHandledRowIndex, columnsInfo, containerWidth) {
  let fixedColumnTouchStartY = 0;
  let fixedColumnTouchStartScrollTop = 0;
  let isFixedColumnTouching = false;
  let touchStartTime = 0;
  let mainTableTouchStartY = 0;
  let mainTableTouchStartX = 0;
  let mainTableStartScrollTop = 0;
  let mainTableStartScrollLeft = 0;
  let isMainTableTouching = false;
  let mainTableTouchStartTime = 0;
  const handleFixedColumnTouchStart = (event) => {
    var _a, _b;
    if (!bodyRef.value)
      return;
    const touch = event.touches[0];
    fixedColumnTouchStartY = touch.clientY;
    fixedColumnTouchStartScrollTop = bodyRef.value.scrollTop;
    isFixedColumnTouching = true;
    touchStartTime = Date.now();
    if (isDevelopment.value) {
      console.log("Fixed column touch start:", {
        startY: fixedColumnTouchStartY,
        startScrollTop: fixedColumnTouchStartScrollTop,
        target: (_b = (_a = event.target.closest("tr")) == null ? void 0 : _a.dataset) == null ? void 0 : _b.rowIndex
      });
    }
  };
  const handleFixedColumnTouchMove = (event) => {
    if (!isFixedColumnTouching || !bodyRef.value)
      return;
    const touch = event.touches[0];
    const deltaY = fixedColumnTouchStartY - touch.clientY;
    if (Math.abs(deltaY) > 3) {
      const getGlobalMaxScrollTopInternal = () => {
        if (!bodyRef.value)
          return 0;
        const mainMaxScrollTop = bodyRef.value.scrollHeight - bodyRef.value.clientHeight;
        let globalMaxScrollTop2 = mainMaxScrollTop;
        if (leftBodyWrapperRef.value) {
          const leftMaxScrollTop = leftBodyWrapperRef.value.scrollHeight - leftBodyWrapperRef.value.clientHeight;
          globalMaxScrollTop2 = Math.min(globalMaxScrollTop2, leftMaxScrollTop);
        }
        if (rightBodyWrapperRef.value) {
          const rightMaxScrollTop = rightBodyWrapperRef.value.scrollHeight - rightBodyWrapperRef.value.clientHeight;
          globalMaxScrollTop2 = Math.min(globalMaxScrollTop2, rightMaxScrollTop);
        }
        return Math.max(0, globalMaxScrollTop2);
      };
      const globalMaxScrollTop = getGlobalMaxScrollTopInternal();
      const newScrollTop = Math.max(0, Math.min(globalMaxScrollTop, fixedColumnTouchStartScrollTop + deltaY));
      const isAtTopBoundary = newScrollTop === 0 && deltaY > 0;
      const isAtBottomBoundary = newScrollTop === globalMaxScrollTop && deltaY < 0;
      vxeStyleAbsoluteSync(newScrollTop, scrollLeft.value);
      if (props.enableLoadMore && !props.loadMoreLoading && !props.loadMoreFinished && !props.loadMoreError) {
        const { scrollHeight, clientHeight } = bodyRef.value;
        const distanceFromBottom = scrollHeight - newScrollTop - clientHeight;
        if (isDevelopment.value) {
          console.log("固定列触摸移动 - 加载更多检测:", {
            scrollHeight,
            scrollTop: newScrollTop,
            clientHeight,
            distanceFromBottom,
            loadMoreOffset: props.loadMoreOffset,
            globalMaxScrollTop,
            useMainTableHeight: true
          });
        }
        if (distanceFromBottom < props.loadMoreOffset) {
          if (isDevelopment.value) {
            console.log("固定列触发加载更多 (使用主表格高度检测)");
            console.log("当前滚动位置:", newScrollTop);
          }
          isLoadingMore.value = true;
          savedScrollPosition.value = newScrollTop;
          if (isDevelopment.value) {
            console.log("固定列触摸触发加载更多，保存滚动位置:", savedScrollPosition.value);
          }
          emit("load-more");
        }
      }
      if (isDevelopment.value) {
        console.log("Fixed column touch move:", {
          deltaY,
          newScrollTop,
          globalMaxScrollTop,
          isAtTopBoundary,
          isAtBottomBoundary
        });
      }
      if (!isAtTopBoundary && !isAtBottomBoundary) {
        event.preventDefault();
        event.stopPropagation();
      }
    }
  };
  const handleFixedColumnTouchEnd = (event) => {
    var _a, _b;
    const touchEndTime = Date.now();
    const touchDuration = touchEndTime - touchStartTime;
    const touchDistance = Math.abs(event.changedTouches[0].clientY - fixedColumnTouchStartY);
    if (isDevelopment.value) {
      console.log("Fixed column touch end:", {
        duration: touchDuration,
        distance: touchDistance,
        isClick: touchDuration < 200 && touchDistance < 10,
        target: (_b = (_a = event.target.closest("tr")) == null ? void 0 : _a.dataset) == null ? void 0 : _b.rowIndex,
        targetElement: event.target.tagName,
        targetClasses: event.target.className
      });
    }
    if (touchDuration < 200 && touchDistance < 10) {
      const isButton = event.target.closest('button, .van-button, [role="button"]');
      const isClickableElement = event.target.closest("a, input, select, textarea");
      if (isButton || isClickableElement) {
        if (isDevelopment.value) {
          console.log("Fixed column touch end: clicked on interactive element, allowing normal flow");
        }
      } else {
        const targetRow = event.target.closest("tr");
        if (targetRow && targetRow.dataset.rowIndex !== void 0) {
          const rowIndex = parseInt(targetRow.dataset.rowIndex);
          if (isDevelopment.value) {
            console.log(`Fixed column touch click: triggering unified row click for row ${rowIndex}`);
          }
          const row = filteredAndSortedData.value[rowIndex];
          if (isDevelopment.value) {
            console.log(`Fixed column touch click: rowIndex=${rowIndex}, row=`, row, `filteredAndSortedData.length=${filteredAndSortedData.value.length}`);
          }
          if (row) {
            if (isDevelopment.value) {
              console.log(`Fixed column touch click: calling handleRowClick for row ${rowIndex}`);
            }
            handleSingleRowHighlight({ target: targetRow }, rowIndex);
            handleRowClick(row, rowIndex);
            event.preventDefault();
            event.stopPropagation();
            setTimeout(() => {
            }, 100);
          } else {
            if (isDevelopment.value) {
              console.error(`Fixed column touch click: row not found for index ${rowIndex}`);
            }
          }
        } else {
          if (isDevelopment.value) {
            console.log("Fixed column touch end: no target row found, allowing normal event flow");
          }
        }
      }
    }
    isFixedColumnTouching = false;
    fixedColumnTouchStartY = 0;
    fixedColumnTouchStartScrollTop = 0;
    touchStartTime = 0;
  };
  const handleMainTableTouchStart = (event) => {
    if (!bodyRef.value)
      return;
    const touch = event.touches[0];
    mainTableTouchStartY = touch.clientY;
    mainTableTouchStartX = touch.clientX;
    mainTableStartScrollTop = bodyRef.value.scrollTop;
    mainTableStartScrollLeft = bodyRef.value.scrollLeft;
    isMainTableTouching = true;
    mainTableTouchStartTime = Date.now();
    if (isDevelopment.value) {
      console.log("Main table touch start:", {
        startY: mainTableTouchStartY,
        startX: mainTableTouchStartX,
        startScrollTop: mainTableStartScrollTop,
        startScrollLeft: mainTableStartScrollLeft
      });
    }
  };
  const handleMainTableTouchMove = (event) => {
    if (!isMainTableTouching || !bodyRef.value)
      return;
    const touch = event.touches[0];
    const deltaY = mainTableTouchStartY - touch.clientY;
    const deltaX = mainTableTouchStartX - touch.clientX;
    const getGlobalMaxScrollTopInternal = () => {
      if (!bodyRef.value)
        return 0;
      const mainMaxScrollTop = bodyRef.value.scrollHeight - bodyRef.value.clientHeight;
      let globalMaxScrollTop2 = mainMaxScrollTop;
      if (leftBodyWrapperRef.value) {
        const leftMaxScrollTop = leftBodyWrapperRef.value.scrollHeight - leftBodyWrapperRef.value.clientHeight;
        globalMaxScrollTop2 = Math.min(globalMaxScrollTop2, leftMaxScrollTop);
      }
      if (rightBodyWrapperRef.value) {
        const rightMaxScrollTop = rightBodyWrapperRef.value.scrollHeight - rightBodyWrapperRef.value.clientHeight;
        globalMaxScrollTop2 = Math.min(globalMaxScrollTop2, rightMaxScrollTop);
      }
      return Math.max(0, globalMaxScrollTop2);
    };
    const globalMaxScrollTop = getGlobalMaxScrollTopInternal();
    const maxScrollLeft = Math.max(0, columnsInfo.value.totalWidth - containerWidth.value);
    const newScrollTop = Math.max(0, Math.min(globalMaxScrollTop, mainTableStartScrollTop + deltaY));
    const newScrollLeft = Math.max(0, Math.min(maxScrollLeft, mainTableStartScrollLeft + deltaX));
    const isAtTopBoundary = newScrollTop === 0 && deltaY > 0;
    const isAtBottomBoundary = newScrollTop === globalMaxScrollTop && deltaY < 0;
    const isAtLeftBoundary = newScrollLeft === 0 && deltaX > 0;
    const isAtRightBoundary = newScrollLeft === maxScrollLeft && deltaX < 0;
    const isVerticalScroll = Math.abs(deltaY) > Math.abs(deltaX);
    const isHorizontalScroll = Math.abs(deltaX) > Math.abs(deltaY);
    let shouldPreventDefault = false;
    if (isVerticalScroll) {
      if (!isAtTopBoundary && !isAtBottomBoundary) {
        shouldPreventDefault = true;
      }
    } else if (isHorizontalScroll) {
      if (!isAtLeftBoundary && !isAtRightBoundary) {
        shouldPreventDefault = true;
      }
    }
    if (Math.abs(deltaY) > 3 || Math.abs(deltaX) > 3) {
      vxeStyleAbsoluteSync(newScrollTop, newScrollLeft);
      if (props.enableLoadMore && !props.loadMoreLoading && !props.loadMoreFinished && !props.loadMoreError && isVerticalScroll) {
        const { scrollHeight, clientHeight } = bodyRef.value;
        const distanceFromBottom = scrollHeight - newScrollTop - clientHeight;
        if (isDevelopment.value) {
          console.log("主表格触摸移动 - 加载更多检测:", {
            scrollHeight,
            scrollTop: newScrollTop,
            clientHeight,
            distanceFromBottom,
            loadMoreOffset: props.loadMoreOffset,
            globalMaxScrollTop,
            isVerticalScroll
          });
        }
        if (distanceFromBottom < props.loadMoreOffset) {
          if (isDevelopment.value) {
            console.log("主表格触发加载更多 (触摸移动检测)");
            console.log("当前滚动位置:", newScrollTop);
          }
          isLoadingMore.value = true;
          savedScrollPosition.value = newScrollTop;
          if (isDevelopment.value) {
            console.log("主表格触摸触发加载更多，保存滚动位置:", savedScrollPosition.value);
          }
          emit("load-more");
        }
      }
      if (isDevelopment.value) {
        console.log("Main table touch move:", {
          deltaY,
          deltaX,
          newScrollTop,
          newScrollLeft,
          isAtTopBoundary,
          isAtBottomBoundary,
          isAtLeftBoundary,
          isAtRightBoundary,
          shouldPreventDefault,
          isVerticalScroll,
          isHorizontalScroll
        });
      }
    }
    if (shouldPreventDefault) {
      event.preventDefault();
      event.stopPropagation();
    }
  };
  const handleMainTableTouchEnd = (event) => {
    const touchEndTime = Date.now();
    const touchDuration = touchEndTime - mainTableTouchStartTime;
    const touchDistanceY = Math.abs(event.changedTouches[0].clientY - mainTableTouchStartY);
    const touchDistanceX = Math.abs(event.changedTouches[0].clientX - mainTableTouchStartX);
    const totalTouchDistance = Math.sqrt(touchDistanceY * touchDistanceY + touchDistanceX * touchDistanceX);
    if (isDevelopment.value) {
      console.log("Main table touch end:", {
        duration: touchDuration,
        distanceY: touchDistanceY,
        distanceX: touchDistanceX,
        totalDistance: totalTouchDistance,
        isClick: touchDuration < 200 && totalTouchDistance < 10
      });
    }
    if (touchDuration < 200 && totalTouchDistance < 10) {
      if (isDevelopment.value) {
        console.log("Main table: detected click, allowing normal event flow");
      }
    }
    isMainTableTouching = false;
    mainTableTouchStartY = 0;
    mainTableTouchStartX = 0;
    mainTableStartScrollTop = 0;
    mainTableStartScrollLeft = 0;
    mainTableTouchStartTime = 0;
  };
  return {
    handleFixedColumnTouchStart,
    handleFixedColumnTouchMove,
    handleFixedColumnTouchEnd,
    handleMainTableTouchStart,
    handleMainTableTouchMove,
    handleMainTableTouchEnd
  };
}
function useRowHighlight(isDevelopment, rowElementRefs, hoveredRowIndex, selectedRowIndex, measureAndSyncRowHeights) {
  let lastRowClickTime = 0;
  let lastRowClickIndex = -1;
  let touchHandledRowIndex = -1;
  const ensureSingleRowHighlight = (targetRowIndex) => {
    if (isDevelopment.value) {
      console.log(`ensureSingleRowHighlight: 开始处理第${targetRowIndex}行，当前选中行: ${selectedRowIndex.value}`);
    }
    if (isDevelopment.value) {
      console.log("ensureSingleRowHighlight: 开始彻底清除所有高亮状态");
    }
    const allHighlightedElements = document.querySelectorAll(".vant-tr--selected, .vant-tr--highlighted, .vant-tr--active");
    allHighlightedElements.forEach((el) => {
      el.classList.remove("vant-tr--selected", "vant-tr--highlighted", "vant-tr--active");
      el.offsetHeight;
    });
    Object.keys(rowElementRefs.value).forEach((rowIndex) => {
      const positions2 = ["main", "left", "right"];
      positions2.forEach((position) => {
        var _a;
        const rowEl = (_a = rowElementRefs.value[rowIndex]) == null ? void 0 : _a[position];
        if (rowEl) {
          rowEl.classList.remove("vant-tr--selected", "vant-tr--highlighted", "vant-tr--active");
          rowEl.offsetHeight;
        }
      });
    });
    selectedRowIndex.value = -1;
    selectedRowIndex.value = targetRowIndex;
    const positions = ["main", "left", "right"];
    let successCount = 0;
    positions.forEach((position) => {
      var _a;
      const rowEl = (_a = rowElementRefs.value[targetRowIndex]) == null ? void 0 : _a[position];
      if (rowEl) {
        rowEl.classList.remove("vant-tr--highlighted", "vant-tr--active");
        rowEl.classList.add("vant-tr--selected");
        rowEl.offsetHeight;
        successCount++;
        if (isDevelopment.value) {
          console.log(`ensureSingleRowHighlight: 已设置第${targetRowIndex}行${position}区域高亮`);
        }
      } else {
        if (isDevelopment.value) {
          console.warn(`ensureSingleRowHighlight: 第${targetRowIndex}行${position}区域元素未找到`);
        }
      }
    });
    if (isDevelopment.value) {
      console.log(`ensureSingleRowHighlight: 成功设置${successCount}个区域高亮`);
      const selectedElements = document.querySelectorAll(".vant-tr--selected");
      console.log(`ensureSingleRowHighlight: 验证结果 - 找到${selectedElements.length}个高亮元素`);
      if (selectedElements.length > 3) {
        console.error(`发现${selectedElements.length}个高亮元素，应该只有3个！立即修正...`);
        selectedElements.forEach((el) => {
          el.classList.remove("vant-tr--selected");
          el.offsetHeight;
        });
        positions.forEach((position) => {
          var _a;
          const rowEl = (_a = rowElementRefs.value[targetRowIndex]) == null ? void 0 : _a[position];
          if (rowEl) {
            rowEl.classList.add("vant-tr--selected");
            rowEl.offsetHeight;
          }
        });
      } else if (selectedElements.length === 0 && successCount > 0) {
        console.error("没有找到任何高亮元素但应该有！重新设置...");
        positions.forEach((position) => {
          var _a;
          const rowEl = (_a = rowElementRefs.value[targetRowIndex]) == null ? void 0 : _a[position];
          if (rowEl) {
            rowEl.classList.add("vant-tr--selected");
            rowEl.offsetHeight;
          }
        });
      }
    }
  };
  const forceCleanAllHighlight = () => {
    if (isDevelopment.value) {
      console.log("forceCleanAllHighlight: 开始强制清除所有行高亮");
    }
    const highlightClasses = [".vant-tr--selected", ".vant-tr--highlighted", ".vant-tr--active"];
    let totalCleaned = 0;
    highlightClasses.forEach((className) => {
      const elements = document.querySelectorAll(className);
      elements.forEach((el) => {
        el.classList.remove(className.substring(1));
        el.offsetHeight;
        totalCleaned++;
      });
    });
    Object.keys(rowElementRefs.value).forEach((rowIndex) => {
      const positions = ["main", "left", "right"];
      positions.forEach((position) => {
        var _a;
        const rowEl = (_a = rowElementRefs.value[rowIndex]) == null ? void 0 : _a[position];
        if (rowEl) {
          const wasHighlighted = rowEl.classList.contains("vant-tr--selected") || rowEl.classList.contains("vant-tr--highlighted") || rowEl.classList.contains("vant-tr--active");
          rowEl.classList.remove("vant-tr--selected", "vant-tr--highlighted", "vant-tr--active");
          if (wasHighlighted) {
            rowEl.offsetHeight;
            totalCleaned++;
          }
        }
      });
    });
    selectedRowIndex.value = -1;
    const remainingSelected = document.querySelectorAll(".vant-tr--selected, .vant-tr--highlighted, .vant-tr--active");
    if (remainingSelected.length > 0) {
      if (isDevelopment.value) {
        console.warn(`forceCleanAllHighlight: 仍有${remainingSelected.length}个元素未清理，执行最终清理`);
      }
      remainingSelected.forEach((el) => {
        el.classList.remove("vant-tr--selected", "vant-tr--highlighted", "vant-tr--active");
        el.offsetHeight;
      });
    }
    if (isDevelopment.value) {
      console.log(`forceCleanAllHighlight: 强制清除完成，共清理${totalCleaned}个元素`);
    }
  };
  const clearAllRowHighlight = () => {
    if (isDevelopment.value) {
      console.log("clearAllRowHighlight: 开始清除所有行高亮");
    }
    document.querySelectorAll(".vant-tr--selected").forEach((el) => {
      el.classList.remove("vant-tr--selected");
    });
    Object.keys(rowElementRefs.value).forEach((rowIndex) => {
      const positions = ["main", "left", "right"];
      positions.forEach((position) => {
        var _a;
        const rowEl = (_a = rowElementRefs.value[rowIndex]) == null ? void 0 : _a[position];
        if (rowEl) {
          rowEl.classList.remove("vant-tr--selected");
        }
      });
    });
    selectedRowIndex.value = -1;
    if (isDevelopment.value) {
      console.log("clearAllRowHighlight: 清除完成");
    }
  };
  const handleSingleRowHighlight = (event, rowIndex) => {
    console.log(`🚫 handleSingleRowHighlight 被调用但已禁用: rowIndex=${rowIndex}`);
    console.log(`💡 只有复选框选中的行才会高亮`);
    return;
  };
  const clearAllSelectedStateSync = () => {
    if (isDevelopment.value) {
      console.log("clearAllSelectedStateSync: 开始同步清除所有选中状态");
    }
    Object.keys(rowElementRefs.value).forEach((rowIndex) => {
      const positions = ["main", "left", "right"];
      positions.forEach((position) => {
        var _a;
        const rowEl = (_a = rowElementRefs.value[rowIndex]) == null ? void 0 : _a[position];
        if (rowEl) {
          rowEl.classList.remove("vant-tr--selected", "vant-tr--hover", "vant-tr--highlighted", "vant-tr--active");
          rowEl.offsetHeight;
        }
      });
    });
    document.querySelectorAll(".vant-tr--selected, .vant-tr--hover, .vant-tr--highlighted, .vant-tr--active").forEach((el) => {
      el.classList.remove("vant-tr--selected", "vant-tr--hover", "vant-tr--highlighted", "vant-tr--active");
    });
    selectedRowIndex.value = -1;
    hoveredRowIndex.value = -1;
    if (isDevelopment.value) {
      console.log("clearAllSelectedStateSync: 同步清除完成");
    }
  };
  const applyRowStateSync = (rowIndex, state, active) => {
    const stateClass = `vant-tr--${state}`;
    if (isDevelopment.value) {
      console.log(`applyRowStateSync: rowIndex=${rowIndex}, state=${state}, active=${active}`);
    }
    const positions = ["main", "left", "right"];
    positions.forEach((position) => {
      var _a;
      const rowEl = (_a = rowElementRefs.value[rowIndex]) == null ? void 0 : _a[position];
      if (rowEl) {
        if (active) {
          rowEl.classList.add(stateClass);
          rowEl.offsetHeight;
          if (isDevelopment.value) {
            console.log(`applyRowStateSync: Added ${stateClass} to ${position} row ${rowIndex}`);
          }
        } else {
          rowEl.classList.remove(stateClass);
          rowEl.offsetHeight;
          if (isDevelopment.value) {
            console.log(`applyRowStateSync: Removed ${stateClass} from ${position} row ${rowIndex}`);
          }
        }
      } else {
        if (isDevelopment.value) {
          console.warn(`applyRowStateSync: Row element not found for ${position} row ${rowIndex}`);
        }
      }
    });
    if (active && state === "selected") {
      setTimeout(() => {
        positions.forEach((position) => {
          var _a;
          const rowEl = (_a = rowElementRefs.value[rowIndex]) == null ? void 0 : _a[position];
          if (rowEl && !rowEl.classList.contains(stateClass)) {
            console.warn(`applyRowStateSync: Force reapplying ${stateClass} to ${position} row ${rowIndex}`);
            rowEl.classList.add(stateClass);
            rowEl.offsetHeight;
          }
        });
      }, 0);
    }
  };
  const clearAllSelectedState = () => {
    const stateClasses = ["vant-tr--selected", "vant-tr--hover", "vant-tr--highlighted", "vant-tr--active"];
    Object.keys(rowElementRefs.value).forEach((rowIndex) => {
      const positions = ["main", "left", "right"];
      positions.forEach((position) => {
        var _a;
        const rowEl = (_a = rowElementRefs.value[rowIndex]) == null ? void 0 : _a[position];
        if (rowEl) {
          stateClasses.forEach((className) => {
            rowEl.classList.remove(className);
          });
          rowEl.offsetHeight;
        }
      });
    });
    selectedRowIndex.value = -1;
    hoveredRowIndex.value = -1;
    if (isDevelopment.value) {
      console.log("clearAllSelectedState: 已清除所有行的选中状态和相关状态");
    }
  };
  const forceResetAllRowStates = () => {
    if (isDevelopment.value) {
      console.log("forceResetAllRowStates: 强制重置所有行状态");
    }
    const stateClasses = ["vant-tr--selected", "vant-tr--hover", "vant-tr--highlighted"];
    Object.keys(rowElementRefs.value).forEach((rowIndex) => {
      const positions = ["main", "left", "right"];
      positions.forEach((position) => {
        var _a;
        const rowEl = (_a = rowElementRefs.value[rowIndex]) == null ? void 0 : _a[position];
        if (rowEl) {
          stateClasses.forEach((className) => {
            if (rowEl.classList.contains(className)) {
              rowEl.classList.remove(className);
              if (isDevelopment.value) {
                console.log(`Removed ${className} from ${position} row ${rowIndex}`);
              }
            }
          });
          rowEl.offsetHeight;
        }
      });
    });
    selectedRowIndex.value = -1;
    hoveredRowIndex.value = -1;
  };
  const updateSelectionHighlight = (selectedRows, getRowKey, filteredAndSortedData) => {
    var _a;
    console.log("🔵 updateSelectionHighlight: 更新选中行高亮", {
      selectedCount: selectedRows.length,
      selectedKeys: selectedRows.map((row, index) => getRowKey(row, index)),
      selectedRows,
      filteredAndSortedDataLength: (_a = filteredAndSortedData == null ? void 0 : filteredAndSortedData.value) == null ? void 0 : _a.length
    });
    const positions = ["main", "left", "right"];
    Object.keys(rowElementRefs.value).forEach((rowIndex) => {
      positions.forEach((position) => {
        var _a2;
        const rowEl = (_a2 = rowElementRefs.value[rowIndex]) == null ? void 0 : _a2[position];
        if (rowEl) {
          rowEl.classList.remove("vant-tr--selected");
        }
      });
    });
    document.querySelectorAll(".vant-tr--selected").forEach((el) => {
      el.classList.remove("vant-tr--selected");
    });
    let appliedCount = 0;
    selectedRows.forEach((selectedRow, selectedIndex) => {
      console.log(`🔍 处理选中行 ${selectedIndex}:`, selectedRow);
      const rowIndex = filteredAndSortedData.value.findIndex((row, index) => {
        const selectedKey = getRowKey(selectedRow, selectedIndex);
        const currentKey = getRowKey(row, index);
        console.log(`🔍 比较键值: selectedKey=${selectedKey}, currentKey=${currentKey}, index=${index}`);
        return selectedKey === currentKey;
      });
      console.log(`🔍 找到行索引: ${rowIndex}`);
      if (rowIndex !== -1) {
        let currentRowApplied = 0;
        positions.forEach((position) => {
          var _a2;
          const rowEl = (_a2 = rowElementRefs.value[rowIndex]) == null ? void 0 : _a2[position];
          if (rowEl) {
            rowEl.classList.add("vant-tr--selected");
            currentRowApplied++;
            console.log(`✅ 通过refs设置第${rowIndex}行${position}区域选中高亮`);
          } else {
            console.log(`❌ 第${rowIndex}行${position}区域元素引用未找到`);
          }
        });
        if (currentRowApplied === 0) {
          console.log(`🔧 第${rowIndex}行refs为空，使用DOM查询备用方案`);
          const mainTableRows = document.querySelectorAll(".vant-table-body tr[data-row-index]");
          const leftFixedRows = document.querySelectorAll(".vant-table-fixed--left tr[data-row-index]");
          const rightFixedRows = document.querySelectorAll(".vant-table-fixed--right tr[data-row-index]");
          if (mainTableRows[rowIndex]) {
            mainTableRows[rowIndex].classList.add("vant-tr--selected");
            currentRowApplied++;
            console.log(`✅ 通过DOM查询设置主表格第${rowIndex}行选中高亮`);
          }
          if (leftFixedRows[rowIndex]) {
            leftFixedRows[rowIndex].classList.add("vant-tr--selected");
            currentRowApplied++;
            console.log(`✅ 通过DOM查询设置左侧固定列第${rowIndex}行选中高亮`);
          }
          if (rightFixedRows[rowIndex]) {
            rightFixedRows[rowIndex].classList.add("vant-tr--selected");
            currentRowApplied++;
            console.log(`✅ 通过DOM查询设置右侧固定列第${rowIndex}行选中高亮`);
          }
        }
        appliedCount += currentRowApplied;
      } else {
        console.warn(`❌ 未找到选中行的索引，selectedRow:`, selectedRow);
      }
    });
    console.log(`🔵 updateSelectionHighlight: 完成，共应用${appliedCount}个区域的选中高亮`);
    if (window.vxeStyleRowHeightSync && typeof window.vxeStyleRowHeightSync === "function") {
      setTimeout(() => {
        window.vxeStyleRowHeightSync();
        console.log(`🔧 已调用VXE风格行高同步函数`);
      }, 50);
    }
  };
  return {
    ensureSingleRowHighlight,
    forceCleanAllHighlight,
    clearAllRowHighlight,
    handleSingleRowHighlight,
    clearAllSelectedStateSync,
    applyRowStateSync,
    clearAllSelectedState,
    forceResetAllRowStates,
    updateSelectionHighlight,
    lastRowClickTime,
    lastRowClickIndex,
    touchHandledRowIndex
  };
}
function useHighlightController(isDevelopment) {
  const createSingleHighlightController = () => {
    let isCheckboxOperation = false;
    let currentHighlightedRow = -1;
    const markCheckboxOperation = () => {
      isCheckboxOperation = true;
      setTimeout(() => {
        isCheckboxOperation = false;
      }, 100);
    };
    const enforceSingleRowHighlight = (targetRowIndex = null) => {
      if (isCheckboxOperation) {
        return;
      }
      const selectedElements = document.querySelectorAll(".vant-tr--selected");
      if (targetRowIndex !== null) {
        selectedElements.forEach((el) => {
          const rowIndex = parseInt(el.getAttribute("data-row-index"));
          if (rowIndex !== targetRowIndex) {
            el.classList.remove("vant-tr--selected");
            el.offsetHeight;
          }
        });
        currentHighlightedRow = targetRowIndex;
      } else {
        const uniqueRows = /* @__PURE__ */ new Set();
        selectedElements.forEach((el) => {
          const rowIndex = el.getAttribute("data-row-index");
          uniqueRows.add(rowIndex);
        });
        if (uniqueRows.size > 1) {
          const lastRowIndex = Math.max(...Array.from(uniqueRows).map(Number));
          selectedElements.forEach((el) => {
            const rowIndex = parseInt(el.getAttribute("data-row-index"));
            if (rowIndex !== lastRowIndex) {
              el.classList.remove("vant-tr--selected");
              el.offsetHeight;
            }
          });
          currentHighlightedRow = lastRowIndex;
        }
      }
    };
    return {
      markCheckboxOperation,
      enforceSingleRowHighlight,
      getCurrentHighlightedRow: () => currentHighlightedRow
    };
  };
  const monitorHighlightState = (singleHighlightController) => {
    if (typeof window !== "undefined" && window.MutationObserver) {
      const observer = new MutationObserver((mutations) => {
        mutations.forEach((mutation) => {
          if (mutation.type === "attributes" && mutation.attributeName === "class") {
            const target = mutation.target;
            if (target.classList.contains("vant-tr--selected")) {
              const rowIndex = target.getAttribute("data-row-index");
              setTimeout(() => {
                singleHighlightController.enforceSingleRowHighlight();
              }, 0);
              if (isDevelopment.value) {
                console.log(`🟡 高亮添加监控: 第${rowIndex}行被高亮`, target);
                const allSelected = document.querySelectorAll(".vant-tr--selected");
                if (allSelected.length > 3) {
                  console.error(`🔴 发现异常: ${allSelected.length}个高亮元素，执行强制清理！`);
                  singleHighlightController.enforceSingleRowHighlight();
                }
              }
            }
          }
        });
      });
      const tableWrapper = document.querySelector(".vant-table-wrapper");
      if (tableWrapper) {
        observer.observe(tableWrapper, {
          attributes: true,
          attributeFilter: ["class"],
          subtree: true
        });
      }
      return observer;
    }
    return null;
  };
  return {
    createSingleHighlightController,
    monitorHighlightState
  };
}
function useDataProcessor(props, activeFilters, sortConfig, getCellValue, isRowTotal) {
  const filteredAndSortedData = computed(() => {
    let data = [...props.data];
    Object.entries(activeFilters.value).forEach(([key, filter]) => {
      if (filter.type === "multiSelect" && filter.values && filter.values.length > 0) {
        data = data.filter((row) => {
          const cellValue = String(getCellValue(row, key) || "");
          return filter.values.includes(cellValue);
        });
      } else if (filter.value) {
        data = data.filter((row) => {
          const cellValue = String(getCellValue(row, key) || "").toLowerCase();
          const filterValue = String(filter.value).toLowerCase();
          switch (filter.type) {
            case "contains":
              return cellValue.includes(filterValue);
            case "equals":
              return cellValue === filterValue;
            case "startsWith":
              return cellValue.startsWith(filterValue);
            default:
              return true;
          }
        });
      }
    });
    if (sortConfig.value.key && sortConfig.value.direction) {
      const { key, direction } = sortConfig.value;
      const totalRows = data.filter((row) => isRowTotal(row));
      const normalRows = data.filter((row) => !isRowTotal(row));
      normalRows.sort((a, b) => {
        const valueA = getCellValue(a, key);
        const valueB = getCellValue(b, key);
        let result = 0;
        if (typeof valueA === "number" && typeof valueB === "number") {
          result = valueA - valueB;
        } else {
          result = String(valueA || "").localeCompare(String(valueB || ""));
        }
        return direction === "asc" ? result : -result;
      });
      data = [...normalRows, ...totalRows];
    }
    return data;
  });
  const hasActiveFilters = computed(() => {
    return Object.keys(activeFilters.value).length > 0;
  });
  return {
    filteredAndSortedData,
    hasActiveFilters
  };
}
function useStyleUpdater(props, columnsInfo, containerWidth, scrollLeft, hasLeftFixedContent, hasRightFixedColumns, leftFixedTotalWidth, showHorizontalScrollbar, layoutWrapperRef, bodyRef, headerRef, leftBodyWrapperRef, rightBodyWrapperRef) {
  const updateShadowState = () => {
    const leftWidth = hasLeftFixedContent.value ? leftFixedTotalWidth.value + 1 : 0;
    const rightWidth = hasRightFixedColumns.value ? columnsInfo.value.rightFixedWidth + 1 : 0;
    const contentWidth = containerWidth.value - leftWidth - rightWidth;
    const mainTableWidth = columnsInfo.value.mainHeadersWidth || 0;
    const currentScrollLeft = scrollLeft.value;
    const maxScrollLeft = Math.max(0, mainTableWidth - contentWidth);
    const hasScrollableContent = mainTableWidth > contentWidth;
    console.log("🔍 阴影状态调试:", {
      containerWidth: containerWidth.value,
      leftWidth,
      rightWidth,
      contentWidth,
      mainTableWidth,
      hasScrollableContent,
      currentScrollLeft,
      maxScrollLeft,
      hasLeftFixedContent: hasLeftFixedContent.value,
      hasRightFixedColumns: hasRightFixedColumns.value
    });
    const hasLeftScroll = hasScrollableContent && currentScrollLeft > 5 && hasLeftFixedContent.value;
    const hasRightScroll = hasScrollableContent && currentScrollLeft < maxScrollLeft - 5 && hasRightFixedColumns.value;
    const hasScrollableContentWithRightFixed = hasScrollableContent && hasRightFixedColumns.value && currentScrollLeft < maxScrollLeft - 5;
    const leftShadowPosition = hasLeftFixedContent.value ? leftFixedTotalWidth.value : 0;
    const rightShadowPosition = hasRightFixedColumns.value ? columnsInfo.value.rightFixedWidth : 0;
    console.log("🔍 最终阴影状态:", {
      hasLeftScroll,
      hasRightScroll,
      hasScrollableContentWithRightFixed,
      leftShadowPosition,
      rightShadowPosition
    });
    if (layoutWrapperRef.value) {
      layoutWrapperRef.value.setAttribute("data-scroll-left", hasLeftScroll ? "1" : "0");
      layoutWrapperRef.value.setAttribute("data-scroll-right", hasRightScroll ? "1" : "0");
      layoutWrapperRef.value.setAttribute("data-has-scrollable-content", hasScrollableContentWithRightFixed ? "1" : "0");
      layoutWrapperRef.value.style.setProperty("--left-shadow-position", `${leftShadowPosition}px`);
      layoutWrapperRef.value.style.setProperty("--right-shadow-position", `${rightShadowPosition}px`);
    }
    if (bodyRef.value) {
      bodyRef.value.setAttribute("data-scroll-left", hasLeftScroll ? "1" : "0");
      bodyRef.value.setAttribute("data-scroll-right", hasRightScroll ? "1" : "0");
      bodyRef.value.setAttribute("data-has-scrollable-content", hasScrollableContentWithRightFixed ? "1" : "0");
      bodyRef.value.style.setProperty("--left-shadow-position", `${leftShadowPosition}px`);
      bodyRef.value.style.setProperty("--right-shadow-position", `${rightShadowPosition}px`);
    }
    if (headerRef.value) {
      headerRef.value.setAttribute("data-scroll-left", hasLeftScroll ? "1" : "0");
      headerRef.value.setAttribute("data-scroll-right", hasRightScroll ? "1" : "0");
      headerRef.value.setAttribute("data-has-scrollable-content", hasScrollableContentWithRightFixed ? "1" : "0");
      headerRef.value.style.setProperty("--left-shadow-position", `${leftShadowPosition}px`);
      headerRef.value.style.setProperty("--right-shadow-position", `${rightShadowPosition}px`);
    }
  };
  const updateContainerWidth = () => {
    if (bodyRef.value) {
      const container = bodyRef.value.parentElement;
      if (container) {
        const rect = container.getBoundingClientRect();
        containerWidth.value = Math.max(rect.width, props.minWidth);
        container.style.setProperty("--vant-highlight-color", props.highlightColor);
        container.style.setProperty("--vant-highlight-border-color", props.highlightBorderColor);
        container.style.setProperty("--vant-selected-row-color", props.selectedRowColor);
        container.style.setProperty("--vant-selected-row-border-color", props.selectedRowBorderColor);
        const wrapper = container.closest(".vant-table-wrapper");
        if (wrapper && wrapper !== container) {
          wrapper.style.setProperty("--vant-highlight-color", props.highlightColor);
          wrapper.style.setProperty("--vant-selected-row-color", props.selectedRowColor);
          wrapper.style.setProperty("--vant-highlight-border-color", props.highlightBorderColor);
          wrapper.style.setProperty("--vant-selected-row-border-color", props.selectedRowBorderColor);
          if (showHorizontalScrollbar.value) {
            wrapper.classList.add("has-horizontal-scrollbar");
          } else {
            wrapper.classList.remove("has-horizontal-scrollbar");
          }
        }
      }
    } else if (typeof props.width === "number") {
      containerWidth.value = props.width;
    }
    nextTick(() => {
      if (leftBodyWrapperRef.value) {
        const leftContainer = leftBodyWrapperRef.value.closest(".vant-table-fixed--left");
        if (leftContainer) {
          leftContainer.style.setProperty("--vant-highlight-color", props.highlightColor);
          leftContainer.style.setProperty("--vant-selected-row-color", props.selectedRowColor);
          leftContainer.style.setProperty("--vant-highlight-border-color", props.highlightBorderColor);
          leftContainer.style.setProperty("--vant-selected-row-border-color", props.selectedRowBorderColor);
          leftContainer.setAttribute("data-active-fix", "true");
        }
        leftBodyWrapperRef.value.style.setProperty("--vant-highlight-color", props.highlightColor);
        leftBodyWrapperRef.value.style.setProperty("--vant-selected-row-color", props.selectedRowColor);
        leftBodyWrapperRef.value.style.setProperty("--vant-highlight-border-color", props.highlightBorderColor);
        leftBodyWrapperRef.value.style.setProperty("--vant-selected-row-border-color", props.selectedRowBorderColor);
      }
      if (rightBodyWrapperRef.value) {
        const rightContainer = rightBodyWrapperRef.value.closest(".vant-table-fixed--right");
        if (rightContainer) {
          rightContainer.style.setProperty("--vant-highlight-color", props.highlightColor);
          rightContainer.style.setProperty("--vant-selected-row-color", props.selectedRowColor);
          rightContainer.style.setProperty("--vant-highlight-border-color", props.highlightBorderColor);
          rightContainer.style.setProperty("--vant-selected-row-border-color", props.selectedRowBorderColor);
          rightContainer.setAttribute("data-active-fix", "true");
        }
        rightBodyWrapperRef.value.style.setProperty("--vant-highlight-color", props.highlightColor);
        rightBodyWrapperRef.value.style.setProperty("--vant-selected-row-color", props.selectedRowColor);
        rightBodyWrapperRef.value.style.setProperty("--vant-highlight-border-color", props.highlightBorderColor);
        rightBodyWrapperRef.value.style.setProperty("--vant-selected-row-border-color", props.selectedRowBorderColor);
      }
      updateShadowState();
    });
  };
  return {
    updateShadowState,
    updateContainerWidth
  };
}
function useVantTableCore(props, emit, refs, composableResults) {
  const isDevelopment = ref(process.env.NODE_ENV === "development");
  const {
    layoutWrapperRef,
    bodyRef,
    headerRef,
    leftBodyWrapperRef,
    rightBodyWrapperRef
  } = refs;
  const {
    filteredAndSortedData,
    activeFilters,
    sortConfig,
    getCellValue,
    isRowTotal,
    columnsInfo,
    containerWidth,
    scrollLeft,
    hasLeftFixedContent,
    hasRightFixedColumns,
    leftFixedTotalWidth,
    showHorizontalScrollbar,
    hoveredRowIndex,
    selectedRowIndex,
    isRowDisabled,
    isRowSelected,
    handleRowSelect,
    selectedRows,
    selectedRowKeys,
    ensureSingleRowHighlight,
    touchHandledRowIndex
  } = composableResults;
  const { filteredAndSortedData: processedData, hasActiveFilters } = useDataProcessor(
    props,
    activeFilters,
    sortConfig,
    getCellValue,
    isRowTotal
  );
  const { createSingleHighlightController, monitorHighlightState } = useHighlightController(isDevelopment);
  const singleHighlightController = createSingleHighlightController();
  const {
    handleRowClickLocal,
    handleBatchDelete,
    lastRowClickTime,
    lastRowClickIndex
  } = useRowClickHandler(
    props,
    emit,
    isDevelopment,
    touchHandledRowIndex,
    selectedRowIndex,
    singleHighlightController,
    ensureSingleRowHighlight,
    isRowDisabled,
    isRowSelected,
    handleRowSelect
  );
  const { updateShadowState, updateContainerWidth } = useStyleUpdater(
    props,
    columnsInfo,
    containerWidth,
    scrollLeft,
    hasLeftFixedContent,
    hasRightFixedColumns,
    leftFixedTotalWidth,
    showHorizontalScrollbar,
    layoutWrapperRef,
    bodyRef,
    headerRef,
    leftBodyWrapperRef,
    rightBodyWrapperRef
  );
  const handleCellClick = (row, header, rowIndex, colIndex, event) => {
    var _a, _b;
    if (isDevelopment.value) {
      console.log("Cell clicked:", { rowIndex, headerKey: header.key });
    }
    const isCheckboxClick = (_a = event == null ? void 0 : event.target) == null ? void 0 : _a.closest(".vant-table-checkbox, .vant-table-radio, .vant-td--selection");
    const isEditButtonClick = (_b = event == null ? void 0 : event.target) == null ? void 0 : _b.closest('button, .van-button, [role="button"], .edit-btn, .action-btn');
    if (!isCheckboxClick && !isEditButtonClick) {
      const allHighlightClasses = [".vant-tr--selected", ".vant-tr--hover", ".vant-tr--active", ".vant-tr--highlighted", ".vant-tr--checkbox-selected"];
      allHighlightClasses.forEach((className) => {
        document.querySelectorAll(className).forEach((el) => {
          el.classList.remove(className.substring(1));
        });
      });
      document.querySelectorAll(`[data-row-index="${rowIndex}"]`).forEach((el) => {
        if (el.classList.contains("vant-tr")) {
          el.classList.add("vant-tr--selected");
        }
      });
      selectedRowIndex.value = rowIndex;
      if (isDevelopment.value) {
        console.log(`🎯 单行高亮控制: 第${rowIndex}行`);
      }
    } else {
      if (isDevelopment.value) {
        console.log(`🚫 复选框或编辑按钮点击，跳过单行高亮控制`);
      }
    }
    if (touchHandledRowIndex.value === rowIndex) {
      if (isDevelopment.value) {
        console.log(`Cell click ignored: row ${rowIndex} already handled by touch event`);
      }
      emit("cell-click", {
        row,
        column: header,
        rowIndex,
        colIndex,
        value: getCellValue(row, header.key)
      });
      return;
    }
    emit("cell-click", {
      row,
      column: header,
      rowIndex,
      colIndex,
      value: getCellValue(row, header.key)
    });
  };
  const handleSort = (header) => {
    if (!header.sortable)
      return;
    let newDirection = "asc";
    if (sortConfig.value.key === header.key) {
      if (sortConfig.value.direction === "asc") {
        newDirection = "desc";
      } else if (sortConfig.value.direction === "desc") {
        newDirection = null;
      }
    }
    sortConfig.value = {
      key: newDirection ? header.key : null,
      direction: newDirection
    };
    emit("sort-change", {
      key: header.key,
      direction: newDirection,
      column: header
    });
  };
  const getRowKey = (row, rowIndex) => {
    if (typeof props.rowKey === "function") {
      return props.rowKey(row, rowIndex);
    }
    return row[props.rowKey] || `row-${rowIndex}`;
  };
  const toggleExpand = (row, rowIndex) => {
    const key = getRowKey(row, rowIndex);
    const expandedRows = composableResults.expandedRows;
    if (expandedRows.value.has(key)) {
      expandedRows.value.delete(key);
    } else {
      expandedRows.value.add(key);
    }
    emit("expand-change", {
      row,
      rowIndex,
      expanded: expandedRows.value.has(key),
      expandedKeys: Array.from(expandedRows.value)
    });
    nextTick(() => {
      setTimeout(() => {
        composableResults.measureAndSyncRowHeights();
      }, 50);
    });
  };
  const isExpanded = (row, rowIndex) => {
    const key = getRowKey(row, rowIndex);
    return composableResults.expandedRows.value.has(key);
  };
  const handleRowMouseEnter = (rowIndex) => {
    if (hoveredRowIndex.value >= 0) {
      composableResults.applyRowState(hoveredRowIndex.value, "hover", false);
    }
    hoveredRowIndex.value = rowIndex;
    composableResults.applyRowState(rowIndex, "hover", true);
  };
  const handleRowMouseLeave = (rowIndex) => {
    if (hoveredRowIndex.value === rowIndex) {
      composableResults.applyRowState(rowIndex, "hover", false);
      hoveredRowIndex.value = -1;
    }
  };
  const isRadioMode = computed(() => props.selectMode === "radio");
  const filterableHeadersWithState = computed(() => {
    return props.headers.filter((header) => header.filterable);
  });
  const filterOptions = computed(() => {
    const options = {};
    props.headers.forEach((header) => {
      if (header.filterable) {
        const uniqueValues = [
          ...new Set(
            props.data.map((row) => getCellValue(row, header.key)).filter((value) => value != null && value !== "").map((value) => String(value))
          )
        ].slice(0, 10);
        options[header.key] = uniqueValues;
      }
    });
    return options;
  });
  const initializeTable = () => {
    updateContainerWidth();
    updateShadowState();
    if (isDevelopment.value) {
      monitorHighlightState(singleHighlightController);
    }
  };
  return {
    // 核心状态
    isDevelopment,
    isRadioMode,
    singleHighlightController,
    // 数据处理
    filteredAndSortedData: processedData,
    hasActiveFilters,
    filterableHeadersWithState,
    filterOptions,
    // 事件处理
    handleRowClickLocal,
    handleCellClick,
    handleSort,
    handleBatchDelete,
    handleRowMouseEnter,
    handleRowMouseLeave,
    // 功能函数
    getRowKey,
    toggleExpand,
    isExpanded,
    updateShadowState,
    updateContainerWidth,
    initializeTable,
    // 调试相关
    lastRowClickTime,
    lastRowClickIndex
  };
}
function useScrollUtils(bodyRef, leftBodyWrapperRef, rightBodyWrapperRef, scrollTop, scrollLeft, isLoadingMore, vxeStyleAbsoluteSync, isDevelopment) {
  const getGlobalMaxScrollTop = () => {
    if (!bodyRef.value)
      return 0;
    const mainScrollHeight = bodyRef.value.scrollHeight;
    const mainClientHeight = bodyRef.value.clientHeight;
    const mainMaxScrollTop = Math.max(0, mainScrollHeight - mainClientHeight);
    let globalMaxScrollTop = mainMaxScrollTop;
    if (isDevelopment.value) {
      console.log("🔍 getGlobalMaxScrollTop 计算详情:", {
        主表格scrollHeight: mainScrollHeight,
        主表格clientHeight: mainClientHeight,
        主表格maxScrollTop: mainMaxScrollTop
      });
    }
    if (leftBodyWrapperRef.value) {
      const leftScrollHeight = leftBodyWrapperRef.value.scrollHeight;
      const leftClientHeight = leftBodyWrapperRef.value.clientHeight;
      const leftMaxScrollTop = Math.max(0, leftScrollHeight - leftClientHeight);
      if (isDevelopment.value) {
        console.log("🔍 左固定列高度详情:", {
          左固定列scrollHeight: leftScrollHeight,
          左固定列clientHeight: leftClientHeight,
          左固定列maxScrollTop: leftMaxScrollTop,
          与主表格高度差: Math.abs(leftScrollHeight - mainScrollHeight)
        });
      }
      globalMaxScrollTop = Math.min(globalMaxScrollTop, leftMaxScrollTop);
    }
    if (rightBodyWrapperRef.value) {
      const rightScrollHeight = rightBodyWrapperRef.value.scrollHeight;
      const rightClientHeight = rightBodyWrapperRef.value.clientHeight;
      const rightMaxScrollTop = Math.max(0, rightScrollHeight - rightClientHeight);
      if (isDevelopment.value) {
        console.log("🔍 右固定列高度详情:", {
          右固定列scrollHeight: rightScrollHeight,
          右固定列clientHeight: rightClientHeight,
          右固定列maxScrollTop: rightMaxScrollTop,
          与主表格高度差: Math.abs(rightScrollHeight - mainScrollHeight)
        });
      }
      globalMaxScrollTop = Math.min(globalMaxScrollTop, rightMaxScrollTop);
    }
    if (isDevelopment.value) {
      console.log("🎯 最终全局边界约束结果:", {
        最终globalMaxScrollTop: Math.max(0, globalMaxScrollTop),
        原始主表格maxScrollTop: mainMaxScrollTop,
        被约束程度: mainMaxScrollTop - Math.max(0, globalMaxScrollTop)
      });
    }
    return Math.max(0, globalMaxScrollTop);
  };
  const safeSetScrollPosition = (targetScrollTop, forceSet = false) => {
    if (!bodyRef.value)
      return;
    const finalScrollTop = forceSet ? targetScrollTop : Math.max(0, Math.min(getGlobalMaxScrollTop(), targetScrollTop));
    bodyRef.value.scrollTop = finalScrollTop;
    scrollTop.value = finalScrollTop;
    if (leftBodyWrapperRef.value) {
      leftBodyWrapperRef.value.scrollTop = finalScrollTop;
    }
    if (rightBodyWrapperRef.value) {
      rightBodyWrapperRef.value.scrollTop = finalScrollTop;
    }
    if (isDevelopment.value) {
      console.log("Safe scroll position set:", {
        target: targetScrollTop,
        final: finalScrollTop,
        constrained: !forceSet,
        globalMax: getGlobalMaxScrollTop()
      });
    }
  };
  const syncScroll = () => {
    if (isLoadingMore.value && isDevelopment.value) {
      console.log("syncScroll: 加载更多期间仍进行同步，保持表格一体性");
    }
    if (!bodyRef.value) {
      return;
    }
    const currentScrollTop = bodyRef.value.scrollTop || 0;
    const currentScrollLeft = bodyRef.value.scrollLeft || 0;
    vxeStyleAbsoluteSync(currentScrollTop, currentScrollLeft);
  };
  const detectIOSSafari = () => {
    const ua = navigator.userAgent.toLowerCase();
    return /iphone|ipad|ipod/.test(ua) && /safari/.test(ua) && !/chrome|firefox|opera/.test(ua);
  };
  return {
    getGlobalMaxScrollTop,
    safeSetScrollPosition,
    syncScroll,
    detectIOSSafari
  };
}
function useFilterUtils(filterStates, activeFilters, filterOptions, emit, isDevelopment) {
  const filterComputedCache = /* @__PURE__ */ new Map();
  const isFilterActive = (key) => {
    return activeFilters.value[key] && activeFilters.value[key].value;
  };
  const getFilterShowState = (key) => {
    var _a;
    return ((_a = filterStates.value[key]) == null ? void 0 : _a.show) || false;
  };
  const getFilterType = (key) => {
    var _a;
    return ((_a = filterStates.value[key]) == null ? void 0 : _a.type) || "contains";
  };
  const getFilterValue = (key) => {
    var _a;
    return ((_a = filterStates.value[key]) == null ? void 0 : _a.value) || "";
  };
  const setFilterType = (key, type) => {
    ensureFilterState(key);
    filterStates.value[key].type = type;
  };
  const setFilterValue = (key, value) => {
    ensureFilterState(key);
    filterStates.value[key].value = value;
  };
  const ensureFilterState = (key) => {
    if (!filterStates.value[key]) {
      filterStates.value[key] = {
        show: false,
        type: "contains",
        value: ""
      };
    }
  };
  const getFilterTypeComputed = (key) => {
    const cacheKey = `type-${key}`;
    if (!filterComputedCache.has(cacheKey)) {
      filterComputedCache.set(cacheKey, computed({
        get: () => {
          ensureFilterState(key);
          return filterStates.value[key].type;
        },
        set: (value) => {
          ensureFilterState(key);
          filterStates.value[key].type = value;
        }
      }));
    }
    return filterComputedCache.get(cacheKey);
  };
  const getFilterShowStateComputed = (key) => {
    const cacheKey = `show-${key}`;
    if (!filterComputedCache.has(cacheKey)) {
      filterComputedCache.set(cacheKey, computed({
        get: () => {
          ensureFilterState(key);
          return filterStates.value[key].show;
        },
        set: (value) => {
          ensureFilterState(key);
          filterStates.value[key].show = value;
        }
      }));
    }
    return filterComputedCache.get(cacheKey);
  };
  const getFilterValueComputed = (key) => {
    const cacheKey = `value-${key}`;
    if (!filterComputedCache.has(cacheKey)) {
      filterComputedCache.set(cacheKey, computed({
        get: () => {
          ensureFilterState(key);
          return filterStates.value[key].value;
        },
        set: (value) => {
          ensureFilterState(key);
          filterStates.value[key].value = value;
        }
      }));
    }
    return filterComputedCache.get(cacheKey);
  };
  const toggleFilter = (key) => {
    ensureFilterState(key);
    const currentState = filterStates.value[key];
    if (!currentState)
      return;
    if (currentState.show) {
      currentState.show = false;
      return;
    }
    Object.keys(filterStates.value).forEach((filterKey) => {
      if (filterKey !== key && filterStates.value[filterKey]) {
        filterStates.value[filterKey].show = false;
      }
    });
    currentState.show = true;
  };
  const closeAllFilterPopups = () => {
    if (filterStates.value) {
      Object.keys(filterStates.value).forEach((key) => {
        if (filterStates.value[key]) {
          filterStates.value[key].show = false;
        }
      });
    }
  };
  const onClickOverlay = () => {
    closeAllFilterPopups();
  };
  const handleFilterClose = (key) => {
    if (filterStates.value && filterStates.value[key]) {
      filterStates.value[key].show = false;
    }
  };
  const selectFilterOption = (key, option) => {
    if (filterStates.value[key]) {
      filterStates.value[key].value = option;
    }
  };
  const applyFilter = (key) => {
    const filter = filterStates.value[key];
    if (!filter)
      return;
    filter.show = false;
    if (filter.value && filter.value.trim() && !activeFilters.value[key]) {
      activeFilters.value[key] = {
        type: "contains",
        value: filter.value.trim()
      };
      emit("filter-change", {
        key,
        filter: activeFilters.value[key] || null,
        allFilters: { ...activeFilters.value }
      });
    }
  };
  const clearFilter = (key) => {
    const filter = filterStates.value[key];
    if (!filter)
      return;
    filter.value = "";
    filter.show = false;
    delete activeFilters.value[key];
    emit("filter-change", {
      key,
      filter: null,
      allFilters: { ...activeFilters.value }
    });
  };
  const getFilteredOptions = (key) => {
    var _a;
    const allOptions = filterOptions.value[key] || [];
    const searchValue = ((_a = filterStates.value[key]) == null ? void 0 : _a.value) || "";
    if (!searchValue) {
      return allOptions;
    }
    return allOptions.filter(
      (option) => String(option).toLowerCase().includes(searchValue.toLowerCase())
    );
  };
  const isOptionSelected = (key, option) => {
    const activeFilter = activeFilters.value[key];
    if (!activeFilter || !activeFilter.values) {
      return false;
    }
    return activeFilter.values.includes(option);
  };
  const toggleFilterOption = (key, option) => {
    ensureFilterState(key);
    if (!activeFilters.value[key]) {
      activeFilters.value[key] = {
        type: "multiSelect",
        values: []
      };
    }
    const values = activeFilters.value[key].values || [];
    const index = values.indexOf(option);
    if (index >= 0) {
      values.splice(index, 1);
    } else {
      values.push(option);
    }
    if (values.length === 0) {
      delete activeFilters.value[key];
    }
    emit("filter-change", {
      key,
      filter: activeFilters.value[key] || null,
      allFilters: { ...activeFilters.value }
    });
  };
  const selectAllFilterOptions = (key) => {
    var _a;
    ensureFilterState(key);
    const isAllSelected = !activeFilters.value[key] || ((_a = activeFilters.value[key].values) == null ? void 0 : _a.length) === 0;
    if (isAllSelected) {
      const allVisibleOptions = getFilteredOptions(key);
      activeFilters.value[key] = {
        type: "multiSelect",
        values: [...allVisibleOptions]
      };
    } else {
      delete activeFilters.value[key];
    }
    emit("filter-change", {
      key,
      filter: activeFilters.value[key] || null,
      allFilters: { ...activeFilters.value }
    });
  };
  const resetFilter = (key) => {
    ensureFilterState(key);
    const filter = filterStates.value[key];
    filter.value = "";
    filter.show = false;
    delete activeFilters.value[key];
    emit("filter-change", {
      key,
      filter: null,
      allFilters: { ...activeFilters.value }
    });
  };
  return {
    // 基础状态方法
    isFilterActive,
    getFilterShowState,
    getFilterType,
    getFilterValue,
    setFilterType,
    setFilterValue,
    ensureFilterState,
    // 计算属性方法
    getFilterTypeComputed,
    getFilterShowStateComputed,
    getFilterValueComputed,
    // 过滤器控制方法
    toggleFilter,
    closeAllFilterPopups,
    onClickOverlay,
    handleFilterClose,
    selectFilterOption,
    applyFilter,
    clearFilter,
    // VTable风格过滤方法
    getFilteredOptions,
    isOptionSelected,
    toggleFilterOption,
    selectAllFilterOptions,
    resetFilter
  };
}
function useCellUtils(props, getCellValue, isRowSelected, isRowTotal) {
  const EXPAND_WIDTH = 40;
  const SELECTION_WIDTH = 48;
  const renderCustomCell = (value, row, column, rowIndex, colIndex) => {
    if (typeof column.renderCell === "function") {
      const result = column.renderCell(value, row, column, rowIndex, colIndex, h);
      if (result && typeof result === "object" && result.type) {
        return result;
      }
      if (typeof result === "string" || typeof result === "number") {
        return h("span", result);
      }
      return h("span", String(value || ""));
    }
    return h("span", String(value || ""));
  };
  const getDataBarStyle = (value, key) => {
    return {
      width: "0%",
      backgroundColor: "var(--van-primary-color)",
      transition: "width 0.3s ease"
    };
  };
  const getHeaderClass = (header) => {
    const classes = ["vant-th"];
    if (header.sortable)
      classes.push("vant-th--sortable");
    return classes;
  };
  const getHeaderStyle = (header) => {
    return {
      width: `${header.computedWidth}px`,
      minWidth: `${header.computedWidth}px`,
      maxWidth: `${header.computedWidth}px`,
      textAlign: header.align || "left",
      boxSizing: "border-box",
      height: "auto",
      minHeight: "48px",
      lineHeight: "1.4",
      padding: "8px 12px",
      verticalAlign: "middle"
    };
  };
  const getCellClass = (header, row, rowIndex) => {
    const classes = ["vant-td"];
    if (props.highlightIndex === rowIndex)
      classes.push("vant-td--highlighted");
    if (header.link)
      classes.push("vant-td--link");
    return classes;
  };
  const getCellStyle = (header) => {
    return {
      width: `${header.computedWidth}px`,
      minWidth: `${header.computedWidth}px`,
      maxWidth: `${header.computedWidth}px`,
      textAlign: header.align || "left",
      boxSizing: "border-box",
      // 🔑 关键修复：添加文本换行支持，避免内容溢出
      whiteSpace: "normal",
      wordWrap: "break-word",
      wordBreak: "break-all",
      padding: "8px 12px",
      verticalAlign: "top",
      // 改为顶部对齐，支持多行内容
      lineHeight: "1.4"
    };
  };
  const getFixedHeaderClass = (header, position) => {
    const classes = ["vant-th", "vant-th--fixed"];
    if (header === "selection") {
      classes.push("vant-th--selection");
    } else if (header === "expand") {
      classes.push("vant-th--expand");
    } else {
      if (header.sortable)
        classes.push("vant-th--sortable");
    }
    classes.push(`vant-th--fixed-${position}`);
    return classes;
  };
  const getFixedHeaderStyle = (header) => {
    return {
      width: `${header.computedWidth}px`,
      minWidth: `${header.computedWidth}px`,
      maxWidth: `${header.computedWidth}px`,
      textAlign: header.align || "left",
      boxSizing: "border-box",
      height: "auto",
      minHeight: "48px",
      lineHeight: "1.4",
      padding: "8px 12px",
      verticalAlign: "middle"
    };
  };
  const getFixedCellClass = (header, row, rowIndex, position) => {
    const classes = ["vant-td", "vant-td--fixed"];
    if (header === "selection") {
      classes.push("vant-td--selection");
    } else if (header === "expand") {
      classes.push("vant-td--expand");
    } else {
      if (props.highlightIndex === rowIndex)
        classes.push("vant-td--highlighted");
      if (header.link)
        classes.push("vant-td--link");
    }
    classes.push(`vant-td--fixed-${position}`);
    return classes;
  };
  const getFixedCellStyle = (header) => {
    return {
      width: `${header.computedWidth}px`,
      minWidth: `${header.computedWidth}px`,
      maxWidth: `${header.computedWidth}px`,
      textAlign: header.align || "left",
      boxSizing: "border-box"
    };
  };
  const getRowClass = (index, row) => {
    const classes = ["vant-tr"];
    if (isRowTotal(row))
      classes.push("vant-tr--total");
    if (props.striped && index % 2 === 1)
      classes.push("vant-tr--striped");
    if (props.highlightIndex === index)
      classes.push("vant-tr--highlighted");
    if (isRowSelected(row, index))
      classes.push("vant-tr--checkbox-selected");
    return classes;
  };
  const formatCellValue = (value, header) => {
    if (value == null)
      return "";
    switch (header.type) {
      case "number":
        return typeof value === "number" ? value.toLocaleString() : value;
      case "percent":
        return typeof value === "number" ? `${value}%` : value;
      case "currency":
        return typeof value === "number" ? `¥${value.toLocaleString()}` : value;
      default:
        return value;
    }
  };
  const getSelectionHeaderStyle = () => ({
    width: `${SELECTION_WIDTH}px`,
    minWidth: `${SELECTION_WIDTH}px`,
    maxWidth: `${SELECTION_WIDTH}px`,
    textAlign: "center",
    height: "auto",
    minHeight: "48px",
    lineHeight: "1.4",
    padding: "8px 12px",
    verticalAlign: "middle"
  });
  const getSelectionCellStyle = () => ({
    width: `${SELECTION_WIDTH}px`,
    minWidth: `${SELECTION_WIDTH}px`,
    maxWidth: `${SELECTION_WIDTH}px`,
    textAlign: "center"
  });
  const getExpandHeaderStyle = () => ({
    width: `${EXPAND_WIDTH}px`,
    minWidth: `${EXPAND_WIDTH}px`,
    maxWidth: `${EXPAND_WIDTH}px`,
    textAlign: "center",
    height: "auto",
    minHeight: "48px",
    lineHeight: "1.4",
    padding: "8px 12px",
    verticalAlign: "middle"
  });
  const getExpandCellStyle = () => ({
    width: `${EXPAND_WIDTH}px`,
    minWidth: `${EXPAND_WIDTH}px`,
    maxWidth: `${EXPAND_WIDTH}px`,
    textAlign: "center"
  });
  return {
    renderCustomCell,
    getDataBarStyle,
    getHeaderClass,
    getHeaderStyle,
    getCellClass,
    getCellStyle,
    getFixedHeaderClass,
    getFixedHeaderStyle,
    getFixedCellClass,
    getFixedCellStyle,
    getRowClass,
    formatCellValue,
    getSelectionHeaderStyle,
    getSelectionCellStyle,
    getExpandHeaderStyle,
    getExpandCellStyle
  };
}
function useStickyStyles(props, columnsInfo, SELECTION_WIDTH, EXPAND_WIDTH) {
  const getStickyHeaderClass = (header, fixed) => {
    const classes = ["vant-th"];
    if (header === "selection") {
      classes.push("vant-th--selection", "vant-th--sticky");
      if (!props.expandable && columnsInfo.value.leftFixedColumns.length === 0) {
        classes.push("vant-th--sticky-left-last");
      }
    } else if (header === "expand") {
      classes.push("vant-th--expand", "vant-th--sticky");
      if (columnsInfo.value.leftFixedColumns.length === 0) {
        classes.push("vant-th--sticky-left-last");
      }
    } else {
      if (header.sortable)
        classes.push("vant-th--sortable");
      if (fixed) {
        classes.push("vant-th--sticky", `vant-th--sticky-${fixed}`);
        if (fixed === "left") {
          const leftIndex = columnsInfo.value.leftFixedColumns.findIndex((h2) => h2.key === header.key);
          if (leftIndex === columnsInfo.value.leftFixedColumns.length - 1) {
            classes.push("vant-th--sticky-left-last");
          }
        }
        if (fixed === "right") {
          const rightIndex = columnsInfo.value.rightFixedColumns.findIndex((h2) => h2.key === header.key);
          if (rightIndex === 0) {
            classes.push("vant-th--sticky-right-first");
          }
        }
      }
    }
    return classes;
  };
  const getStickyHeaderStyle = (header, fixed) => {
    const baseStyle = {};
    if (header === "selection") {
      baseStyle.width = `${SELECTION_WIDTH}px`;
      baseStyle.minWidth = `${SELECTION_WIDTH}px`;
      baseStyle.maxWidth = `${SELECTION_WIDTH}px`;
      baseStyle.textAlign = "center";
      baseStyle.position = "sticky";
      baseStyle.left = "0px";
      baseStyle.zIndex = "100";
      baseStyle.backgroundColor = "var(--van-background)";
    } else if (header === "expand") {
      baseStyle.width = `${EXPAND_WIDTH}px`;
      baseStyle.minWidth = `${EXPAND_WIDTH}px`;
      baseStyle.maxWidth = `${EXPAND_WIDTH}px`;
      baseStyle.textAlign = "center";
      baseStyle.position = "sticky";
      baseStyle.left = props.selectable ? `${SELECTION_WIDTH}px` : "0px";
      baseStyle.zIndex = "100";
      baseStyle.backgroundColor = "var(--van-background)";
    } else {
      baseStyle.width = `${header.computedWidth}px`;
      baseStyle.minWidth = `${header.computedWidth}px`;
      baseStyle.maxWidth = `${header.computedWidth}px`;
      baseStyle.textAlign = header.align || "left";
      baseStyle.boxSizing = "border-box";
      if (fixed === "left") {
        let leftOffset = 0;
        if (props.selectable)
          leftOffset += SELECTION_WIDTH;
        if (props.expandable)
          leftOffset += EXPAND_WIDTH;
        const leftIndex = columnsInfo.value.leftFixedColumns.findIndex((h2) => h2.key === header.key);
        if (leftIndex >= 0) {
          for (let i = 0; i < leftIndex; i++) {
            leftOffset += columnsInfo.value.leftFixedColumns[i].computedWidth;
          }
        }
        baseStyle.position = "sticky";
        baseStyle.left = `${leftOffset}px`;
        baseStyle.zIndex = "100";
        baseStyle.backgroundColor = "var(--van-background)";
      } else if (fixed === "right") {
        let rightOffset = 0;
        const rightIndex = columnsInfo.value.rightFixedColumns.findIndex((h2) => h2.key === header.key);
        if (rightIndex >= 0) {
          for (let i = rightIndex + 1; i < columnsInfo.value.rightFixedColumns.length; i++) {
            rightOffset += columnsInfo.value.rightFixedColumns[i].computedWidth;
          }
        }
        baseStyle.position = "sticky";
        baseStyle.right = `${rightOffset}px`;
        baseStyle.zIndex = "100";
        baseStyle.backgroundColor = "var(--van-background)";
      }
    }
    return baseStyle;
  };
  const getStickyColumnClass = (header, fixed) => {
    const classes = ["vant-td"];
    if (header === "selection") {
      classes.push("vant-td--selection", "vant-td--sticky");
      if (!props.expandable && columnsInfo.value.leftFixedColumns.length === 0) {
        classes.push("vant-td--sticky-left-last");
      }
    } else if (header === "expand") {
      classes.push("vant-td--expand", "vant-td--sticky");
      if (columnsInfo.value.leftFixedColumns.length === 0) {
        classes.push("vant-td--sticky-left-last");
      }
    } else {
      if (fixed) {
        classes.push("vant-td--sticky", `vant-td--sticky-${fixed}`);
        if (fixed === "left") {
          const leftIndex = columnsInfo.value.leftFixedColumns.findIndex((h2) => h2.key === header.key);
          if (leftIndex === columnsInfo.value.leftFixedColumns.length - 1) {
            classes.push("vant-td--sticky-left-last");
          }
        }
        if (fixed === "right") {
          const rightIndex = columnsInfo.value.rightFixedColumns.findIndex((h2) => h2.key === header.key);
          if (rightIndex === 0) {
            classes.push("vant-td--sticky-right-first");
          }
        }
      }
    }
    return classes;
  };
  const getStickyColumnStyle = (header, fixed) => {
    const baseStyle = {};
    if (header === "selection") {
      baseStyle.width = `${SELECTION_WIDTH}px`;
      baseStyle.minWidth = `${SELECTION_WIDTH}px`;
      baseStyle.maxWidth = `${SELECTION_WIDTH}px`;
      baseStyle.textAlign = "center";
      baseStyle.position = "sticky";
      baseStyle.left = "0px";
      baseStyle.zIndex = "90";
      baseStyle.backgroundColor = "var(--van-white)";
    } else if (header === "expand") {
      baseStyle.width = `${EXPAND_WIDTH}px`;
      baseStyle.minWidth = `${EXPAND_WIDTH}px`;
      baseStyle.maxWidth = `${EXPAND_WIDTH}px`;
      baseStyle.textAlign = "center";
      baseStyle.position = "sticky";
      baseStyle.left = props.selectable ? `${SELECTION_WIDTH}px` : "0px";
      baseStyle.zIndex = "90";
      baseStyle.backgroundColor = "var(--van-white)";
    } else {
      baseStyle.width = `${header.computedWidth}px`;
      baseStyle.minWidth = `${header.computedWidth}px`;
      baseStyle.maxWidth = `${header.computedWidth}px`;
      baseStyle.textAlign = header.align || "left";
      baseStyle.boxSizing = "border-box";
      if (fixed === "left") {
        let leftOffset = 0;
        if (props.selectable)
          leftOffset += SELECTION_WIDTH;
        if (props.expandable)
          leftOffset += EXPAND_WIDTH;
        const leftIndex = columnsInfo.value.leftFixedColumns.findIndex((h2) => h2.key === header.key);
        if (leftIndex >= 0) {
          for (let i = 0; i < leftIndex; i++) {
            leftOffset += columnsInfo.value.leftFixedColumns[i].computedWidth;
          }
        }
        baseStyle.position = "sticky";
        baseStyle.left = `${leftOffset}px`;
        baseStyle.zIndex = "90";
        baseStyle.backgroundColor = "var(--van-white)";
      } else if (fixed === "right") {
        let rightOffset = 0;
        const rightIndex = columnsInfo.value.rightFixedColumns.findIndex((h2) => h2.key === header.key);
        if (rightIndex >= 0) {
          for (let i = rightIndex + 1; i < columnsInfo.value.rightFixedColumns.length; i++) {
            rightOffset += columnsInfo.value.rightFixedColumns[i].computedWidth;
          }
        }
        baseStyle.position = "sticky";
        baseStyle.right = `${rightOffset}px`;
        baseStyle.zIndex = "90";
        baseStyle.backgroundColor = "var(--van-white)";
      }
    }
    return baseStyle;
  };
  return {
    getStickyHeaderClass,
    getStickyHeaderStyle,
    getStickyColumnClass,
    getStickyColumnStyle
  };
}
function useTableDebug(containerWidth, columnsInfo, scrollLeft, scrollTop, filteredAndSortedData, selectedRows, selectedRowKeys, isAllSelected, isIndeterminate, selectableRows, dynamicHeaderHeight, dynamicRowHeights, showHorizontalScrollbar, headerRowRef, leftHeaderRowRef, rightHeaderRowRef, forceHeaderSync, isDevelopment) {
  const enableDebug = () => {
    console.log("=== 表格调试信息 ===");
    console.log("容器宽度:", containerWidth.value);
    console.log("列信息:", columnsInfo.value);
    console.log("滚动位置:", { scrollLeft: scrollLeft.value, scrollTop: scrollTop.value });
    console.log("数据长度:", filteredAndSortedData.value.length);
    console.log("选择状态:", {
      选中行数: selectedRows.value.length,
      选中键值: selectedRowKeys.value,
      全选状态: isAllSelected.value,
      半选状态: isIndeterminate.value,
      可选行数: selectableRows.value.length
    });
    console.log("动态尺寸:", {
      表头高度: dynamicHeaderHeight.value,
      行高度映射: Object.fromEntries(dynamicRowHeights.value)
    });
    console.log("横向滚动条:", {
      显示: showHorizontalScrollbar.value,
      容器宽度: containerWidth.value,
      总宽度: columnsInfo.value.totalWidth
    });
  };
  const quickDebug = () => {
    console.log("=== 快速调试 ===");
    console.log("主表格行数:", filteredAndSortedData.value.length);
    console.log("当前动态高度:", {
      表头: dynamicHeaderHeight.value,
      行数: dynamicRowHeights.value.size
    });
    console.log("滚动状态:", { scrollLeft: scrollLeft.value, scrollTop: scrollTop.value });
    console.log("选择状态:", {
      选中: selectedRows.value.length,
      键值: selectedRowKeys.value,
      可选: selectableRows.value.length
    });
    forceHeaderSync();
  };
  const checkAlignment = () => {
    console.log("=== 高度对齐检查 ===");
    const headerRows = [headerRowRef.value, leftHeaderRowRef.value, rightHeaderRowRef.value].filter(
      Boolean
    );
    const headerHeights = headerRows.map((row, index) => {
      const rect = row.getBoundingClientRect();
      const area = ["主表头", "左表头", "右表头"][index];
      return { area, height: Math.round(rect.height * 10) / 10 };
    });
    console.log("表头高度:", headerHeights);
    console.log("行高度映射:", Object.fromEntries(dynamicRowHeights.value));
  };
  return {
    enableDebug,
    quickDebug,
    checkAlignment
  };
}
function useScrollRestore(bodyRef, leftBodyWrapperRef, rightBodyWrapperRef, scrollTop, scrollLeft, savedScrollPosition, hoveredRowIndex, applyRowState, vxeStyleAbsoluteSync, intoRunScroll, lastScrollTop, isDevelopment) {
  const restoreScrollPositionForIOS = () => {
    if (!bodyRef.value || savedScrollPosition.value <= 0)
      return;
    const positionToRestore = savedScrollPosition.value;
    if (isDevelopment.value) {
      console.log("iOS Safari: 恢复滚动位置:", positionToRestore);
    }
    bodyRef.value.scrollTop = positionToRestore;
    scrollTop.value = positionToRestore;
    if (leftBodyWrapperRef.value) {
      leftBodyWrapperRef.value.scrollTop = positionToRestore;
    }
    if (rightBodyWrapperRef.value) {
      rightBodyWrapperRef.value.scrollTop = positionToRestore;
    }
    if (hoveredRowIndex.value >= 0) {
      applyRowState(hoveredRowIndex.value, "hover", false);
      nextTick(() => {
        const mouseEvent = new MouseEvent("mousemove", {
          bubbles: true,
          cancelable: true,
          clientX: 0,
          clientY: 0
        });
        if (bodyRef.value) {
          bodyRef.value.dispatchEvent(mouseEvent);
        }
        if (isDevelopment.value) {
          console.log("iOS: 重新触发hover计算，统一使用主表格逻辑");
        }
      });
    }
    if (isDevelopment.value) {
      console.log("iOS Safari: 滚动位置恢复完成:", positionToRestore);
    }
    setTimeout(() => {
      if (isDevelopment.value) {
        console.log("iOS VXE风格绝对同步");
      }
      vxeStyleAbsoluteSync(positionToRestore, scrollLeft.value);
    }, 100);
  };
  const restoreScrollLocationWithoutConstraint = (targetScrollTop) => {
    return new Promise((resolve) => {
      if (bodyRef.value && targetScrollTop > 0) {
        intoRunScroll.value = true;
        if (isDevelopment.value) {
          console.log("无约束恢复滚动位置:", {
            目标位置: targetScrollTop,
            当前scrollHeight: bodyRef.value.scrollHeight,
            当前clientHeight: bodyRef.value.clientHeight
          });
        }
        bodyRef.value.scrollTop = targetScrollTop;
        scrollTop.value = targetScrollTop;
        if (leftBodyWrapperRef.value) {
          leftBodyWrapperRef.value.scrollTop = targetScrollTop;
        }
        if (rightBodyWrapperRef.value) {
          rightBodyWrapperRef.value.scrollTop = targetScrollTop;
        }
        lastScrollTop.value = targetScrollTop;
        requestAnimationFrame(() => {
          setTimeout(() => {
            intoRunScroll.value = false;
            resolve();
          }, 50);
        });
      } else {
        resolve();
      }
    });
  };
  const restoreScrollLocation = (targetScrollTop = lastScrollTop.value) => {
    return new Promise((resolve) => {
      if (bodyRef.value && targetScrollTop > 0) {
        intoRunScroll.value = true;
        const maxScrollTop = bodyRef.value.scrollHeight - bodyRef.value.clientHeight;
        const safeScrollTop = Math.max(0, Math.min(maxScrollTop, targetScrollTop));
        if (isDevelopment.value) {
          console.log("VXE 风格恢复滚动位置:", {
            目标位置: targetScrollTop,
            安全位置: safeScrollTop,
            最大位置: maxScrollTop
          });
        }
        bodyRef.value.scrollTop = safeScrollTop;
        scrollTop.value = safeScrollTop;
        if (leftBodyWrapperRef.value) {
          leftBodyWrapperRef.value.scrollTop = safeScrollTop;
        }
        if (rightBodyWrapperRef.value) {
          rightBodyWrapperRef.value.scrollTop = safeScrollTop;
        }
        lastScrollTop.value = safeScrollTop;
        setTimeout(() => {
          if (bodyRef.value && Math.abs(bodyRef.value.scrollTop - safeScrollTop) > 5) {
            bodyRef.value.scrollTop = safeScrollTop;
          }
          resolve();
        }, 50);
      } else {
        resolve();
      }
    });
  };
  return {
    restoreScrollPositionForIOS,
    restoreScrollLocationWithoutConstraint,
    restoreScrollLocation
  };
}
function useTableSetup(props, emit, refs) {
  const {
    headerRef,
    headerContentRef,
    headerRowRef,
    leftHeaderRowRef,
    rightHeaderRowRef,
    bodyRef,
    tbodyRef,
    leftFixedRef,
    leftBodyWrapperRef,
    leftTbodyRef,
    rightFixedRef,
    rightBodyWrapperRef,
    rightTbodyRef,
    layoutWrapperRef,
    scrollbarWrapperRef,
    scrollbarHandleRef,
    tableHeaderRef,
    leftFixedColumnRef,
    rightFixedColumnRef,
    horizontalScrollbarRef
  } = refs;
  const dynamicHeaderHeight = ref(48);
  const dynamicRowHeights = ref(/* @__PURE__ */ new Map());
  const expandedRowHeights = ref(/* @__PURE__ */ new Map());
  const isHeaderSyncing = ref(false);
  const isRowSyncing = ref(false);
  const headerElementRefs = ref({});
  const rowElementRefs = ref({});
  const internalSelectedKeys = ref(new Set(props.selectedKeys || []));
  const lastSelectedIndex = ref(-1);
  const containerWidth = ref(0);
  const scrollLeft = ref(0);
  const scrollTop = ref(0);
  const lastScrollLeft = ref(0);
  const updateContainerWidth = () => {
    if (typeof props.width === "number") {
      containerWidth.value = props.width;
      return;
    }
    if (layoutWrapperRef == null ? void 0 : layoutWrapperRef.value) {
      const rect = layoutWrapperRef.value.getBoundingClientRect();
      const newWidth = Math.floor(rect.width);
      if (newWidth > 0 && newWidth !== containerWidth.value) {
        containerWidth.value = Math.max(newWidth, props.minWidth || 0);
        return;
      }
    }
    if (containerWidth.value === 0) {
      containerWidth.value = 375;
    }
  };
  const initializeTable = () => {
    updateContainerWidth();
    nextTick(() => {
      updateContainerWidth();
      setTimeout(() => {
        updateContainerWidth();
      }, 100);
    });
  };
  watch(() => props.width, () => {
    updateContainerWidth();
  }, { immediate: true });
  const rawData = computed(() => props.data);
  const tableState = useTableState(
    props,
    emit,
    bodyRef
  );
  const tempFilteredData = ref([]);
  const tableComputed = useTableComputed(
    props,
    containerWidth,
    scrollTop,
    scrollLeft,
    tableState.headerHeight,
    tempFilteredData,
    // 先用ref，稍后更新
    tableState.rowHeightMap
  );
  const reactivePropsForScrollHandlers = computed(() => {
    var _a;
    return {
      ...props,
      columnsInfo: (_a = tableComputed.columnsInfo) == null ? void 0 : _a.value,
      containerWidth: containerWidth.value
    };
  });
  const tableFilters = useTableFilters(
    props,
    rawData,
    tableComputed.columnsInfo,
    true
    // isDevelopment
  );
  const tableSorting = useTableSorting(
    props,
    emit,
    tableFilters.filteredData,
    true
    // isDevelopment
  );
  const filteredAndSortedData = computed(() => {
    var _a;
    const result = ((_a = tableSorting.sortedData) == null ? void 0 : _a.value) || [];
    tempFilteredData.value = result;
    return result;
  });
  const rowHighlight = useRowHighlight(
    true,
    // isDevelopment
    rowElementRefs,
    tableState.hoveredRowIndex,
    tableState.selectedRowIndex
  );
  const tableSelection = useSelection(
    props,
    emit,
    filteredAndSortedData,
    (row, rowIndex) => {
      if (typeof props.rowKey === "function") {
        return props.rowKey(row, rowIndex);
      }
      return row[props.rowKey] || `row-${rowIndex}`;
    },
    // getRowKey函数
    true,
    // isDevelopment
    rowHighlight.updateSelectionHighlight
    // 传递updateSelectionHighlight函数
  );
  const tableUtils = useTableUtils(
    props,
    emit,
    tableComputed.columnsInfo,
    containerWidth,
    scrollLeft,
    tableComputed.hasHorizontalScrollbar,
    tableComputed.leftFixedTotalWidth,
    tableComputed.hasRightFixedColumns,
    tableComputed.scrollbarHandleWidth,
    tableComputed.scrollbarHandleLeft,
    tableState.isDragging,
    tableState.isScrollbarVisible,
    tableComputed.SCROLLBAR_HEIGHT
  );
  const scrollbar = useScrollbar(
    bodyRef,
    scrollLeft,
    containerWidth,
    tableComputed.columnsInfo,
    tableState.isDragging,
    tableState.isScrollbarVisible,
    tableState.autoHideTimer,
    tableState.smoothScrollAnimation,
    () => {
    },
    // syncScroll临时函数
    () => {
    }
    // updateShadowState临时函数
  );
  const tableStyles = useTableStyles(
    props,
    tableComputed.columnsInfo,
    tableComputed.leftFixedTotalWidth,
    tableComputed.hasRightFixedColumns,
    tableComputed.hasLeftFixedContent,
    scrollLeft,
    containerWidth,
    tableState.headerHeight,
    tableComputed.EXPAND_WIDTH,
    tableComputed.SELECTION_WIDTH,
    tableComputed.SCROLLBAR_HEIGHT
  );
  const scrollHandlers = useScrollHandlers(
    reactivePropsForScrollHandlers.value,
    emit,
    bodyRef,
    leftBodyWrapperRef,
    rightBodyWrapperRef,
    headerContentRef,
    // 添加表头内容引用
    scrollTop,
    scrollLeft,
    true,
    // isDevelopment
    layoutWrapperRef,
    // 添加布局容器引用
    tableStyles.updateShadowState,
    // 添加阴影状态更新函数
    tableStyles.updateShadowScrollPosition
    // 添加独立的阴影滚动跟踪函数
  );
  const tableEvents2 = useTableEvents(
    bodyRef,
    leftBodyWrapperRef,
    rightBodyWrapperRef,
    scrollTop,
    scrollLeft,
    scrollHandlers.vxeStyleAbsoluteSync,
    () => 0,
    // getGlobalMaxScrollTop临时函数
    () => {
    },
    // updateShadowState临时函数
    true,
    // isDevelopment
    emit,
    props,
    scrollHandlers.isLoadingMore,
    scrollHandlers.savedScrollPosition
  );
  const tableHandlers = useTableHandlers(
    props,
    emit,
    scrollTop,
    scrollLeft,
    scrollHandlers.lastScrollTop,
    lastScrollLeft,
    scrollHandlers.intoRunScroll,
    scrollHandlers.isLoadingMore,
    true,
    // isDevelopment
    scrollHandlers.vxeStyleAbsoluteSync,
    () => {
    },
    // handleLoadMore临时函数
    () => {
    },
    // updateShadowState临时函数
    () => {
    },
    // syncScroll临时函数
    44,
    // MIN_ROW_HEIGHT
    dynamicRowHeights,
    tableComputed.EXPAND_WIDTH,
    rowHighlight
    // 传递行高亮处理函数
  );
  const tableCore = useVantTableCore(
    props,
    emit,
    {
      layoutWrapperRef,
      bodyRef,
      headerRef,
      leftBodyWrapperRef,
      rightBodyWrapperRef
    },
    {
      filteredAndSortedData,
      activeFilters: tableFilters.activeFilters,
      sortConfig: tableSorting.sortConfig,
      getCellValue: tableUtils.getCellValue,
      isRowTotal: tableUtils.isRowTotal,
      columnsInfo: tableComputed.columnsInfo,
      containerWidth,
      scrollLeft,
      hasLeftFixedContent: tableComputed.hasLeftFixedContent,
      hasRightFixedColumns: tableComputed.hasRightFixedColumns,
      leftFixedTotalWidth: tableComputed.leftFixedTotalWidth,
      showHorizontalScrollbar: tableStyles.hasHorizontalScrollbar,
      hoveredRowIndex: tableState.hoveredRowIndex,
      selectedRowIndex: tableState.selectedRowIndex,
      isRowDisabled: () => false,
      // 临时函数
      isRowSelected: tableSelection.isRowSelected,
      handleRowSelect: tableSelection.handleRowSelect,
      selectedRows: tableSelection.selectedRows,
      selectedRowKeys: tableSelection.selectedRowKeys,
      ensureSingleRowHighlight: rowHighlight.ensureSingleRowHighlight,
      touchHandledRowIndex: rowHighlight.touchHandledRowIndex,
      expandedRows: tableState.expandedRows,
      measureAndSyncRowHeights: tableState.measureAndSyncRowHeights,
      applyRowState: () => {
      }
      // 临时函数
    }
  );
  const touchEvents = useTouchEvents(
    props,
    emit,
    bodyRef,
    leftBodyWrapperRef,
    rightBodyWrapperRef,
    scrollLeft,
    scrollHandlers.vxeStyleAbsoluteSync,
    () => 0,
    // getGlobalMaxScrollTop临时函数
    filteredAndSortedData,
    rowHighlight.handleSingleRowHighlight,
    tableCore.handleRowClickLocal,
    scrollHandlers.isLoadingMore,
    scrollHandlers.savedScrollPosition,
    true,
    // isDevelopment
    rowHighlight.touchHandledRowIndex,
    tableComputed.columnsInfo,
    containerWidth
  );
  const scrollUtils = useScrollUtils(
    bodyRef,
    leftBodyWrapperRef,
    rightBodyWrapperRef,
    scrollTop,
    scrollLeft,
    scrollHandlers.isLoadingMore,
    scrollHandlers.vxeStyleAbsoluteSync,
    true
    // isDevelopment
  );
  const filterUtils = useFilterUtils(
    tableFilters.filterStates,
    tableFilters.activeFilters,
    tableCore.filterOptions,
    emit
  );
  const cellUtils = useCellUtils(
    props,
    tableUtils.getCellValue,
    tableSelection.isRowSelected,
    tableUtils.isRowTotal
  );
  const stickyStyles = useStickyStyles(
    props,
    tableComputed.columnsInfo,
    tableComputed.SELECTION_WIDTH,
    tableComputed.EXPAND_WIDTH
  );
  const tableDebug = useTableDebug(
    containerWidth,
    tableComputed.columnsInfo,
    scrollLeft,
    scrollTop,
    filteredAndSortedData,
    tableSelection.selectedRows,
    tableSelection.selectedRowKeys,
    tableSelection.isAllSelected,
    tableSelection.isIndeterminate,
    computed(() => []),
    // selectableRows临时
    dynamicHeaderHeight,
    dynamicRowHeights,
    tableStyles.hasHorizontalScrollbar,
    headerRowRef,
    leftHeaderRowRef,
    rightHeaderRowRef,
    () => {
    }
  );
  const scrollRestore = useScrollRestore(
    bodyRef,
    leftBodyWrapperRef,
    rightBodyWrapperRef,
    scrollTop,
    scrollLeft,
    scrollHandlers.savedScrollPosition,
    tableState.hoveredRowIndex,
    () => {
    },
    // applyRowState临时函数
    scrollHandlers.vxeStyleAbsoluteSync,
    scrollHandlers.intoRunScroll,
    scrollHandlers.lastScrollTop,
    true
    // isDevelopment
  );
  useLoadMore(
    props,
    bodyRef,
    leftBodyWrapperRef,
    rightBodyWrapperRef,
    scrollTop,
    scrollLeft,
    filteredAndSortedData,
    tableState.measureAndSyncHeaderHeight,
    tableState.measureAndSyncRowHeights,
    true,
    // isDevelopment
    scrollHandlers.isLoadingMore,
    scrollHandlers.savedScrollPosition,
    scrollHandlers.savedDataLength,
    scrollHandlers.savedScrollHeight,
    scrollHandlers.lastScrollTop,
    scrollHandlers.intoRunScroll
  );
  const headerProps = computed(() => {
    var _a, _b, _c;
    const hasLeftFixedExpand = props.expandable && (tableComputed.hasLeftFixedContent.value || false);
    const headerPropsValue = {
      hasLeftFixedContent: tableComputed.hasLeftFixedContent.value || false,
      leftFixedTotalWidth: tableComputed.leftFixedTotalWidth.value || 0,
      hasRightFixedColumns: tableComputed.hasRightFixedColumns.value || false,
      columnsInfo: ((_a = tableComputed.columnsInfo) == null ? void 0 : _a.value) || { computedHeaders: [] },
      tableStyle: ((_b = tableComputed.tableStyle) == null ? void 0 : _b.value) || {},
      expandable: props.expandable || false,
      hasLeftFixedExpand,
      getColStyle: tableComputed.getColStyle,
      getHeaderClass: cellUtils.getHeaderClass,
      getHeaderStyle: cellUtils.getHeaderStyle,
      setHeaderElementRef: tableState.setHeaderElementRef,
      handleSort: tableSorting.handleSort,
      sortConfig: ((_c = tableSorting.sortConfig) == null ? void 0 : _c.value) || {},
      isFilterActive: tableFilters.isFilterActive,
      toggleFilter: tableFilters.toggleFilter
    };
    return headerPropsValue;
  });
  const bodyProps = computed(() => {
    var _a, _b, _c, _d;
    const hasLeftFixedExpand = props.expandable && (tableComputed.hasLeftFixedContent.value || false);
    return {
      bodyWrapperStyle: ((_a = tableComputed.bodyWrapperStyle) == null ? void 0 : _a.value) || {},
      tableStyle: ((_b = tableComputed.tableStyle) == null ? void 0 : _b.value) || {},
      columnsInfo: ((_c = tableComputed.columnsInfo) == null ? void 0 : _c.value) || { computedHeaders: [] },
      filteredAndSortedData: filteredAndSortedData.value || [],
      hasActiveFilters: ((_d = tableFilters.hasActiveFilters) == null ? void 0 : _d.value) || false,
      expandable: props.expandable || false,
      hasLeftFixedExpand,
      handleScroll: scrollHandlers.handleScroll,
      handleMainTableWheel: scrollHandlers.handleMainTableWheel,
      handleMainTableTouchStart: scrollHandlers.handleMainTableTouchStart,
      handleMainTableTouchMove: scrollHandlers.handleMainTableTouchMove,
      handleMainTableTouchEnd: scrollHandlers.handleMainTableTouchEnd,
      handleAreaMouseEnter: scrollHandlers.handleAreaMouseEnter,
      handleAreaMouseLeave: scrollHandlers.handleAreaMouseLeave,
      getColStyle: tableComputed.getColStyle,
      getRowKey: tableCore.getRowKey,
      getRowClass: tableComputed.getRowClass,
      getRowStyle: tableComputed.getRowStyle,
      setRowElementRef: tableState.setRowElementRef,
      handleSingleRowHighlight: tableHandlers.handleSingleRowHighlight,
      handleRowClickLocal: tableHandlers.handleRowClickLocal,
      handleRowMouseEnter: tableHandlers.handleRowMouseEnter,
      handleRowMouseLeave: tableHandlers.handleRowMouseLeave,
      getCellClass: cellUtils.getCellClass,
      getCellStyle: cellUtils.getCellStyle,
      handleCellClick: tableHandlers.handleCellClick,
      isRowTotal: tableUtils.isRowTotal,
      getDataBarStyle: cellUtils.getDataBarStyle,
      getCellValue: tableUtils.getCellValue,
      renderCustomCell: cellUtils.renderCustomCell,
      formatCellValue: cellUtils.formatCellValue,
      isExpanded: tableState.isRowExpanded,
      toggleExpand: tableCore.toggleExpand
    };
  });
  const leftFixedProps = computed(() => {
    var _a, _b, _c, _d, _e, _f, _g, _h, _i;
    const colInfo = ((_a = tableComputed.columnsInfo) == null ? void 0 : _a.value) || { computedHeaders: [] };
    const leftColumns = colInfo.leftFixedColumns || [];
    const selectionWidth = props.selectable && props.selectMode === "checkbox" ? 48 : 0;
    const expandWidth = props.expandable ? 40 : 0;
    const shouldShowLeft = leftColumns.length > 0 || props.selectable || props.expandable;
    const dataToPass = filteredAndSortedData.value || [];
    return {
      position: "left",
      shouldShow: shouldShowLeft,
      columns: leftColumns,
      columnsInfo: colInfo,
      filteredAndSortedData: dataToPass,
      tableStyle: tableComputed.tableStyle || {},
      bodyWrapperStyle: (() => {
        var _a2;
        const mainStyle = ((_a2 = tableComputed.bodyWrapperStyle) == null ? void 0 : _a2.value) || {};
        const result = {
          ...mainStyle,
          // 除去margin以避免固定列与主表格重复偏移
          marginLeft: "0",
          marginRight: "0",
          // 固定列使用hidden而不是auto滚动
          overflow: "hidden",
          overflowX: "hidden",
          overflowY: "hidden"
        };
        console.log("🔍 Fixed column bodyWrapperStyle debug:", {
          position: "left/right",
          originalMainHeight: mainStyle.height,
          finalResultHeight: result.height,
          originalMainPadding: mainStyle.paddingBottom,
          finalResultPadding: result.paddingBottom,
          heightMatch: mainStyle.height === result.height,
          paddingMatch: mainStyle.paddingBottom === result.paddingBottom,
          marginLeft: result.marginLeft,
          marginRight: result.marginRight,
          "疑点": "主表格和固定列高度公式是否一致？"
        });
        return result;
      })(),
      fixedStyle: ((_b = tableStyles.leftFixedStyle) == null ? void 0 : _b.value) || { left: 0 },
      fixedHeaderWrapperStyle: {
        // 🔑 关键修复：完全不限制高度，让内容自由扩展
      },
      headerTableStyle: {
        width: `${colInfo.leftFixedWidth + expandWidth + selectionWidth}px`,
        tableLayout: "fixed",
        borderCollapse: "separate",
        borderSpacing: 0,
        margin: 0
      },
      bodyTableStyle: {
        width: `${colInfo.leftFixedWidth + expandWidth + selectionWidth}px`,
        tableLayout: "fixed",
        borderCollapse: "separate",
        borderSpacing: 0,
        margin: 0
      },
      selectionColStyle: { width: "48px" },
      expandColStyle: { width: "40px" },
      showSelection: props.selectable && props.selectMode === "checkbox",
      showExpand: props.expandable,
      getColStyle: tableComputed.getColStyle,
      getRowKey: tableCore.getRowKey,
      getRowClass: tableComputed.getRowClass,
      getRowStyle: tableComputed.getRowStyle,
      getFixedHeaderClass: cellUtils.getFixedHeaderClass,
      getFixedHeaderStyle: cellUtils.getFixedHeaderStyle,
      getSelectionHeaderStyle: cellUtils.getSelectionHeaderStyle,
      getExpandHeaderStyle: cellUtils.getExpandHeaderStyle,
      getSelectionCellStyle: cellUtils.getSelectionCellStyle,
      getExpandCellStyle: cellUtils.getExpandCellStyle,
      toggleExpand: tableCore.toggleExpand,
      setRowElementRef: tableState.setRowElementRef,
      setHeaderElementRef: tableState.setHeaderElementRef,
      handleSingleRowHighlight: tableHandlers.handleSingleRowHighlight,
      handleRowClickLocal: tableHandlers.handleRowClickLocal,
      handleRowMouseEnter: tableHandlers.handleRowMouseEnter,
      handleRowMouseLeave: tableHandlers.handleRowMouseLeave,
      getCellClass: cellUtils.getCellClass,
      getCellStyle: cellUtils.getCellStyle,
      getFixedCellClass: cellUtils.getFixedCellClass,
      getFixedCellStyle: cellUtils.getFixedCellStyle,
      handleCellClick: tableHandlers.handleCellClick,
      isRowTotal: tableUtils.isRowTotal,
      getDataBarStyle: cellUtils.getDataBarStyle,
      getCellValue: tableUtils.getCellValue,
      renderCustomCell: cellUtils.renderCustomCell,
      formatCellValue: cellUtils.formatCellValue,
      isExpanded: tableState.isRowExpanded,
      expandable: props.expandable || false,
      hasActiveFilters: ((_c = tableFilters.hasActiveFilters) == null ? void 0 : _c.value) || false,
      handleSort: tableSorting.handleSort,
      sortConfig: ((_d = tableSorting.sortConfig) == null ? void 0 : _d.value) || {},
      isFilterActive: tableFilters.isFilterActive,
      toggleFilter: tableFilters.toggleFilter,
      // 选择相关
      handleSelectAll: tableSelection.handleSelectAll,
      isAllSelected: ((_e = tableSelection.isAllSelected) == null ? void 0 : _e.value) || false,
      isIndeterminate: ((_f = tableSelection.isIndeterminate) == null ? void 0 : _f.value) || false,
      selectableRows: ((_g = tableSelection.selectableRows) == null ? void 0 : _g.value) || [],
      allRowsDisabled: ((_h = tableSelection.allRowsDisabled) == null ? void 0 : _h.value) || false,
      isRadioMode: props.selectMode === "radio",
      isRowSelected: tableSelection.isRowSelected,
      handleRowSelect: tableSelection.handleRowSelect,
      isRowDisabled: tableSelection.isRowDisabled,
      handleCellSelect: tableSelection.handleCellSelect,
      // 滚动和触摸事件
      handleFixedColumnScroll: scrollHandlers.handleFixedColumnScroll,
      handleFixedColumnWheel: scrollHandlers.handleFixedColumnWheel,
      handleFixedColumnTouchStart: scrollHandlers.handleFixedColumnTouchStart,
      handleFixedColumnTouchMove: scrollHandlers.handleFixedColumnTouchMove,
      handleFixedColumnTouchEnd: scrollHandlers.handleFixedColumnTouchEnd,
      handleAreaMouseEnter: scrollHandlers.handleAreaMouseEnter,
      handleAreaMouseLeave: scrollHandlers.handleAreaMouseLeave,
      // 🔑 添加左侧阴影控制，参考vxe-table
      shouldShowShadow: ((_i = tableStyles.shouldShowLeftShadow) == null ? void 0 : _i.value) || false
    };
  });
  const rightFixedProps = computed(() => {
    var _a, _b, _c, _d, _e, _f, _g, _h, _i;
    const colInfo = ((_a = tableComputed.columnsInfo) == null ? void 0 : _a.value) || { computedHeaders: [] };
    const rightColumns = colInfo.rightFixedColumns || [];
    const shouldShowRight = rightColumns.length > 0;
    const dataToPass = filteredAndSortedData.value || [];
    return {
      position: "right",
      shouldShow: shouldShowRight,
      columns: rightColumns,
      columnsInfo: colInfo,
      filteredAndSortedData: dataToPass,
      tableStyle: tableComputed.tableStyle || {},
      bodyWrapperStyle: (() => {
        var _a2;
        const mainStyle = ((_a2 = tableComputed.bodyWrapperStyle) == null ? void 0 : _a2.value) || {};
        const result = {
          ...mainStyle,
          // 除去margin以避免固定列与主表格重复偏移
          marginLeft: "0",
          marginRight: "0",
          // 固定列使用hidden而不是auto滚动
          overflow: "hidden",
          overflowX: "hidden",
          overflowY: "hidden"
        };
        console.log("🔍 Fixed column bodyWrapperStyle debug:", {
          position: "left/right",
          originalMainHeight: mainStyle.height,
          finalResultHeight: result.height,
          originalMainPadding: mainStyle.paddingBottom,
          finalResultPadding: result.paddingBottom,
          heightMatch: mainStyle.height === result.height,
          paddingMatch: mainStyle.paddingBottom === result.paddingBottom,
          marginLeft: result.marginLeft,
          marginRight: result.marginRight,
          "疑点": "主表格和固定列高度公式是否一致？"
        });
        return result;
      })(),
      fixedStyle: ((_b = tableStyles.rightFixedStyle) == null ? void 0 : _b.value) || { right: 0 },
      fixedHeaderWrapperStyle: {
        // 🔑 关键修复：完全不限制高度，让内容自由扩展
      },
      headerTableStyle: {
        width: `${colInfo.rightFixedWidth || 0}px`,
        tableLayout: "fixed",
        borderCollapse: "separate",
        borderSpacing: 0,
        margin: 0
      },
      bodyTableStyle: {
        width: `${colInfo.rightFixedWidth || 0}px`,
        tableLayout: "fixed",
        borderCollapse: "separate",
        borderSpacing: 0,
        margin: 0
      },
      selectionColStyle: { width: "48px" },
      expandColStyle: { width: "40px" },
      showSelection: false,
      // 右固定列通常不显示选择框
      showExpand: false,
      // 右固定列通常不显示展开
      getColStyle: tableComputed.getColStyle,
      getRowKey: tableCore.getRowKey,
      getRowClass: tableComputed.getRowClass,
      getRowStyle: tableComputed.getRowStyle,
      getFixedHeaderClass: cellUtils.getFixedHeaderClass,
      getFixedHeaderStyle: cellUtils.getFixedHeaderStyle,
      getSelectionHeaderStyle: cellUtils.getSelectionHeaderStyle,
      getExpandHeaderStyle: cellUtils.getExpandHeaderStyle,
      getSelectionCellStyle: cellUtils.getSelectionCellStyle,
      getExpandCellStyle: cellUtils.getExpandCellStyle,
      toggleExpand: tableCore.toggleExpand,
      setRowElementRef: tableState.setRowElementRef,
      setHeaderElementRef: tableState.setHeaderElementRef,
      handleSingleRowHighlight: tableHandlers.handleSingleRowHighlight,
      handleRowClickLocal: tableHandlers.handleRowClickLocal,
      handleRowMouseEnter: tableHandlers.handleRowMouseEnter,
      handleRowMouseLeave: tableHandlers.handleRowMouseLeave,
      getCellClass: cellUtils.getCellClass,
      getCellStyle: cellUtils.getCellStyle,
      getFixedCellClass: cellUtils.getFixedCellClass,
      getFixedCellStyle: cellUtils.getFixedCellStyle,
      handleCellClick: tableHandlers.handleCellClick,
      isRowTotal: tableUtils.isRowTotal,
      getDataBarStyle: cellUtils.getDataBarStyle,
      getCellValue: tableUtils.getCellValue,
      renderCustomCell: cellUtils.renderCustomCell,
      formatCellValue: cellUtils.formatCellValue,
      isExpanded: tableState.isRowExpanded,
      expandable: props.expandable || false,
      hasActiveFilters: ((_c = tableFilters.hasActiveFilters) == null ? void 0 : _c.value) || false,
      handleSort: tableSorting.handleSort,
      sortConfig: ((_d = tableSorting.sortConfig) == null ? void 0 : _d.value) || {},
      isFilterActive: tableFilters.isFilterActive,
      toggleFilter: tableFilters.toggleFilter,
      // 选择相关
      handleSelectAll: tableSelection.handleSelectAll,
      isAllSelected: ((_e = tableSelection.isAllSelected) == null ? void 0 : _e.value) || false,
      isIndeterminate: ((_f = tableSelection.isIndeterminate) == null ? void 0 : _f.value) || false,
      selectableRows: ((_g = tableSelection.selectableRows) == null ? void 0 : _g.value) || [],
      allRowsDisabled: ((_h = tableSelection.allRowsDisabled) == null ? void 0 : _h.value) || false,
      isRadioMode: props.selectMode === "radio",
      isRowSelected: tableSelection.isRowSelected,
      handleRowSelect: tableSelection.handleRowSelect,
      isRowDisabled: tableSelection.isRowDisabled,
      handleCellSelect: tableSelection.handleCellSelect,
      // 滚动和触摸事件
      handleFixedColumnScroll: scrollHandlers.handleFixedColumnScroll,
      handleFixedColumnWheel: scrollHandlers.handleFixedColumnWheel,
      handleFixedColumnTouchStart: scrollHandlers.handleFixedColumnTouchStart,
      handleFixedColumnTouchMove: scrollHandlers.handleFixedColumnTouchMove,
      handleFixedColumnTouchEnd: scrollHandlers.handleFixedColumnTouchEnd,
      handleAreaMouseEnter: scrollHandlers.handleAreaMouseEnter,
      handleAreaMouseLeave: scrollHandlers.handleAreaMouseLeave,
      // 🔑 添加右侧阴影控制，参考vxe-table
      shouldShowShadow: ((_i = tableStyles.shouldShowRightShadow) == null ? void 0 : _i.value) || false
    };
  });
  const scrollbarProps = computed(() => {
    var _a, _b, _c, _d, _e, _f, _g, _h, _i;
    return {
      showHorizontalScrollbar: ((_a = tableStyles.hasHorizontalScrollbar) == null ? void 0 : _a.value) || false,
      horizontalScrollbarContainerStyle: ((_b = tableUtils.horizontalScrollbarContainerStyle) == null ? void 0 : _b.value) || {},
      scrollbarWrapperStyle: ((_c = tableUtils.scrollbarWrapperStyle) == null ? void 0 : _c.value) || {},
      isScrollbarVisible: ((_d = tableState.isScrollbarVisible) == null ? void 0 : _d.value) || false,
      isDragging: ((_e = tableState.isDragging) == null ? void 0 : _e.value) || false,
      scrollbarHandleStyle: ((_f = tableUtils.scrollbarHandleStyle) == null ? void 0 : _f.value) || {},
      scrollbarSpaceStyle: ((_g = tableUtils.scrollbarSpaceStyle) == null ? void 0 : _g.value) || {},
      scrollbarLeftCornerStyle: ((_h = tableUtils.scrollbarLeftCornerStyle) == null ? void 0 : _h.value) || {},
      scrollbarRightCornerStyle: ((_i = tableUtils.scrollbarRightCornerStyle) == null ? void 0 : _i.value) || {},
      // 事件处理函数
      handleScrollbarTrackClick: scrollbar.handleScrollbarTrackClick || (() => {
      }),
      handleScrollbarMouseDown: scrollbar.handleScrollbarMouseDown || (() => {
      }),
      handleScrollbarMouseEnter: scrollbar.handleScrollbarMouseEnter || (() => {
      }),
      handleScrollbarMouseLeave: scrollbar.handleScrollbarMouseLeave || (() => {
      }),
      handleScrollToLeft: scrollbar.scrollToLeft || (() => {
      }),
      handleScrollToRight: scrollbar.scrollToRight || (() => {
      })
    };
  });
  const loadMoreProps = computed(() => ({
    enableLoadMore: props.enableLoadMore,
    showLoadMoreUi: props.showLoadMoreUi,
    loadMoreLoading: props.loadMoreLoading,
    loadMoreFinished: props.loadMoreFinished,
    loadMoreError: props.loadMoreError,
    loadMoreLoadingText: props.loadMoreLoadingText,
    loadMoreFinishedText: props.loadMoreFinishedText,
    loadMoreErrorText: props.loadMoreErrorText,
    loadMoreReadyText: props.loadMoreReadyText
  }));
  const filterProps = computed(() => ({
    headers: props.headers,
    filterStates: tableFilters.filterStates,
    filters: tableFilters.filters,
    toggleFilter: tableFilters.toggleFilter,
    applyFilter: tableFilters.applyFilter,
    clearFilters: tableFilters.clearFilters
  }));
  return {
    // 滚动相关
    ...scrollHandlers,
    ...scrollUtils,
    ...scrollbar,
    ...scrollRestore,
    // 状态管理
    ...tableState,
    // 计算属性
    ...tableComputed,
    // 过滤和排序
    ...tableFilters,
    ...tableSorting,
    ...filterUtils,
    // 选择功能
    ...tableSelection,
    // 事件处理
    ...tableEvents2,
    ...tableHandlers,
    ...touchEvents,
    // 样式相关
    ...tableStyles,
    ...cellUtils,
    ...stickyStyles,
    // 核心功能
    ...tableCore,
    // 行高亮
    ...rowHighlight,
    // 工具函数
    ...tableUtils,
    // 调试功能
    ...tableDebug,
    // 数据
    filteredAndSortedData,
    rawData,
    // 基础响应式数据
    dynamicHeaderHeight,
    dynamicRowHeights,
    expandedRowHeights,
    isHeaderSyncing,
    isRowSyncing,
    headerElementRefs,
    rowElementRefs,
    internalSelectedKeys,
    lastSelectedIndex,
    containerWidth,
    scrollLeft,
    scrollTop,
    lastScrollLeft,
    // 组件属性绑定
    headerProps,
    bodyProps,
    leftFixedProps,
    rightFixedProps,
    scrollbarProps,
    loadMoreProps,
    filterProps,
    // 核心功能方法
    updateContainerWidth,
    initializeTable
  };
}
function useTableLifecycle(props, emit, refs, composableResults) {
  const {
    layoutWrapperRef,
    bodyRef,
    headerRef,
    leftBodyWrapperRef,
    rightBodyWrapperRef
  } = refs;
  const {
    initializeTable,
    updateContainerWidth,
    measureAndSyncHeaderHeight,
    measureAndSyncRowHeights,
    forceResetAllRowStates,
    applyRowState,
    closeAllFilterPopups,
    isDevelopment,
    selectedRowIndex,
    autoHideTimer,
    smoothScrollAnimation,
    forceHeaderHeightSync
  } = composableResults;
  let cleanupTouchOptimization = null;
  let globalButtonClickHandler = null;
  const isIOSSafari = ref(false);
  const iosScrollTimeout = ref(null);
  const detectIOSSafari = () => {
    const ua = navigator.userAgent;
    const isIOS = tableConstants.IOS_REGEX.test(ua);
    const isSafari = /Safari/i.test(ua) && !/Chrome/i.test(ua);
    return isIOS && isSafari;
  };
  const handleKeyDown = (event) => {
    if (event.key === "Escape") {
      closeAllFilterPopups();
    }
  };
  const handleTouchOptimization = () => {
    const isIOS = tableConstants.IOS_REGEX.test(navigator.userAgent);
    if (isIOS && layoutWrapperRef.value) {
      const tableWrapper = layoutWrapperRef.value;
      tableWrapper.classList.add(tableConstants.CSS_CLASSES.IOS_OPTIMIZED);
      let startY = 0;
      let startX = 0;
      const touchStart = (e) => {
        startY = e.touches[0].clientY;
        startX = e.touches[0].clientX;
      };
      const touchMove = (e) => {
        var _a, _b, _c;
        const currentY = e.touches[0].clientY;
        const currentX = e.touches[0].clientX;
        const deltaY = currentY - startY;
        const deltaX = currentX - startX;
        if (Math.abs(deltaX) > Math.abs(deltaY)) {
          return;
        }
        const scrollTop = ((_a = bodyRef.value) == null ? void 0 : _a.scrollTop) || 0;
        const scrollHeight = ((_b = bodyRef.value) == null ? void 0 : _b.scrollHeight) || 0;
        const clientHeight = ((_c = bodyRef.value) == null ? void 0 : _c.clientHeight) || 0;
        if (scrollTop === 0 && deltaY > 0 || scrollTop + clientHeight >= scrollHeight && deltaY < 0) {
          e.preventDefault();
        }
      };
      tableWrapper.addEventListener("touchstart", touchStart, { passive: true });
      tableWrapper.addEventListener("touchmove", touchMove, { passive: false });
      return () => {
        tableWrapper.removeEventListener("touchstart", touchStart);
        tableWrapper.removeEventListener("touchmove", touchMove);
      };
    }
    return () => {
    };
  };
  const setupGlobalButtonClickHandler = () => {
    globalButtonClickHandler = (event) => {
      const isEditButtonClick = event.target.closest('button, .van-button, [role="button"], .edit-btn, .action-btn');
      if (isEditButtonClick) {
        const row = event.target.closest("tr");
        if (row && row.dataset.rowIndex !== void 0) {
          const rowIndex = parseInt(row.dataset.rowIndex);
          const allHighlightClasses = [
            `.${tableConstants.CSS_CLASSES.SELECTED}`,
            `.${tableConstants.CSS_CLASSES.HOVER}`,
            ".vant-tr--active",
            `.${tableConstants.CSS_CLASSES.HIGHLIGHTED}`
          ];
          allHighlightClasses.forEach((className) => {
            document.querySelectorAll(className).forEach((el) => {
              el.classList.remove(className.substring(1));
            });
          });
          document.querySelectorAll(`[data-row-index="${rowIndex}"]`).forEach((el) => {
            if (el.classList.contains(tableConstants.CSS_CLASSES.ROW)) {
              el.classList.add(tableConstants.CSS_CLASSES.SELECTED);
            }
          });
          selectedRowIndex.value = rowIndex;
          if (isDevelopment.value) {
            console.log(`🎯 编辑/删除按钮点击：高亮第${rowIndex}行`);
          }
        }
      }
    };
    document.addEventListener("click", globalButtonClickHandler, true);
  };
  const handleWindowResize = () => {
    setTimeout(() => {
      updateContainerWidth();
    }, tableConstants.RESIZE_DEBOUNCE_TIME);
  };
  const setupDevelopmentDebugger = () => {
    if (isDevelopment.value && debugConfig.enableConsoleLog) {
      window.tableDebugger = {
        ...composableResults,
        // 所有组合函数的方法
        // 额外的调试方法
        forceHeaderSync: forceHeaderHeightSync,
        // 选择相关调试方法
        testRowHighlight: (rowIndex) => {
          console.log(`Testing row ${rowIndex} highlight...`);
          applyRowState(rowIndex, "selected", true);
          selectedRowIndex.value = rowIndex;
        },
        checkRowElements: (rowIndex) => {
          const positions = ["main", "left", "right"];
          console.log(`Checking row ${rowIndex} elements:`);
          positions.forEach((position) => {
            var _a, _b;
            const rowEl = (_b = (_a = composableResults.rowElementRefs) == null ? void 0 : _a.value[rowIndex]) == null ? void 0 : _b[position];
            console.log(`${position}:`, rowEl ? "Found" : "Missing", rowEl);
          });
        },
        checkHighlightState: () => {
          const selectedElements = document.querySelectorAll(`.${tableConstants.CSS_CLASSES.SELECTED}`);
          console.log(`Current highlight state: ${selectedElements.length} elements`);
          selectedElements.forEach((el, index) => {
            const rowIndex = el.getAttribute("data-row-index");
            console.log(`  ${index + 1}. Row ${rowIndex}:`, el);
          });
          return {
            count: selectedElements.length,
            selectedRowIndex: selectedRowIndex.value,
            elements: selectedElements
          };
        }
      };
    }
  };
  const setupHeaderContentRef = () => {
    const trySetupRef = (retryCount = 0) => {
      if (refs.tableHeaderRef && refs.tableHeaderRef.value && refs.tableHeaderRef.value.headerContentRef && refs.tableHeaderRef.value.headerContentRef.value) {
        refs.headerContentRef.value = refs.tableHeaderRef.value.headerContentRef.value;
        return true;
      } else {
        if (retryCount < 5) {
          setTimeout(() => {
            trySetupRef(retryCount + 1);
          }, 100 * (retryCount + 1));
        }
        return false;
      }
    };
    return trySetupRef();
  };
  const initializeTableHeights = () => {
    nextTick(() => {
      setupHeaderContentRef();
      const performInitialization = () => {
        measureAndSyncRowHeights();
        forceResetAllRowStates();
        if (props.highlightIndex >= 0) {
          applyRowState(props.highlightIndex, "highlighted", true);
        }
      };
      setTimeout(performInitialization, 50);
    });
  };
  const cleanup = () => {
    window.removeEventListener("resize", handleWindowResize);
    document.removeEventListener("keydown", handleKeyDown);
    if (globalButtonClickHandler) {
      document.removeEventListener("click", globalButtonClickHandler, true);
    }
    if (cleanupTouchOptimization) {
      cleanupTouchOptimization();
    }
    if (autoHideTimer == null ? void 0 : autoHideTimer.value) {
      clearTimeout(autoHideTimer.value);
    }
    if (smoothScrollAnimation == null ? void 0 : smoothScrollAnimation.value) {
      cancelAnimationFrame(smoothScrollAnimation.value);
    }
    if (iosScrollTimeout.value) {
      clearTimeout(iosScrollTimeout.value);
    }
    if (isDevelopment.value && window.tableDebugger) {
      delete window.tableDebugger;
    }
  };
  onMounted(() => {
    isIOSSafari.value = detectIOSSafari();
    if (isIOSSafari.value && isDevelopment.value) {
      console.log("检测到iOS Safari环境，启用特殊滚动处理");
    }
    initializeTable();
    nextTick(() => {
      setTimeout(() => {
        console.log("🔧 DOM渲染完成后更新容器宽度（一次性）");
        updateContainerWidth();
      }, 100);
    });
    document.addEventListener("keydown", handleKeyDown);
    window.addEventListener("resize", handleWindowResize);
    setupGlobalButtonClickHandler();
    cleanupTouchOptimization = handleTouchOptimization();
    setupDevelopmentDebugger();
    initializeTableHeights();
  });
  onUnmounted(() => {
    cleanup();
  });
  return {
    // 状态
    isIOSSafari,
    iosScrollTimeout,
    // 方法
    detectIOSSafari,
    handleKeyDown,
    handleTouchOptimization,
    setupGlobalButtonClickHandler,
    handleWindowResize,
    setupDevelopmentDebugger,
    setupHeaderContentRef,
    initializeTableHeights,
    cleanup
  };
}
function useTableWatchers(props, composableResults) {
  const {
    selectedKeys,
    internalSelectedKeys,
    filteredAndSortedData,
    expandedRows,
    loadMoreLoading,
    enableLoadMore,
    showLoadMoreUi,
    highlightIndex,
    width,
    isDevelopment,
    measureAndSyncHeaderHeight,
    measureAndSyncRowHeights,
    updateContainerWidth,
    applyRowState,
    bodyRef
  } = composableResults;
  const watchSelectedKeys = () => {
    if (!props.selectedKeys || !internalSelectedKeys)
      return;
    watch(
      () => props.selectedKeys,
      (newKeys) => {
        if (internalSelectedKeys.value) {
          internalSelectedKeys.value = new Set(newKeys || []);
        }
      },
      { immediate: true }
    );
  };
  const watchColumnsData = () => {
    watch(
      () => props.columns,
      () => {
        nextTick(() => {
          setTimeout(() => {
            if (isDevelopment == null ? void 0 : isDevelopment.value) {
              console.log("列信息变化，重新同步表头高度");
            }
            if (measureAndSyncHeaderHeight)
              measureAndSyncHeaderHeight(true);
            if (measureAndSyncRowHeights)
              measureAndSyncRowHeights();
          }, 50);
        });
      },
      { deep: true, flush: "post" }
    );
  };
  const watchFilteredData = () => {
    if (!filteredAndSortedData)
      return;
    watch(
      () => filteredAndSortedData.value,
      () => {
        nextTick(() => {
          setTimeout(() => {
            if (isDevelopment == null ? void 0 : isDevelopment.value) {
              console.log("VXE 方式：数据变化，只进行高度同步");
            }
            if (measureAndSyncHeaderHeight)
              measureAndSyncHeaderHeight();
            if (measureAndSyncRowHeights)
              measureAndSyncRowHeights();
          }, 50);
        });
      },
      { flush: "post" }
    );
  };
  const watchLoadMoreState = () => {
    if (loadMoreLoading) {
      watch(
        () => loadMoreLoading.value,
        (newLoading, oldLoading) => {
          if (oldLoading && !newLoading) {
            nextTick(() => {
              setTimeout(() => {
                if (measureAndSyncHeaderHeight)
                  measureAndSyncHeaderHeight(false);
                if (measureAndSyncRowHeights)
                  measureAndSyncRowHeights();
              }, 100);
            });
          }
        }
      );
    }
    if (enableLoadMore) {
      watch(
        () => props.enableLoadMore,
        () => {
          nextTick(() => {
            if (updateContainerWidth)
              updateContainerWidth();
            setTimeout(() => {
              if (bodyRef == null ? void 0 : bodyRef.value) {
                const scrollEvent = new Event("scroll");
                bodyRef.value.dispatchEvent(scrollEvent);
              }
            }, 100);
          });
        }
      );
    }
    if (showLoadMoreUi) {
      watch(
        () => props.showLoadMoreUi,
        () => {
          nextTick(() => {
            if (updateContainerWidth)
              updateContainerWidth();
            setTimeout(() => {
              if (bodyRef == null ? void 0 : bodyRef.value) {
                const scrollEvent = new Event("scroll");
                bodyRef.value.dispatchEvent(scrollEvent);
              }
            }, 100);
          });
        }
      );
    }
  };
  const watchExpandedRows = () => {
    if (!expandedRows)
      return;
    watch(
      () => expandedRows.value,
      () => {
        nextTick(() => {
          setTimeout(() => {
            if (measureAndSyncRowHeights)
              measureAndSyncRowHeights();
          }, 50);
        });
      },
      { deep: true }
    );
  };
  const watchTableWidth = () => {
    watch(
      () => props.width,
      () => {
        nextTick(() => {
          if (updateContainerWidth)
            updateContainerWidth();
        });
      }
    );
  };
  const watchHighlightIndex = () => {
    if (!highlightIndex)
      return;
    watch(
      () => props.highlightIndex,
      (newIndex, oldIndex) => {
        if (applyRowState) {
          if (oldIndex >= 0) {
            applyRowState(oldIndex, "highlighted", false);
          }
          if (newIndex >= 0) {
            applyRowState(newIndex, "highlighted", true);
          }
        }
      }
    );
  };
  const watchScrollState = () => {
  };
  const watchSelectionState = () => {
  };
  const watchFilterSortState = () => {
  };
  const watchStyleState = () => {
  };
  const initializeWatchers = () => {
    watchSelectedKeys();
    watchColumnsData();
    watchFilteredData();
    watchExpandedRows();
    watchTableWidth();
    watchHighlightIndex();
    watchLoadMoreState();
  };
  const cleanupWatchers = () => {
  };
  initializeWatchers();
  return {
    // 监听器初始化和清理
    initializeWatchers,
    cleanupWatchers,
    // 各个监听器函数，可以单独使用
    watchSelectedKeys,
    watchColumnsData,
    watchFilteredData,
    watchLoadMoreState,
    watchExpandedRows,
    watchTableWidth,
    watchHighlightIndex,
    watchScrollState,
    watchSelectionState,
    watchFilterSortState,
    watchStyleState
  };
}
function useTableExpose(composableResults) {
  const {
    // 表格基础方法
    forceHeaderSync,
    measureAndSyncHeaderHeight,
    measureAndSyncRowHeights,
    quickDebug,
    enableDebug,
    checkAlignment,
    // 选择功能相关方法
    setSelectedRowKeys,
    setSelectedRows,
    getSelectedRowKeys,
    getSelectedRows,
    clearSelection,
    toggleRowSelection,
    selectAllCurrentPage,
    invertSelection,
    isRowSelected,
    isRowDisabled,
    // 滚动控制方法
    smoothScrollTo,
    scrollToLeft,
    scrollToRight,
    scrollToColumn,
    // 过滤控制方法
    closeAllFilterPopups,
    // 内部状态访问器
    selectedRowKeys,
    selectedRows,
    selectableRows,
    isAllSelected,
    isIndeterminate
  } = composableResults;
  const createStateAccessors = () => ({
    // 选择状态
    selectedRowKeys: () => (selectedRowKeys == null ? void 0 : selectedRowKeys.value) || [],
    selectedRows: () => (selectedRows == null ? void 0 : selectedRows.value) || [],
    selectableRows: () => (selectableRows == null ? void 0 : selectableRows.value) || [],
    isAllSelected: () => (isAllSelected == null ? void 0 : isAllSelected.value) || false,
    isIndeterminate: () => (isIndeterminate == null ? void 0 : isIndeterminate.value) || false
  });
  const createBaseOperations = () => ({
    // 表头和行高度同步
    forceHeaderSync: forceHeaderSync || (() => {
    }),
    measureAndSyncHeaderHeight: measureAndSyncHeaderHeight || (() => {
    }),
    measureAndSyncRowHeights: measureAndSyncRowHeights || (() => {
    }),
    // 调试方法
    quickDebug: quickDebug || (() => {
    }),
    enableDebug: enableDebug || (() => {
    }),
    checkAlignment: checkAlignment || (() => {
    })
  });
  const createSelectionOperations = () => ({
    // 设置选择状态
    setSelectedRowKeys: setSelectedRowKeys || (() => {
    }),
    setSelectedRows: setSelectedRows || (() => {
    }),
    // 获取选择状态
    getSelectedRowKeys: getSelectedRowKeys || (() => []),
    getSelectedRows: getSelectedRows || (() => []),
    // 选择操作
    clearSelection: clearSelection || (() => {
    }),
    toggleRowSelection: toggleRowSelection || (() => {
    }),
    selectAllCurrentPage: selectAllCurrentPage || (() => {
    }),
    invertSelection: invertSelection || (() => {
    }),
    // 选择状态判断
    isRowSelected: isRowSelected || (() => false),
    isRowDisabled: isRowDisabled || (() => false)
  });
  const createScrollOperations = () => ({
    smoothScrollTo: smoothScrollTo || (() => {
    }),
    scrollToLeft: scrollToLeft || (() => {
    }),
    scrollToRight: scrollToRight || (() => {
    }),
    scrollToColumn: scrollToColumn || (() => {
    })
  });
  const createFilterOperations = () => ({
    closeAllFilterPopups: closeAllFilterPopups || (() => {
    })
  });
  const createAdvancedOperations = () => ({
    // 强制重新对齐（组合多个基础操作）
    forceRealign: () => {
      if (forceHeaderSync)
        forceHeaderSync();
      if (measureAndSyncHeaderHeight)
        measureAndSyncHeaderHeight(true);
      if (measureAndSyncRowHeights)
        measureAndSyncRowHeights();
    },
    // 强制DOM清理和重建
    forceDOMCleanup: () => {
      if (clearSelection)
        clearSelection();
      if (closeAllFilterPopups)
        closeAllFilterPopups();
      if (forceHeaderSync)
        forceHeaderSync();
    },
    // 同步所有区域高度
    measureAndSyncAllHeights: () => {
      if (measureAndSyncHeaderHeight)
        measureAndSyncHeaderHeight(true);
      setTimeout(() => {
        if (measureAndSyncRowHeights)
          measureAndSyncRowHeights();
      }, 50);
    },
    // 强制同步所有区域
    forceAllAreaSync: () => {
      if (forceHeaderSync)
        forceHeaderSync();
      setTimeout(() => {
        if (measureAndSyncHeaderHeight)
          measureAndSyncHeaderHeight(true);
        setTimeout(() => {
          if (measureAndSyncRowHeights)
            measureAndSyncRowHeights();
        }, 50);
      }, 50);
    }
  });
  const createBatchOperations = () => ({
    // 批量选择操作
    batchSelect: (rowKeys = []) => {
      if (setSelectedRowKeys) {
        setSelectedRowKeys(rowKeys);
      }
    },
    // 批量取消选择
    batchDeselect: (rowKeys = []) => {
      const currentKeys = getSelectedRowKeys ? getSelectedRowKeys() : [];
      const remainingKeys = currentKeys.filter((key) => !rowKeys.includes(key));
      if (setSelectedRowKeys) {
        setSelectedRowKeys(remainingKeys);
      }
    },
    // 重置表格状态
    resetTableState: () => {
      if (clearSelection)
        clearSelection();
      if (closeAllFilterPopups)
        closeAllFilterPopups();
      if (scrollToLeft)
        scrollToLeft();
    }
  });
  const createExposedAPI = () => ({
    // 基础操作
    ...createBaseOperations(),
    // 选择功能
    ...createSelectionOperations(),
    // 滚动控制
    ...createScrollOperations(),
    // 过滤控制
    ...createFilterOperations(),
    // 高级操作
    ...createAdvancedOperations(),
    // 批量操作
    ...createBatchOperations(),
    // 状态访问器
    ...createStateAccessors()
  });
  return {
    // 返回完整的对外API
    exposedAPI: createExposedAPI(),
    // 也可以分类返回，便于按需使用
    baseOperations: createBaseOperations(),
    selectionOperations: createSelectionOperations(),
    scrollOperations: createScrollOperations(),
    filterOperations: createFilterOperations(),
    advancedOperations: createAdvancedOperations(),
    batchOperations: createBatchOperations(),
    stateAccessors: createStateAccessors()
  };
}
const VantTable_vue_vue_type_style_index_0_scoped_b5082cf7_lang = "";
const VantTable_vue_vue_type_style_index_1_lang = "";
const _export_sfc = (sfc, props) => {
  const target = sfc.__vccOpts || sfc;
  for (const [key, val] of props) {
    target[key] = val;
  }
  return target;
};
const _hoisted_1 = {
  key: 0,
  class: "vant-table-loading"
};
const _hoisted_2 = { class: "vant-filter-modal" };
const _hoisted_3 = { class: "vant-filter-modal__header" };
const _hoisted_4 = { class: "vant-filter-modal__title" };
const _hoisted_5 = { class: "vant-filter-modal__content" };
const _hoisted_6 = { class: "vant-filter-search" };
const _hoisted_7 = { class: "vant-filter-v-options" };
const _hoisted_8 = { class: "vant-filter-v-option" };
const _hoisted_9 = { class: "vant-filter-v-option__text" };
const _hoisted_10 = { class: "vant-filter-modal__actions" };
const _hoisted_11 = { style: { "display": "none" } };
const _sfc_main = {
  __name: "VantTable",
  props: tableProps,
  emits: tableEvents,
  setup(__props, { expose: __expose, emit: __emit }) {
    var _a;
    const props = __props;
    const emit = __emit;
    const headerRef = ref(null);
    const headerContentRef = ref(null);
    const headerRowRef = ref(null);
    const leftHeaderRowRef = ref(null);
    const rightHeaderRowRef = ref(null);
    const bodyRef = ref(null);
    const tbodyRef = ref(null);
    const leftFixedRef = ref(null);
    const leftBodyWrapperRef = ref(null);
    const leftTbodyRef = ref(null);
    const rightFixedRef = ref(null);
    const rightBodyWrapperRef = ref(null);
    const rightTbodyRef = ref(null);
    const layoutWrapperRef = ref(null);
    const scrollbarWrapperRef = ref(null);
    const scrollbarHandleRef = ref(null);
    const tableHeaderRef = ref(null);
    const tableBodyRef = ref(null);
    const leftFixedColumnRef = ref(null);
    const rightFixedColumnRef = ref(null);
    const horizontalScrollbarRef = ref(null);
    const refs = {
      headerRef,
      headerContentRef,
      headerRowRef,
      leftHeaderRowRef,
      rightHeaderRowRef,
      bodyRef,
      tbodyRef,
      leftFixedRef,
      leftBodyWrapperRef,
      leftTbodyRef,
      rightFixedRef,
      rightBodyWrapperRef,
      rightTbodyRef,
      layoutWrapperRef,
      scrollbarWrapperRef,
      scrollbarHandleRef,
      tableHeaderRef,
      tableBodyRef,
      leftFixedColumnRef,
      rightFixedColumnRef,
      horizontalScrollbarRef
    };
    const composableResults = useTableSetup(props, emit, refs);
    const currentFilterStates = reactive({});
    (_a = props.headers) == null ? void 0 : _a.forEach((header) => {
      if (header.filterable) {
        currentFilterStates[header.key] = {
          show: false,
          searchValue: "",
          selectedValues: [],
          // 空数组表示全选状态
          allOptions: []
        };
      }
    });
    const getColumnOptions = (key) => {
      var _a2;
      if (!((_a2 = composableResults.filteredAndSortedData) == null ? void 0 : _a2.value))
        return [];
      const uniqueValues = [...new Set(composableResults.filteredAndSortedData.value.map((row) => row[key]).filter((v) => v != null))];
      return uniqueValues.sort();
    };
    const getFilteredOptions = (key) => {
      var _a2, _b;
      const allOptions = getColumnOptions(key);
      const searchValue = ((_b = (_a2 = currentFilterStates[key]) == null ? void 0 : _a2.searchValue) == null ? void 0 : _b.toLowerCase()) || "";
      if (!searchValue)
        return allOptions;
      return allOptions.filter(
        (option) => String(option).toLowerCase().includes(searchValue)
      );
    };
    const isOptionSelected = (key, option) => {
      var _a2;
      const selectedValues = ((_a2 = currentFilterStates[key]) == null ? void 0 : _a2.selectedValues) || [];
      if (selectedValues === "NONE") {
        return false;
      }
      if (selectedValues.length === 0) {
        return true;
      }
      return selectedValues.includes(option);
    };
    const isAllSelected = (key) => {
      var _a2;
      const selectedValues = ((_a2 = currentFilterStates[key]) == null ? void 0 : _a2.selectedValues) || [];
      return Array.isArray(selectedValues) && selectedValues.length === 0;
    };
    const handleSelectAll = (key) => {
      if (isAllSelected(key)) {
        currentFilterStates[key].selectedValues = "NONE";
      } else {
        currentFilterStates[key].selectedValues = [];
      }
    };
    const handleToggleOption = (key, option) => {
      const selectedValues = currentFilterStates[key].selectedValues;
      if (selectedValues === "NONE") {
        currentFilterStates[key].selectedValues = [option];
        return;
      }
      if (Array.isArray(selectedValues) && selectedValues.length === 0) {
        const allOptions = getColumnOptions(key);
        currentFilterStates[key].selectedValues = allOptions.filter((opt) => opt !== option);
      } else if (Array.isArray(selectedValues)) {
        const index = selectedValues.indexOf(option);
        if (index > -1) {
          selectedValues.splice(index, 1);
          if (selectedValues.length === 0) {
            currentFilterStates[key].selectedValues = "NONE";
          }
        } else {
          selectedValues.push(option);
        }
        const allOptions = getColumnOptions(key);
        if (selectedValues.length === allOptions.length) {
          currentFilterStates[key].selectedValues = [];
        }
      }
    };
    const handleResetFilter = (key) => {
      currentFilterStates[key].selectedValues = [];
      currentFilterStates[key].searchValue = "";
    };
    const handleApplyFilter = (key) => {
      const selectedValues = currentFilterStates[key].selectedValues;
      const allOptions = getColumnOptions(key);
      console.log("🎯 过滤器应用 - 字段:", key);
      console.log("🎯 选中的值:", selectedValues);
      console.log("🎯 所有可用选项:", allOptions);
      console.log("🎯 状态类型:", {
        isNone: selectedValues === "NONE",
        isAll: Array.isArray(selectedValues) && selectedValues.length === 0,
        isPartial: Array.isArray(selectedValues) && selectedValues.length > 0,
        value: selectedValues
      });
      if (selectedValues === "NONE") {
        console.log("🎯 应用全不选过滤");
        console.log("🎯 实际生效的选项: 无（不显示任何数据）");
        if (composableResults.resetFilter) {
          composableResults.resetFilter(key);
        }
        if (composableResults.toggleFilterOption) {
          composableResults.toggleFilterOption(key, "__FILTER_NONE__");
        }
      } else if (Array.isArray(selectedValues) && selectedValues.length === 0) {
        console.log("🎯 应用全选过滤（清除过滤）");
        console.log("🎯 实际生效的选项:", allOptions, "（显示所有数据）");
        if (composableResults.clearFilters) {
          composableResults.clearFilters();
        }
      } else if (Array.isArray(selectedValues)) {
        console.log("🎯 应用部分选择过滤");
        console.log("🎯 实际生效的选项:", selectedValues);
        console.log("🎯 被过滤掉的选项:", allOptions.filter((opt) => !selectedValues.includes(opt)));
        if (composableResults.toggleFilterOption) {
          if (composableResults.resetFilter) {
            composableResults.resetFilter(key);
          }
          selectedValues.forEach((value, index) => {
            console.log(`🎯 设置过滤选项 ${index + 1}:`, value);
            composableResults.toggleFilterOption(key, value);
          });
        }
      }
      console.log("🎯 过滤器应用完成，关闭弹窗");
      currentFilterStates[key].show = false;
    };
    const handleFilterClose = (key) => {
      currentFilterStates[key].show = false;
    };
    const toggleFilter = (key) => {
      console.log("🚀 VantTable LOCAL toggleFilter called with key:", key);
      console.log("🚀 This is the LOCAL toggle filter function!");
      if (!currentFilterStates[key]) {
        console.warn("⚠️ Filter state not found for key:", key);
        return;
      }
      currentFilterStates[key].show = !currentFilterStates[key].show;
      console.log("🚀 LOCAL Filter popup show state:", {
        key,
        show: currentFilterStates[key].show,
        state: currentFilterStates[key]
      });
    };
    const handleHeaderWheelEvent = (eventData) => {
      console.log("🎯 主组件收到表头滚动事件(通过emit):", eventData);
      if (composableResults.vxeStyleAbsoluteSync) {
        composableResults.vxeStyleAbsoluteSync(
          eventData.scrollTop,
          eventData.scrollLeft,
          "header"
          // 标记来源是表头，避免循环
        );
      }
    };
    const originalHeaderProps = composableResults.headerProps;
    const headerProps = computed(() => {
      var _a2;
      const props2 = {
        ...originalHeaderProps.value,
        toggleFilter
        // 使用本地的toggleFilter函数
      };
      console.log("🔍 HeaderProps updated:", {
        originalToggleFilter: (_a2 = originalHeaderProps.value) == null ? void 0 : _a2.toggleFilter,
        newToggleFilter: toggleFilter,
        propsToggleFilter: props2.toggleFilter,
        areEqual: props2.toggleFilter === toggleFilter
      });
      return props2;
    });
    const originalLeftFixedProps = composableResults.leftFixedProps;
    const leftFixedProps = computed(() => {
      const props2 = {
        ...originalLeftFixedProps.value,
        toggleFilter
        // 使用本地的toggleFilter函数
      };
      return props2;
    });
    const originalRightFixedProps = composableResults.rightFixedProps;
    const rightFixedProps = computed(() => {
      const props2 = {
        ...originalRightFixedProps.value,
        toggleFilter
        // 使用本地的toggleFilter函数
      };
      return props2;
    });
    const {
      // 核心数据和状态
      filteredAndSortedData,
      containerStyle,
      hasLeftFixedContent,
      hasRightFixedColumns,
      // 过滤相关 - 注意这里的filterStates是用于FilterPopup组件的
      filterStates: popupFilterStates,
      toggleFilter: popupToggleFilter,
      // 组件属性绑定（除了headerProps、leftFixedProps、rightFixedProps，我们已经重新定义了）
      bodyProps,
      scrollbarProps,
      loadMoreProps,
      filterProps
    } = composableResults;
    useTableWatchers(props, composableResults);
    useTableLifecycle(props, emit, refs, composableResults);
    onMounted(() => {
      nextTick(() => {
        var _a2, _b, _c, _d;
        console.log("🔍 调试表头、表体和固定列引用获取:", {
          tableHeaderRef: !!tableHeaderRef.value,
          tableBodyRef: !!tableBodyRef.value,
          leftFixedColumnRef: !!leftFixedColumnRef.value,
          rightFixedColumnRef: !!rightFixedColumnRef.value,
          headerContentRefFromChild: (_a2 = tableHeaderRef.value) == null ? void 0 : _a2.headerContentRef,
          bodyRefFromChild: (_b = tableBodyRef.value) == null ? void 0 : _b.bodyRef,
          leftBodyWrapperFromChild: (_c = leftFixedColumnRef.value) == null ? void 0 : _c.bodyWrapperRef,
          rightBodyWrapperFromChild: (_d = rightFixedColumnRef.value) == null ? void 0 : _d.bodyWrapperRef
        });
        const setupImmediateFallbackRefs = () => {
          console.log("🚀 设置立即DOM查询fallback以修复初始化滚动同步问题");
          if (!bodyRef.value) {
            const bodyElements = document.querySelectorAll(".vant-table-body");
            for (let element of bodyElements) {
              if (!element.closest(".vant-table-fixed")) {
                bodyRef.value = element;
                console.log("✅ 立即通过DOM查询设置bodyRef");
                break;
              }
            }
          }
          if (!headerContentRef.value) {
            const headerContentElement = document.querySelector(".vant-table-header__content");
            if (headerContentElement) {
              headerContentRef.value = headerContentElement;
              console.log("✅ 立即通过DOM查询设置headerContentRef");
            }
          }
          if (!leftBodyWrapperRef.value) {
            const leftFixedElements = document.querySelectorAll(".vant-table-fixed--left .vant-table-fixed__body");
            if (leftFixedElements.length > 0) {
              leftBodyWrapperRef.value = leftFixedElements[0];
              console.log("✅ 立即通过DOM查询设置leftBodyWrapperRef");
            }
          }
          if (!rightBodyWrapperRef.value) {
            const rightFixedElements = document.querySelectorAll(".vant-table-fixed--right .vant-table-fixed__body");
            if (rightFixedElements.length > 0) {
              rightBodyWrapperRef.value = rightFixedElements[0];
              console.log("✅ 立即通过DOM查询设置rightBodyWrapperRef");
            }
          }
          console.log("🔍 立即fallback设置后的ref状态:", {
            bodyRef: !!bodyRef.value,
            headerContentRef: !!headerContentRef.value,
            leftBodyWrapperRef: !!leftBodyWrapperRef.value,
            rightBodyWrapperRef: !!rightBodyWrapperRef.value
          });
        };
        setupImmediateFallbackRefs();
        setTimeout(setupImmediateFallbackRefs, 20);
        const testInitialScrollSync = () => {
          console.log("🧪 测试初始化滚动同步功能");
          const hasAllRefs = bodyRef.value && (leftBodyWrapperRef.value || !document.querySelector(".vant-table-fixed--left")) && (rightBodyWrapperRef.value || !document.querySelector(".vant-table-fixed--right"));
          if (hasAllRefs) {
            console.log("✅ 所有必要的refs已设置，滚动同步应该能正常工作");
            if (bodyRef.value) {
              const currentScrollTop = bodyRef.value.scrollTop;
              bodyRef.value.scrollTop = currentScrollTop + 1;
              setTimeout(() => {
                bodyRef.value.scrollTop = currentScrollTop;
                console.log("✅ 初始化滚动同步激活完成");
              }, 5);
            }
          } else {
            console.log("⚠️ 还有refs未设置，将在50ms后重试");
            setTimeout(testInitialScrollSync, 50);
          }
        };
        setTimeout(testInitialScrollSync, 30);
        const connectHeaderContentRef = () => {
          var _a3;
          if (tableHeaderRef.value && tableHeaderRef.value.headerContentRef && tableHeaderRef.value.headerContentRef.value) {
            headerContentRef.value = tableHeaderRef.value.headerContentRef.value;
            console.log("✅ 主组件成功获取表头内容引用:", {
              获取到的引用: !!headerContentRef.value,
              DOM元素: headerContentRef.value,
              元素类名: (_a3 = headerContentRef.value) == null ? void 0 : _a3.className
            });
            return true;
          }
          return false;
        };
        if (!connectHeaderContentRef()) {
          setTimeout(() => {
            if (!connectHeaderContentRef()) {
              const headerContentElement = document.querySelector(".vant-table-header__content");
              if (headerContentElement) {
                headerContentRef.value = headerContentElement;
                console.log("✅ 通过简化DOM查询获取表头内容引用");
              }
            }
          }, 100);
        }
        const connectBodyRef = () => {
          var _a3;
          if (tableBodyRef.value && tableBodyRef.value.bodyRef && tableBodyRef.value.bodyRef.value) {
            bodyRef.value = tableBodyRef.value.bodyRef.value;
            console.log("✅ 主组件成功获取表体引用:", {
              获取到的引用: !!bodyRef.value,
              DOM元素: bodyRef.value,
              元素类名: (_a3 = bodyRef.value) == null ? void 0 : _a3.className
            });
            return true;
          }
          return false;
        };
        if (!connectBodyRef()) {
          setTimeout(() => {
            if (!connectBodyRef()) {
              const bodyElements = document.querySelectorAll(".vant-table-body");
              for (let element of bodyElements) {
                if (!element.closest(".vant-table-fixed")) {
                  bodyRef.value = element;
                  console.log("✅ 通过简化DOM查询获取表体引用");
                  break;
                }
              }
            }
          }, 100);
        }
        const connectLeftBodyWrapper = () => {
          var _a3, _b2, _c2, _d2, _e;
          let leftBodyElement = null;
          if ((_b2 = (_a3 = leftFixedColumnRef.value) == null ? void 0 : _a3.bodyWrapperRef) == null ? void 0 : _b2.value) {
            leftBodyElement = leftFixedColumnRef.value.bodyWrapperRef.value;
            console.log("✅ 方法1成功: 通过组件暴露的ref获取左侧固定列");
          } else {
            const leftFixedElements = document.querySelectorAll(".vant-table-fixed--left .vant-table-fixed__body");
            if (leftFixedElements.length > 0) {
              leftBodyElement = leftFixedElements[0];
              console.log("✅ 方法2成功: 通过DOM查询获取左侧固定列");
            }
          }
          if (leftBodyElement) {
            leftBodyWrapperRef.value = leftBodyElement;
            console.log("✅ 主组件成功获取左侧固定列表体引用:", {
              获取到的引用: !!leftBodyWrapperRef.value,
              DOM元素: leftBodyWrapperRef.value,
              元素类名: (_c2 = leftBodyWrapperRef.value) == null ? void 0 : _c2.className,
              滚动能力: ((_d2 = leftBodyWrapperRef.value) == null ? void 0 : _d2.scrollHeight) > ((_e = leftBodyWrapperRef.value) == null ? void 0 : _e.clientHeight)
            });
            return true;
          }
          return false;
        };
        if (!connectLeftBodyWrapper()) {
          console.warn("⚠️ 主组件无法获取左侧固定列表体引用，开始重试...");
          const tryConnectLeft = (attempt = 1, maxAttempts = 5) => {
            setTimeout(() => {
              if (connectLeftBodyWrapper()) {
                console.log(`✅ 第${attempt}次重试成功获取左侧固定列表体引用`);
              } else if (attempt < maxAttempts) {
                console.log(`⚠️ 第${attempt}次重试失败，继续尝试...`);
                tryConnectLeft(attempt + 1, maxAttempts);
              } else {
                console.error(`❌ ${maxAttempts}次重试后仍无法获取左侧固定列表体引用`);
              }
            }, attempt * 100);
          };
          tryConnectLeft();
        }
        const connectRightBodyWrapper = () => {
          var _a3, _b2, _c2, _d2, _e;
          let rightBodyElement = null;
          if ((_b2 = (_a3 = rightFixedColumnRef.value) == null ? void 0 : _a3.bodyWrapperRef) == null ? void 0 : _b2.value) {
            rightBodyElement = rightFixedColumnRef.value.bodyWrapperRef.value;
            console.log("✅ 方法1成功: 通过组件暴露的ref获取右侧固定列");
          } else {
            const rightFixedElements = document.querySelectorAll(".vant-table-fixed--right .vant-table-fixed__body");
            if (rightFixedElements.length > 0) {
              rightBodyElement = rightFixedElements[0];
              console.log("✅ 方法2成功: 通过DOM查询获取右侧固定列");
            }
          }
          if (rightBodyElement) {
            rightBodyWrapperRef.value = rightBodyElement;
            console.log("✅ 主组件成功获取右侧固定列表体引用:", {
              获取到的引用: !!rightBodyWrapperRef.value,
              DOM元素: rightBodyWrapperRef.value,
              元素类名: (_c2 = rightBodyWrapperRef.value) == null ? void 0 : _c2.className,
              滚动能力: ((_d2 = rightBodyWrapperRef.value) == null ? void 0 : _d2.scrollHeight) > ((_e = rightBodyWrapperRef.value) == null ? void 0 : _e.clientHeight)
            });
            return true;
          }
          return false;
        };
        if (!connectRightBodyWrapper()) {
          console.warn("⚠️ 主组件无法获取右侧固定列表体引用，开始重试...");
          const tryConnectRight = (attempt = 1, maxAttempts = 5) => {
            setTimeout(() => {
              if (connectRightBodyWrapper()) {
                console.log(`✅ 第${attempt}次重试成功获取右侧固定列表体引用`);
              } else if (attempt < maxAttempts) {
                console.log(`⚠️ 第${attempt}次重试失败，继续尝试...`);
                tryConnectRight(attempt + 1, maxAttempts);
              } else {
                console.error(`❌ ${maxAttempts}次重试后仍无法获取右侧固定列表体引用`);
              }
            }, attempt * 100);
          };
          tryConnectRight();
        }
        window.testHeaderScroll = (scrollLeft = 200) => {
          if (headerContentRef.value) {
            console.log(`🧪 手动测试表头滚动到 ${scrollLeft}px`);
            headerContentRef.value.scrollLeft = scrollLeft;
            setTimeout(() => {
              console.log("🧪 滚动结果:", {
                目标scrollLeft: scrollLeft,
                实际scrollLeft: headerContentRef.value.scrollLeft,
                可滚动: headerContentRef.value.scrollWidth > headerContentRef.value.clientWidth,
                scrollWidth: headerContentRef.value.scrollWidth,
                clientWidth: headerContentRef.value.clientWidth
              });
            }, 100);
          } else {
            console.warn("⚠️ headerContentRef 不存在");
          }
        };
        window.testVerticalSync = (scrollTop = 100) => {
          console.log(`🧪 手动测试垂直滚动同步到 ${scrollTop}px`);
          console.log("🔍 当前引用状态:", {
            bodyRef: !!bodyRef.value,
            leftBodyWrapperRef: !!leftBodyWrapperRef.value,
            rightBodyWrapperRef: !!rightBodyWrapperRef.value
          });
          if (bodyRef.value) {
            bodyRef.value.scrollTop = scrollTop;
            console.log("✅ 主表格scrollTop已设置:", bodyRef.value.scrollTop);
            if (leftBodyWrapperRef.value) {
              leftBodyWrapperRef.value.scrollTop = scrollTop;
              console.log("✅ 左侧固定列scrollTop已设置:", leftBodyWrapperRef.value.scrollTop);
            }
            if (rightBodyWrapperRef.value) {
              rightBodyWrapperRef.value.scrollTop = scrollTop;
              console.log("✅ 右侧固定列scrollTop已设置:", rightBodyWrapperRef.value.scrollTop);
            }
            setTimeout(() => {
              var _a3, _b2, _c2, _d2;
              console.log("🔍 同步结果检查:", {
                主表格scrollTop: (_a3 = bodyRef.value) == null ? void 0 : _a3.scrollTop,
                左侧固定列scrollTop: (_b2 = leftBodyWrapperRef.value) == null ? void 0 : _b2.scrollTop,
                右侧固定列scrollTop: (_c2 = rightBodyWrapperRef.value) == null ? void 0 : _c2.scrollTop,
                同步成功: ((_d2 = bodyRef.value) == null ? void 0 : _d2.scrollTop) === scrollTop && (!leftBodyWrapperRef.value || leftBodyWrapperRef.value.scrollTop === scrollTop) && (!rightBodyWrapperRef.value || rightBodyWrapperRef.value.scrollTop === scrollTop)
              });
            }, 100);
          } else {
            console.warn("⚠️ bodyRef 不存在，无法测试垂直滚动同步");
          }
        };
        window.testScrollEvents = () => {
          var _a3, _b2, _c2, _d2, _e, _f, _g, _h, _i, _j, _k, _l;
          console.log("🧪 测试滚动事件绑定状态");
          console.log("主表格滚动事件:", {
            element: bodyRef.value,
            hasScrollListener: !!((_a3 = bodyRef.value) == null ? void 0 : _a3.onscroll),
            scrollHeight: (_b2 = bodyRef.value) == null ? void 0 : _b2.scrollHeight,
            clientHeight: (_c2 = bodyRef.value) == null ? void 0 : _c2.clientHeight,
            canScroll: bodyRef.value && bodyRef.value.scrollHeight > bodyRef.value.clientHeight,
            currentScrollTop: (_d2 = bodyRef.value) == null ? void 0 : _d2.scrollTop
          });
          if (leftBodyWrapperRef.value) {
            console.log("左侧固定列滚动事件:", {
              element: leftBodyWrapperRef.value,
              hasScrollListener: !!((_e = leftBodyWrapperRef.value) == null ? void 0 : _e.onscroll),
              scrollHeight: (_f = leftBodyWrapperRef.value) == null ? void 0 : _f.scrollHeight,
              clientHeight: (_g = leftBodyWrapperRef.value) == null ? void 0 : _g.clientHeight,
              canScroll: leftBodyWrapperRef.value.scrollHeight > leftBodyWrapperRef.value.clientHeight,
              currentScrollTop: (_h = leftBodyWrapperRef.value) == null ? void 0 : _h.scrollTop,
              overflowY: getComputedStyle(leftBodyWrapperRef.value).overflowY
            });
          }
          if (rightBodyWrapperRef.value) {
            console.log("右侧固定列滚动事件:", {
              element: rightBodyWrapperRef.value,
              hasScrollListener: !!((_i = rightBodyWrapperRef.value) == null ? void 0 : _i.onscroll),
              scrollHeight: (_j = rightBodyWrapperRef.value) == null ? void 0 : _j.scrollHeight,
              clientHeight: (_k = rightBodyWrapperRef.value) == null ? void 0 : _k.clientHeight,
              canScroll: rightBodyWrapperRef.value.scrollHeight > rightBodyWrapperRef.value.clientHeight,
              currentScrollTop: (_l = rightBodyWrapperRef.value) == null ? void 0 : _l.scrollTop,
              overflowY: getComputedStyle(rightBodyWrapperRef.value).overflowY
            });
          }
        };
        window.testWheelEvents = (deltaY = 50) => {
          console.log(`🧪 手动触发wheel事件，deltaY: ${deltaY}`);
          if (bodyRef.value) {
            const wheelEvent = new WheelEvent("wheel", {
              deltaY,
              deltaX: 0,
              bubbles: true,
              cancelable: true
            });
            bodyRef.value.dispatchEvent(wheelEvent);
            console.log("✅ 主表格wheel事件已触发");
          }
          if (leftBodyWrapperRef.value) {
            const wheelEvent = new WheelEvent("wheel", {
              deltaY,
              deltaX: 0,
              bubbles: true,
              cancelable: true
            });
            leftBodyWrapperRef.value.dispatchEvent(wheelEvent);
            console.log("✅ 左侧固定列wheel事件已触发");
          }
        };
        window.forceScroll = (target = "main", scrollTop = 50) => {
          console.log(`🧪 强制滚动测试 - 目标: ${target}, scrollTop: ${scrollTop}`);
          let targetElement = null;
          if (target === "main" && bodyRef.value) {
            targetElement = bodyRef.value;
          } else if (target === "left" && leftBodyWrapperRef.value) {
            targetElement = leftBodyWrapperRef.value;
          } else if (target === "right" && rightBodyWrapperRef.value) {
            targetElement = rightBodyWrapperRef.value;
          }
          if (targetElement) {
            console.log("🔍 滚动前状态:", {
              scrollTop: targetElement.scrollTop,
              scrollHeight: targetElement.scrollHeight,
              clientHeight: targetElement.clientHeight,
              canScroll: targetElement.scrollHeight > targetElement.clientHeight,
              computedStyle: {
                overflow: getComputedStyle(targetElement).overflow,
                overflowY: getComputedStyle(targetElement).overflowY,
                height: getComputedStyle(targetElement).height,
                maxHeight: getComputedStyle(targetElement).maxHeight
              }
            });
            targetElement.scrollTop = scrollTop;
            console.log("🔍 滚动后状态:", {
              scrollTop: targetElement.scrollTop,
              设置成功: targetElement.scrollTop === scrollTop
            });
          } else {
            console.warn(`⚠️ 找不到目标元素: ${target}`);
          }
        };
        window.checkFixedContent = () => {
          var _a3, _b2, _c2, _d2, _e, _f, _g, _h, _i, _j;
          console.log("🧪 检查固定列内容");
          if (leftFixedColumnRef.value) {
            const leftElement = leftFixedColumnRef.value.$el || leftFixedColumnRef.value;
            console.log("🔍 左侧固定列状态:", {
              组件存在: !!leftFixedColumnRef.value,
              DOM元素: leftElement,
              shouldShow: (_a3 = leftFixedColumnRef.value) == null ? void 0 : _a3.shouldShow,
              columns: (_b2 = leftFixedColumnRef.value) == null ? void 0 : _b2.columns,
              filteredData: (_c2 = leftFixedColumnRef.value) == null ? void 0 : _c2.filteredAndSortedData,
              innerHTML: ((_d2 = leftElement == null ? void 0 : leftElement.innerHTML) == null ? void 0 : _d2.substring(0, 200)) + "...",
              子元素数量: (_e = leftElement == null ? void 0 : leftElement.children) == null ? void 0 : _e.length
            });
          }
          if (rightFixedColumnRef.value) {
            const rightElement = rightFixedColumnRef.value.$el || rightFixedColumnRef.value;
            console.log("🔍 右侧固定列状态:", {
              组件存在: !!rightFixedColumnRef.value,
              DOM元素: rightElement,
              shouldShow: (_f = rightFixedColumnRef.value) == null ? void 0 : _f.shouldShow,
              columns: (_g = rightFixedColumnRef.value) == null ? void 0 : _g.columns,
              filteredData: (_h = rightFixedColumnRef.value) == null ? void 0 : _h.filteredAndSortedData,
              innerHTML: ((_i = rightElement == null ? void 0 : rightElement.innerHTML) == null ? void 0 : _i.substring(0, 200)) + "...",
              子元素数量: (_j = rightElement == null ? void 0 : rightElement.children) == null ? void 0 : _j.length
            });
          }
        };
        window.checkRefConnections = () => {
          var _a3, _b2, _c2, _d2, _e, _f, _g, _h;
          console.log("🔍 检查所有ref连接状态:");
          console.log("主要组件refs:", {
            tableHeaderRef: !!tableHeaderRef.value,
            tableBodyRef: !!tableBodyRef.value,
            leftFixedColumnRef: !!leftFixedColumnRef.value,
            rightFixedColumnRef: !!rightFixedColumnRef.value
          });
          console.log("内部DOM refs:", {
            headerContentRef: !!headerContentRef.value,
            bodyRef: !!bodyRef.value,
            leftBodyWrapperRef: !!leftBodyWrapperRef.value,
            rightBodyWrapperRef: !!rightBodyWrapperRef.value
          });
          console.log("组件暴露的refs:", {
            headerContentFromChild: (_b2 = (_a3 = tableHeaderRef.value) == null ? void 0 : _a3.headerContentRef) == null ? void 0 : _b2.value,
            bodyFromChild: (_d2 = (_c2 = tableBodyRef.value) == null ? void 0 : _c2.bodyRef) == null ? void 0 : _d2.value,
            leftBodyWrapperFromChild: (_f = (_e = leftFixedColumnRef.value) == null ? void 0 : _e.bodyWrapperRef) == null ? void 0 : _f.value,
            rightBodyWrapperFromChild: (_h = (_g = rightFixedColumnRef.value) == null ? void 0 : _g.bodyWrapperRef) == null ? void 0 : _h.value
          });
        };
        window.forceReconnectRefs = () => {
          var _a3, _b2, _c2, _d2;
          console.log("🔧 强制重新连接所有refs...");
          if ((_b2 = (_a3 = tableHeaderRef.value) == null ? void 0 : _a3.headerContentRef) == null ? void 0 : _b2.value) {
            headerContentRef.value = tableHeaderRef.value.headerContentRef.value;
            console.log("✅ headerContentRef重连成功");
          }
          if ((_d2 = (_c2 = tableBodyRef.value) == null ? void 0 : _c2.bodyRef) == null ? void 0 : _d2.value) {
            bodyRef.value = tableBodyRef.value.bodyRef.value;
            console.log("✅ bodyRef重连成功");
          }
          if (connectLeftBodyWrapper()) {
            console.log("✅ leftBodyWrapperRef重连成功");
          } else {
            console.warn("⚠️ leftBodyWrapperRef重连失败");
          }
          if (connectRightBodyWrapper()) {
            console.log("✅ rightBodyWrapperRef重连成功");
          } else {
            console.warn("⚠️ rightBodyWrapperRef重连失败");
          }
          window.checkRefConnections();
        };
        console.log("🔧 全局测试函数已添加：");
        console.log("  - window.testHeaderScroll(scrollLeft) - 测试表头水平滚动");
        console.log("  - window.testVerticalSync(scrollTop) - 测试垂直滚动同步");
        console.log("  - window.testScrollEvents() - 测试滚动事件绑定状态");
        console.log("  - window.testWheelEvents(deltaY) - 手动触发wheel事件测试");
        console.log("  - window.forceScroll(target, scrollTop) - 强制滚动测试 (target: main/left/right)");
        console.log("  - window.checkFixedContent() - 检查固定列内容状态");
        console.log("  - window.checkRefConnections() - 检查ref连接状态");
        console.log("  - window.forceReconnectRefs() - 强制重新连接refs");
      });
    });
    const { exposedAPI } = useTableExpose(composableResults);
    __expose(exposedAPI);
    return (_ctx, _cache) => {
      var _a2;
      return openBlock(), createElementBlock("div", {
        class: normalizeClass(["vant-table-wrapper", { "has-load-more": _ctx.enableLoadMore && _ctx.showLoadMoreUi, "has-horizontal-scrollbar": _ctx.showHorizontalScrollbar }]),
        style: normalizeStyle(unref(containerStyle)),
        "data-active-fix": "true"
      }, [
        _ctx.loading ? (openBlock(), createElementBlock("div", _hoisted_1, [
          createVNode(unref(Loading), { size: "24px" })
        ])) : createCommentVNode("", true),
        createElementVNode("div", {
          class: "vant-table-layout-wrapper",
          ref_key: "layoutWrapperRef",
          ref: layoutWrapperRef
        }, [
          createVNode(_sfc_main$8, mergeProps(headerProps.value, {
            "body-ref": bodyRef.value,
            onHeaderWheel: handleHeaderWheelEvent,
            ref_key: "tableHeaderRef",
            ref: tableHeaderRef
          }), null, 16, ["body-ref"]),
          createVNode(_sfc_main$7, mergeProps(unref(bodyProps), {
            ref_key: "tableBodyRef",
            ref: tableBodyRef
          }), {
            expanded: withCtx(({ row, rowIndex }) => [
              renderSlot(_ctx.$slots, "expanded", {
                row,
                rowIndex
              }, void 0, true)
            ]),
            _: 3
          }, 16)
        ], 512),
        unref(hasLeftFixedContent) ? (openBlock(), createBlock(_sfc_main$4, mergeProps({
          key: 1,
          position: "left"
        }, leftFixedProps.value, {
          onLoadMore: _cache[0] || (_cache[0] = ($event) => _ctx.$emit("load-more")),
          ref_key: "leftFixedColumnRef",
          ref: leftFixedColumnRef
        }), null, 16)) : createCommentVNode("", true),
        unref(hasRightFixedColumns) ? (openBlock(), createBlock(_sfc_main$4, mergeProps({
          key: 2,
          position: "right"
        }, rightFixedProps.value, {
          onLoadMore: _cache[1] || (_cache[1] = ($event) => _ctx.$emit("load-more")),
          ref_key: "rightFixedColumnRef",
          ref: rightFixedColumnRef
        }), null, 16)) : createCommentVNode("", true),
        createVNode(_sfc_main$3, mergeProps(unref(scrollbarProps), {
          ref_key: "horizontalScrollbarRef",
          ref: horizontalScrollbarRef
        }), null, 16),
        createVNode(_sfc_main$2, mergeProps(unref(loadMoreProps), {
          onLoadMore: _cache[2] || (_cache[2] = ($event) => _ctx.$emit("load-more"))
        }), null, 16),
        (openBlock(true), createElementBlock(Fragment, null, renderList((_a2 = props.headers) == null ? void 0 : _a2.filter((h2) => h2.filterable), (header) => {
          var _a3;
          return openBlock(), createBlock(Teleport, {
            key: `filter-${header.key}`,
            to: "body"
          }, [
            ((_a3 = currentFilterStates[header.key]) == null ? void 0 : _a3.show) ? (openBlock(), createBlock(unref(Popup), {
              key: 0,
              show: currentFilterStates[header.key].show,
              "onUpdate:show": ($event) => currentFilterStates[header.key].show = $event,
              position: "center",
              style: { zIndex: 99999 },
              "lazy-render": true,
              "destroy-on-close": true,
              closeable: "",
              onClickOverlay: ($event) => handleFilterClose(header.key),
              round: "",
              class: "vant-filter-modal-popup vant-filter-modal-popup--teleport van-overlay"
            }, {
              default: withCtx(() => [
                createElementVNode("div", _hoisted_2, [
                  createElementVNode("div", _hoisted_3, [
                    createElementVNode("span", _hoisted_4, "过滤 " + toDisplayString(header.label), 1),
                    createVNode(unref(Icon), {
                      name: "cross",
                      class: "vant-filter-modal__close",
                      onClick: ($event) => handleFilterClose(header.key)
                    }, null, 8, ["onClick"])
                  ]),
                  createElementVNode("div", _hoisted_5, [
                    createElementVNode("div", _hoisted_6, [
                      createVNode(unref(Field), {
                        modelValue: currentFilterStates[header.key].searchValue,
                        "onUpdate:modelValue": ($event) => currentFilterStates[header.key].searchValue = $event,
                        placeholder: "搜索...",
                        size: "small",
                        clearable: ""
                      }, null, 8, ["modelValue", "onUpdate:modelValue"])
                    ]),
                    createElementVNode("div", _hoisted_7, [
                      createElementVNode("div", _hoisted_8, [
                        createVNode(unref(Checkbox), {
                          "model-value": isAllSelected(header.key),
                          "onUpdate:modelValue": ($event) => handleSelectAll(header.key)
                        }, {
                          default: withCtx(() => _cache[3] || (_cache[3] = [
                            createElementVNode("span", { class: "vant-filter-v-option__text" }, "全部", -1)
                          ])),
                          _: 2,
                          __: [3]
                        }, 1032, ["model-value", "onUpdate:modelValue"])
                      ]),
                      (openBlock(true), createElementBlock(Fragment, null, renderList(getFilteredOptions(header.key), (option) => {
                        return openBlock(), createElementBlock("div", {
                          key: option,
                          class: "vant-filter-v-option"
                        }, [
                          createVNode(unref(Checkbox), {
                            "model-value": isOptionSelected(header.key, option),
                            "onUpdate:modelValue": ($event) => handleToggleOption(header.key, option)
                          }, {
                            default: withCtx(() => [
                              createElementVNode("span", _hoisted_9, toDisplayString(option), 1)
                            ]),
                            _: 2
                          }, 1032, ["model-value", "onUpdate:modelValue"])
                        ]);
                      }), 128))
                    ])
                  ]),
                  createElementVNode("div", _hoisted_10, [
                    createVNode(unref(Button), {
                      block: "",
                      onClick: ($event) => handleResetFilter(header.key)
                    }, {
                      default: withCtx(() => _cache[4] || (_cache[4] = [
                        createTextVNode("重置")
                      ])),
                      _: 2,
                      __: [4]
                    }, 1032, ["onClick"]),
                    createVNode(unref(Button), {
                      block: "",
                      type: "primary",
                      onClick: ($event) => handleApplyFilter(header.key)
                    }, {
                      default: withCtx(() => _cache[5] || (_cache[5] = [
                        createTextVNode("确定")
                      ])),
                      _: 2,
                      __: [5]
                    }, 1032, ["onClick"])
                  ])
                ])
              ]),
              _: 2
            }, 1032, ["show", "onUpdate:show", "onClickOverlay"])) : createCommentVNode("", true)
          ]);
        }), 128)),
        createElementVNode("div", _hoisted_11, toDisplayString(console.log("🔍 VantTable filterProps:", unref(filterProps))), 1),
        createVNode(_sfc_main$1, mergeProps(unref(filterProps), { style: { "display": "none" } }), null, 16)
      ], 6);
    };
  }
};
const VantTable = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-b5082cf7"]]);
VantTable.install = (app) => {
  app.component("VantTable", VantTable);
};
export {
  VantTable,
  VantTable as default
};
//# sourceMappingURL=index.mjs.map
